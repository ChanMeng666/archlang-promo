<!-- AGENT-FIRST NOTICE -->
> [!IMPORTANT]
> ### 🤖 Read this with your AI agent — don't read it by hand.
> This repo is written agent-first. Point Claude Code, GitHub Copilot, Cursor, or any agent at it:
> *"Read the README and AGENTS.md, then help me run / extend this."*
> Structure + [`AGENTS.md`](AGENTS.md) are optimized for agent comprehension.
<!-- /AGENT-FIRST NOTICE -->

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="./brand/archlang-wordmark.svg" />
  <img src="./brand/archlang-wordmark-black.svg" alt="ArchLang" width="440" />
</picture>

### Floor plans as code — compiled to SVG, DXF and PDF.

**An open-source (MIT) DSL for floor plans that compiles `.arch` source to SVG/DXF/PDF with linting
and geometric validation — diffable, reproducible, and LLM-writable.** Text in, a precise
architectural drawing out: deterministic, zero-dependency, and built so an
**AI agent can verify its own plan without ever looking at an image**.

[![npm](https://img.shields.io/npm/v/@chanmeng666/archlang?style=flat-square&logo=npm&color=CB3837)](https://www.npmjs.com/package/@chanmeng666/archlang)
[![CI](https://img.shields.io/github/actions/workflow/status/chanmeng666/archlang/ci.yml?branch=main&style=flat-square&logo=githubactions&logoColor=white&label=CI)](https://github.com/chanmeng666/archlang/actions/workflows/ci.yml)
[![Node](https://img.shields.io/node/v/@chanmeng666/archlang?style=flat-square&logo=nodedotjs&color=339933)](https://nodejs.org)
[![Runtime deps](https://img.shields.io/badge/runtime%20deps-0-2e7d32?style=flat-square)](#-why-it-is-different)
[![License](https://img.shields.io/github/license/chanmeng666/archlang?style=flat-square)](LICENSE)
[![Stars](https://img.shields.io/github/stars/chanmeng666/archlang?style=flat-square)](https://github.com/chanmeng666/archlang/stargazers)
[![Sponsor](https://img.shields.io/badge/Sponsor-%E2%9D%A4-EA4AAA?style=flat-square&logo=githubsponsors)](https://github.com/sponsors/ChanMeng666)

**[▶ Live Playground](https://playground.archlang.uk)** · **[📖 Docs](https://archlang.uk)** · **[⌨ CLI reference](https://archlang.uk/cli)** · **[📦 npm](https://www.npmjs.com/package/@chanmeng666/archlang)** · **[🧩 VS Code](https://marketplace.visualstudio.com/items?itemName=ChanMeng.archlang)**

</div>

## 👀 See it

Here is a **whole program**, and below it **the actual drawing it compiles to** — not a mock-up.
Not one coordinate in it places a door, a window or a piece of furniture: every opening is pinned to
a distance along a *named wall*, every fixture resolves against a room or a wall, and the bath and
bedroom are laid out by a `strip`. `site { street north }` names the two facades the plan turns
on — the front door faces the lane, the glazing faces the garden.

```arch
# A one-bedroom laneway cottage — 49 m² that reads as one program.
#
# Nothing here is positioned by hand. Every opening is pinned to a run distance along a
# named wall (`on <wall> at <pos>`), every fixture resolves against a room or a wall
# (`in <room> anchor …`, `against wall …`), and the bath/bedroom pair is laid out by
# `strip`. `site { street north }` names the two facades the plan turns on: the door
# faces the lane, the glass faces the garden.
plan "Laneway House" {
  units mm
  grid 50            # partitions are 100 thick, so a `flush` fixture lands on a …50
  north up
  dims auto all
  site { street north }

  wall id=w_lane   exterior  thickness 200 { (0,0) (7500,0) }
  wall id=w_east   exterior  thickness 200 { (7500,0) (7500,6500) }
  wall id=w_garden exterior  thickness 200 { (0,6500) (7500,6500) }
  wall id=w_west   exterior  thickness 200 { (0,0) (0,6500) }
  wall id=w_hall   partition thickness 100 { (4200,0) (4200,6500) }
  wall id=w_bath   partition thickness 100 { (4200,2500) (7500,2500) }

  room id=r_live at (0,0) size 4200x6500 label "Living / Kitchen" uses living kitchen
  strip down at (4200,0) gap 0 width 3300 {
    room id=r_bath size 2500 label "Bath"    uses bath
    room id=r_bed  size 4000 label "Bedroom" uses bedroom
  }

  door id=d_front  on w_lane at 2100 width 900 hinge near start swing into r_live
  door id=d_garden sliding on w_garden at 2700 width 1800 slide left
  door id=d_bed    on w_hall at 5600 width 800 hinge left swing into r_bed
  # `w_hall` is walked lane→garden, so `slide right` sends the panel down the solid wall
  # below the jamb; `slide left` would aim it at 500 mm and trip `W_POCKET_RUN`.
  door id=d_bath   pocket on w_hall at 900 width 800 slide right

  window on w_west   at 2400 width 1200
  window on w_garden at 700  width 1000
  window on w_garden at 5850 width 1600
  window on w_east   at 1500 width 600

  furniture fridge       against wall w_west offset 400  in r_live
  furniture stove        against wall w_west offset 1200 in r_live
  furniture kitchen_sink against wall w_west offset 2000 in r_live
  furniture table  in r_live centered size 1300x900 label "Table"
  furniture sofa   in r_live anchor bottom-left flush inset 250 size 900x2000  label "Sofa"
  furniture bed    in r_bed  anchor bottom-right flush inset 250 size 1500x2000 label "Bed"
  furniture robe   in r_bed  anchor top-left     flush inset 200 size 1800x600  label "Wardrobe"
  furniture shower in r_bath anchor top-right    flush size 900x900
  furniture wc     in r_bath anchor bottom-left  flush size 400x700
  furniture basin  in r_bath anchor bottom-right flush size 600x450

  title { project "Laneway House" drawn_by "ArchLang" date "2026-08-16" }
}
```

<div align="center">

<a href="https://playground.archlang.uk/#z=jVZdbhs3EH7fU3yQXhxAdmjZUuw2CZC2AQrESIs0QdAn70gcaVmvSIGkvHIDA3nqAYqeoQfoEXqUnKQYciWtHMepnijuzMdvvvkh-3gBZ_lwwto7t0BNlhu6wdTFSHPGp49_4fQci3__QawowjPpAArihKV3c0-Lo6Jf9PHaxcrYOSr2DBOwdMFE4yxrTG5QkdVHeHnN_gZuyVYsxchYMYgOBL-y0CZEslMG1c7OQUUflhas0VBd46B0Fk9l-RwU8XTpwvPy0QCcYGdmHVee4Tm4-poDaE7GhijQEprzoIRT9HFQGounsv0cZKeV8_j08e9ygHLjlA6UvUcDkNWIFWNCsXq8UWpJxksINRkNt4qY3BR9lCF6syyPUAYTGR8QomeOsM7HCrdlCicktNg4zGhKuv2_rMkirrwVcb9JW9o5X_TFqrWR9AzSal5TCJ0vc_Ka7VGRUHoXbRp_dKvAPXwogJU1MWCxKIC5Nxojhc6vjyX5mBIWQJ5xrBRiZaZXAwTJTjmrV6EqtyrXZLUQBYlKI1WgjXG1LABtFgG0krzWdQHcK0ZRIMts9LPmUkIDwOvI3jiPfLrlEDBUCh9woAbqEQ6ejFRa3O55M4X4sPfGLy_GI_UZRpbwYQbZ78sYDX-NRyZxv3clK-xS0fE-zt6nwzaKtLgPQ4r0f2AMO4EMW5gCuVOMfuYva3PN0mWZcDC_M8RxLWeipgnX6F2Ya2nkx3hl4rRi28MqcECdt6_ypqRfmgLaNTYhboKY0xIKjdGxwsmJkCukFnccUizp6GHn1O8oVj0xTIeJzV031mgZq45bbtyWY9vGBXLc0mnirC9n3tkIqey2JiliKMplnudKQeYcwzJ5hEg-IjRpntnokIXbQ2zrKtRGi1lCbvcE-8kW-_hMqWTGqHkW90BSTC2tVCYUMRpvXc-2tMRzn9CEdSEdXmbPUqZWQ_UV6zRPPv3xZ2aTOr3M53szr2KJwNLlaTqR5TqnUP4GV5s8lRP0hGvXpA-_0WLy7QZFuJRo3KrWILOAiYm2Ulgs8lSVuijfX_780_evXr69fPPudXm0H3ZbzW56xXE_-vO94Du001wxVrsmO7Q9KVqf7rQeKnXHbpcTScnGTj1gNzobbfHGn9m1M4kijkfbc8WsAGYrb00apDNv9JzbMbx3-7TM3WwWOEopA8buCmwHEaK73iA8BCExfwGi7dXLYOzVQxBDdQeij7cVw6_SdU4W717_8PLNxYtfB9CeGosJz5znXEKG821FUfrGapHJRKm6XFIzkqJIoJEmNcu1gWsTzKS-EdvolvAUK_YCYlHlhjIxPVPyPZ5fE4In7T1Aba4yzfRIyE8UrgOnd8oAVrZBmDrntbEU-WhPFwmsI_vmsTBxMbrFYeo1YzfpyZPqTKn1yWmqhh1OjqcDNGUbWdgmp-MTpdbnu1n1Vsx7-0kWeb5CJd3RLaHhqCV0rtQ6pW0D_oub0T52O1wSdlrvY6euuh9cKjuj76bsPrZ3E74PO7plJi2_PeyNkjIO1-MO8ffktcDdEaZyDfv2ABkXnQMy8-0BWz3O76SnmWInQAejK24X41Sp9ZM7GBMKxn4ZoytiwhgrtT4dpWkQTazlfbT07jeexs_eb6mVLic36L3w0-qC7LwHTZHRG6rh-FCdHR6Pe7gtbov_AA">
<img src="./examples/laneway-house.svg" alt="The floor plan the program above compiles to — click to open it in the live playground" width="620" />
</a>

**↑ `arch compile laneway-house.arch` — that program, rendered.** The walls join and hatch
themselves, the hinged doors draw their own swing arcs, the sliding and pocket leaves draw panels
instead (a pocket door has no arc, because it has no swing), and `dims auto all` measures the
building it was given.

**▶ [Click the drawing](https://playground.archlang.uk/#z=jVZdbhs3EH7fU3yQXhxAdmjZUuw2CZC2AQrESIs0QdAn70gcaVmvSIGkvHIDA3nqAYqeoQfoEXqUnKQYciWtHMepnijuzMdvvvkh-3gBZ_lwwto7t0BNlhu6wdTFSHPGp49_4fQci3__QawowjPpAArihKV3c0-Lo6Jf9PHaxcrYOSr2DBOwdMFE4yxrTG5QkdVHeHnN_gZuyVYsxchYMYgOBL-y0CZEslMG1c7OQUUflhas0VBd46B0Fk9l-RwU8XTpwvPy0QCcYGdmHVee4Tm4-poDaE7GhijQEprzoIRT9HFQGounsv0cZKeV8_j08e9ygHLjlA6UvUcDkNWIFWNCsXq8UWpJxksINRkNt4qY3BR9lCF6syyPUAYTGR8QomeOsM7HCrdlCicktNg4zGhKuv2_rMkirrwVcb9JW9o5X_TFqrWR9AzSal5TCJ0vc_Ka7VGRUHoXbRp_dKvAPXwogJU1MWCxKIC5Nxojhc6vjyX5mBIWQJ5xrBRiZaZXAwTJTjmrV6EqtyrXZLUQBYlKI1WgjXG1LABtFgG0krzWdQHcK0ZRIMts9LPmUkIDwOvI3jiPfLrlEDBUCh9woAbqEQ6ejFRa3O55M4X4sPfGLy_GI_UZRpbwYQbZ78sYDX-NRyZxv3clK-xS0fE-zt6nwzaKtLgPQ4r0f2AMO4EMW5gCuVOMfuYva3PN0mWZcDC_M8RxLWeipgnX6F2Ya2nkx3hl4rRi28MqcECdt6_ypqRfmgLaNTYhboKY0xIKjdGxwsmJkCukFnccUizp6GHn1O8oVj0xTIeJzV031mgZq45bbtyWY9vGBXLc0mnirC9n3tkIqey2JiliKMplnudKQeYcwzJ5hEg-IjRpntnokIXbQ2zrKtRGi1lCbvcE-8kW-_hMqWTGqHkW90BSTC2tVCYUMRpvXc-2tMRzn9CEdSEdXmbPUqZWQ_UV6zRPPv3xZ2aTOr3M53szr2KJwNLlaTqR5TqnUP4GV5s8lRP0hGvXpA-_0WLy7QZFuJRo3KrWILOAiYm2Ulgs8lSVuijfX_780_evXr69fPPudXm0H3ZbzW56xXE_-vO94Du001wxVrsmO7Q9KVqf7rQeKnXHbpcTScnGTj1gNzobbfHGn9m1M4kijkfbc8WsAGYrb00apDNv9JzbMbx3-7TM3WwWOEopA8buCmwHEaK73iA8BCExfwGi7dXLYOzVQxBDdQeij7cVw6_SdU4W717_8PLNxYtfB9CeGosJz5znXEKG821FUfrGapHJRKm6XFIzkqJIoJEmNcu1gWsTzKS-EdvolvAUK_YCYlHlhjIxPVPyPZ5fE4In7T1Aba4yzfRIyE8UrgOnd8oAVrZBmDrntbEU-WhPFwmsI_vmsTBxMbrFYeo1YzfpyZPqTKn1yWmqhh1OjqcDNGUbWdgmp-MTpdbnu1n1Vsx7-0kWeb5CJd3RLaHhqCV0rtQ6pW0D_oub0T52O1wSdlrvY6euuh9cKjuj76bsPrZ3E74PO7plJi2_PeyNkjIO1-MO8ffktcDdEaZyDfv2ABkXnQMy8-0BWz3O76SnmWInQAejK24X41Sp9ZM7GBMKxn4ZoytiwhgrtT4dpWkQTazlfbT07jeexs_eb6mVLic36L3w0-qC7LwHTZHRG6rh-FCdHR6Pe7gtbov_AA)** — it opens the
live playground with **this exact plan already loaded**. Change a number and watch it redraw;
the compiler runs in your browser, nothing is sent to a server.

</div>

> **Why a link and not a live embed?** ArchLang *does* ship an embeddable viewer — but
> **GitHub's markdown sanitizer strips `<iframe>`** (it comes back as escaped text, exactly like
> `<script>`), so no README on GitHub can host one. The embed works everywhere GitHub isn't:
> see [Embed a plan anywhere](#embed-a-plan-anywhere). Source:
> [`examples/laneway-house.arch`](examples/laneway-house.arch).

## 🌟 Introduction

**ArchLang** is a small declarative language for floor plans. You *declare* a plan — walls, rooms,
doors, windows, furniture — and the compiler renders a clean, professional **SVG** (also DXF, PDF,
PNG, and a zero-dependency ASCII plan). It works the way Typst and LaTeX work for documents: the
source is the thing you keep, and the drawing is what the compiler makes of it.

Coordinates are integer **millimetres**, so output is **deterministic**: the same source always
produces byte-identical bytes, and changing one number changes exactly one thing. *"Make the bedroom
1 m wider"* is a one-number diff — not a re-roll of a raster image that silently redraws the kitchen
too.

The compiler is **pure TypeScript with zero runtime dependencies** and is isomorphic — the same code
runs in Node and in the browser, which is why the [playground](https://playground.archlang.uk)
is fully client-side.

> ArchLang is the floor-plan engine behind [ArchCanvas](https://github.com/archcanvas/archcanvas),
> an AI design agent — but it stands alone and is useful in any app or script.

## 💡 Why it is different

Most "AI floor plan" tools generate a **picture**. A picture cannot be checked, diffed, or reasoned
about — and neither the model nor you can tell whether the bathroom is actually reachable.

ArchLang generates a **program**, and then lets you interrogate it as **facts**:

| | Raster image generation | **ArchLang** |
|---|---|---|
| Output | pixels | a `.arch` program → SVG / DXF / PDF / PNG / TXT |
| Edit "widen the bedroom" | re-roll the whole image | change one number |
| Same input twice | different image | **byte-identical** output |
| "Is the bath reachable?" | look at it and guess | `arch describe --json` → access graph |
| "Does it match the brief?" | eyeball it | `arch validate --intent` → exit code |
| Wrong syntax | — | **errors returned as data, each carrying its own `fix`** |

That last row is the whole design: **`compile()` never throws.** It *returns* `diagnostics` with byte
spans and a machine-applicable fix, which is what makes a tight self-correction loop possible.

## 🤖 The agent loop

An agent can author a plan, correct itself, and **confirm the plan matches the brief without
rendering an image at all** — which is what makes ArchLang cheap to drive from a text-only model.

```mermaid
flowchart TD
    B([Brief]) --> S["<b>arch context</b> — the whole language, one call"]
    S --> W["Write <b>.arch</b>"]
    W --> C{"<b>arch compile --json</b>"}
    C -->|"ok: false"| F["<b>arch fix</b><br/><i>each diagnostic carries its own fix</i>"]
    F --> C
    C -->|"ok: true"| D["<b>arch describe --json</b><br/><i>rooms · areas · adjacency · access graph</i>"]
    D --> V{"<b>arch validate --intent</b><br/><i>does it meet the brief?</i>"}
    V -->|"no"| G["<b>arch suggest</b><br/><i>candidate door / window statements</i>"]
    G --> W
    V -->|"yes"| O([SVG · DXF · PDF · PNG])

    style B fill:#ede7f6,stroke:#6b3ae0,color:#1a1a1a
    style O fill:#e8f5e9,stroke:#2e7d32,color:#1a1a1a
    style C fill:#fff8e1,stroke:#7a6000,color:#1a1a1a
    style V fill:#fff8e1,stroke:#7a6000,color:#1a1a1a
    style D fill:#e8f5e9,stroke:#2e7d32,color:#1a1a1a
    style F fill:#fdecea,stroke:#b3261e,color:#1a1a1a
    style G fill:#fdecea,stroke:#b3261e,color:#1a1a1a
```

**Cold start in one command.** `arch context` prints the entire agent context — language spec,
workflow skill, CLI reference and every diagnostic code — as one system-prompt-ready document (the
same [`llms-full.txt`](https://archlang.uk/llms-full.txt) the docs site serves).

```bash
npx @chanmeng666/archlang context                       # EVERYTHING: spec + skill + CLI + error catalog
npx @chanmeng666/archlang context --section errors      # …or one section of it (the catalog alone: 60 KB → 13 KB)
npx @chanmeng666/archlang spec                          # just the language, one page (~2k tokens)
npx @chanmeng666/archlang help describe                 # one command, with worked examples
npx @chanmeng666/archlang compile plan.arch --json      # render → { ok, diagnostics, summary }
npx @chanmeng666/archlang fix plan.arch --dry-run       # the exact unified diff it would write, applying nothing
npx @chanmeng666/archlang describe plan.arch --json     # VERIFY, without an image
npx @chanmeng666/archlang validate plan.arch --strict   # the ship gate
```

Every command takes `--json` (result on stdout, messages on stderr) with deterministic exit codes
(`0` ok · `2` user-source error · `1` IO · `3` usage) — and a typo *earns* that `3`: `arch lint
--jsn` exits 3 with `did you mean --json?` rather than quietly reading `--jsn` as a filename, and
`arch comple` suggests `compile`.

**One manifest, no drift.** The per-command help (`arch <cmd> --help`), the flag parser, and the
generated **[CLI reference](https://archlang.uk/cli)** are all rendered from the same
manifest — which is why they cannot advertise a flag a command doesn't take. `arch manifest --json`
is that manifest as data, and `arch <cmd> --help` is the cheap way to read one row of it.

Reads are bounded, so a big plan can't flood a context window: `describe --select`/`--room`,
`lint|validate --code`/`--severity`, `context --section`. Filtering what you *read* never changes
what *gates* — the exit code always weighs every diagnostic. And because `arch fix` rewrites your
source, it prints the unified diff first and takes `--backup`.

See [`SKILL.md`](SKILL.md).

<details>
<summary><b>Machine-native artifacts</b> — Plan JSON, a GBNF grammar, an intent schema, and an optional MCP server</summary>

<br/>

| Artifact | Use |
|---|---|
| [`/plan.schema.json`](https://archlang.uk/plan.schema.json) | Emit structured JSON, compile it with `arch compile --from-json` |
| [`/archlang.gbnf`](https://archlang.uk/archlang.gbnf) | Constrain a local model to parseable output |
| [`/intent.schema.json`](https://archlang.uk/intent.schema.json) | Write the brief down as a contract; gate on it with `validate --intent` |
| [`/llms-full.txt`](https://archlang.uk/llms-full.txt) | The whole context bundle (`arch context`) |

**MCP server (optional).** [`@chanmeng666/archlang-mcp`](packages/mcp) is a stdio Model Context
Protocol shim over the library, listed on the official registry as `io.github.ChanMeng666/archlang-mcp`:

```bash
claude mcp add archlang -- npx -y @chanmeng666/archlang-mcp
```

Prefer the **CLI** when your agent has a shell — a CLI costs nothing in the context window until it
is called, whereas an MCP tool schema sits there permanently. The server exists so MCP-native hosts
can *discover* ArchLang. The core stays zero-dependency; the SDK lives only in that package
([ADR 0012](docs/adr/0012-mcp-shim-discoverability.md)).

**In CI:** [`.github/actions/arch-render`](.github/actions/arch-render) renders every ` ```arch `
fence in your Markdown to images in one step.

</details>

## ✨ Features

<details open>
<summary><b>It draws like an architect, not like a plotter</b></summary>

<br/>

Poché-hatched walls (by material), door **swing arcs**, window glazing, computed room areas,
dimension lines, layers, line weights, a north arrow, a scale bar and a title block. **Real drawn
symbols for every catalogued furniture kind** — 129 words across 83 families, the bathroom and
kitchen fixtures, the room furniture and the garden beside them, each with the detail that makes it
readable at plan scale (see [Furniture & Fixtures](docs/furniture.md), or the
[`furnished-flat`](examples/furnished-flat.arch) and
[`garden-house`](examples/garden-house.arch) examples) — plus the two **drawing-only**
annotations a plan needs above and below the cut: `roof overhang 600` puts a dashed eaves line
around the building (an exact mitred offset of the wall ring, at any angle), and `void` puts a stair
well or an atrium on the floor plate. And `dims auto` synthesizes the dimension strings for you.

</details>

<details>
<summary><b>It checks architectural soundness, not just syntax</b></summary>

<br/>

`arch lint` encodes tacit professional knowledge: a bathroom reachable only *through* a bedroom, a
wet room that isn't fully walled in, a door whose swing hits furniture or another door, a windowless
bedroom, an unenterable room, a too-narrow door, a bath/kitchen with no fixtures, and a room whose use
was merely *inferred* from an indirect label (`W_ALIAS_MATCH` — with a fix that pins the explicit
`uses`). All tunable via the ruleset.

</details>

<details>
<summary><b>It models how a person actually walks the plan</b></summary>

<br/>

`arch describe` runs a clearance-eroded nav grid: per-room walk distance, the **narrowest pinch on
the way in**, and how circuitous the route is — with advisory lint for a too-tight
(`W_PATH_TOO_NARROW`) or roundabout (`W_CIRCUITOUS_PATH`) walk, and an opt-in
`arch compile --overlay circulation` that draws the routes on top of the plan.

**Facts and advice — never an invisible auto-arranger** ([ADR 0005](docs/adr/0005-no-invisible-architect.md)).
`arch repair` is the one *explicit* corrector: it pushes furniture out of walls, doorways and swing
arcs, and emits a change log you review.

</details>

<details>
<summary><b>Errors are data, and many carry a machine-applicable fix</b></summary>

<br/>

`compile()` **never throws** on bad source — it *returns* `diagnostics` with byte spans, a catalogued
`E_*`/`W_*` code, and a `fix`. Where the edit is mechanical, the diagnostic also carries applicable
`fixes` that `arch fix` applies for you. `--error-svg` even turns a plan that *won't* compile into a
self-describing error card an agent can look at.

</details>

<details>
<summary><b>Parametric, scriptable, and still deterministic</b></summary>

<br/>

Values, arithmetic, arrays, `for`/`if`/`while` and pure functions — plus **relational placement**
(`right-of` / `below` / …) and room **strips**, resolved by deterministic topological arithmetic, not
an optimizer. All of it expands at compile time: no runtime, no clock, no I/O. Optional metric unit
suffixes (`4m` / `40cm` / `20mm`) fold exactly to millimetres at lex time.

</details>

<details>
<summary><b>Five output formats · accessible SVG · IDE-grade tooling</b></summary>

<br/>

**SVG**, **DXF** and a **TXT** ASCII plan with zero dependencies; **PDF** (vector, selectable text)
and **PNG** (deterministic raster) via optional, lazily-loaded add-ons the default install never
pulls. `arch compile --accessible` stamps the SVG with `<title>`/`<desc>` + `role="img"`
(`--acc-id-prefix` renames those ids, so several plans can share one page). Add the
library's `annotate` beside it — `compile(src, { annotate: true, accessible: true })`, an
option the CLI does not expose — and every room, opening and fixture becomes a named,
focusable control (`data-arch-primary`, `role="button"`, `aria-label`). What the embedder
still owns — the roving tab stop, selection state, and taking the controls back off for a
read-only render — is in
[the language reference](docs/language-reference.md#keyboard-and-screen-reader-operability-annotate--accessible),
with the known screen-reader limitations beside it.

A full **LSP** (hover, completion, go-to-definition, rename, signature help), an `arch fmt`
formatter, an `arch explain <CODE>` catalog, a self-documenting CLI (`arch <cmd> --help`, rendered
from the manifest, worked examples included), and a
[VS Code extension](https://marketplace.visualstudio.com/items?itemName=ChanMeng.archlang).

</details>

## 🚀 Quick start

```bash
npx @chanmeng666/archlang new -o plan.arch          # scaffold a starter plan
npx @chanmeng666/archlang compile plan.arch -o plan.svg
```

Or install it:

```bash
npm install @chanmeng666/archlang
```

**As a library** (zero dependencies, runs in Node *and* the browser):

```ts
import { compile } from "@chanmeng666/archlang";

const { svg, diagnostics } = compile(`
plan "Tiny" {
  units mm
  grid 50
  wall exterior thickness 200 { (0,0) (4000,0) (4000,3000) (0,3000) close }
  room id=r at (0,0) size 4000x3000 label "Studio"
  door at (2000,3000) width 900 wall exterior hinge left swing in
  window at (0,1500) width 1200 wall exterior
}`);

// compile() never throws — errors come back as data, each with a span and a fix.
if (diagnostics.some((d) => d.severity === "error")) console.error(diagnostics);
else writeFileSync("tiny.svg", svg);
```

**Also exported, all pure:** `describe()` (facts), `lint()` (soundness), `validateIntent()` +
`projectSubscores()` (does it match the brief?), `repair()`, `applyFixes()`, `suggestTopology()`,
`renderAscii()`, `toDxf()`, and the LSP core (`completion`, `hover`, …).

<details>
<summary><b>Develop this repo</b></summary>

<br/>

```bash
npm install          # one install bootstraps every workspace
npm run build        # build the library + CLI into dist/
npm run check        # typecheck + lint + the full test suite
npm run check:drift  # every generated artifact must match its source
npm run playground:dev   # build the core, then open the playground
```

</details>

## 🖼️ Gallery

Every one of these is a real, compiled example from [`examples/`](examples) — and every drawing on
this page is **generated from its source by `npm run gen:example-svgs`**, so a picture here can
never drift from the compiler that made it. Click a drawing to open it in the playground, or the
name for the source.

**The showpiece** — the whole language on one sheet: `site` orientation, a polygon reading
nook and an L-shaped master suite, a bowed arc bay, all five door kinds, a shared stair shaft, a
void over the double-height living room, a roof overhang, and a mirrored pair of ensuite bathrooms
composed from one `component`. Every room is reachable, every doorway clears, and the three
warnings `arch lint` still raises are left in on purpose and explained in the source.

<div align="center">

<a href="https://playground.archlang.uk/#z=vVzpciM3kv6vp8iQflhaU1Lx0uUjQnbL3R3Tbnlbsr0RExMkWAWyMCoCXAAlSnZ4Yx5in2FfYf_vo8yTbGQmUFUsHi072qMf3TwKHxKJRN7gAdznEu7e3P78w9ubb29gWoiZy9UC_vmP_wYBfmmOnTdWPkOuisKpTMKjKgoBS-VzEBqE9yLNZQYzYcVMdsDnEhYFfrN3AFNlnT_2ao7DnPLGgjf0SCH0rBQzCS43ZZGBk_IEbh6lffa50jOQhZOgNMgnMV8U0p2CcmC03DsAfiAzWsJSFsUX-AF9h48g9jI3RWMGo-lLl0vpT-CutFORSgfKg3ySNlVOuqu9Axg75eUYDqfqUUImrXqUGaRmvhDOgRZz6Y7g__4XxguxkHb8-dilopDjz8fiSTp6m8uspE8KOZM6G8OhACtFsXfAcweegVe-kDApTPrAiL8YjRMX6lHp2amT9lGl8tQVUi5wpUulZ64D1hSFzKBcIFt8jpyIc4IrJ954UQQSrTFzWJjieWY0kZHmYj6VVmagjXkAM50So5wvs-cOCJ3R23fHLhcLme0dwFw4Ly24UnnJmMKmY1iKogCZzSSCTsxSZjARzxUerwBwehqET9-9_Q_IjLHwoHTmUK5oCyUQn30uPOQCXxmYSOJzBoeuUBnyYmHSB-lPJ2pqiux0Iqw-ZTk76sCiKHm7xygPMhvvHUAmp6IsPG45fmOl8x2QIs1hmUsrQcCkVEUmLSxJ6kTqS1EUz7AoPSh_At-aUnscO4-LQslA-sdQKC0dMevZlDCTnpbQgYlMRelqOqIY4oLpUS0fcUarvLwC4R4QUtg0h0y61KqJhOPjvzvcKqWdlyLrwDJXaQ5WLoz1DTSjAbGemaO4LUulM7PcO8CvvsTt-RqEhy8Xxn09ZhYJGE-JfGMWuG3OWyn98VSktFdqMsEDMmVhAMYjOUIyC_koC-iOT8Or3phmdV4oO4ZDJ-YSVAYT43OgJ1wnHDYx9Sw4j0bxWchMOSnkcS7VLPd7BzATCzDImU2igzI8pa9zoWdjOMSHpHiUrgOZFUsd97hcLFBQSUlFqvHUGi21H8PnMF4UIpXwz3_8D8yVtcbCE5HDb2QGC6EsMkBqEneYCJ8jHXyY_qufwLS0WvnSojBMxVwVCgUhtcY5eFA-zaU-Dad3IjMce0rcDMJ66qW1SAOuK1NzB6L0Bk9H2CLWa3OhS1FApuYnewd7B6SZF4XxMLVGByngzYtrf3_74f5NJ-gD0Mb6XFoNuZwrtyCBRzXuDIwnIn0Yo-wie-R_lsIbO0J1PgZhJQ2_u_7-BkjDHzpT-vwoSqFysMyf27vEml7YlDQAI7NsBhZEImfCZlLDhLSMeODJaAaYilRkslZAgV1BA9IQ1HJepA8ORGH0rMGEk6ixURwcaEN24QvU60YXz6yyIVNWpl4Z7U72yCztv4mG7Cc0ZPvw6x5AqZV3MJ_vAcysyqCbJHsApOnhuoemJHOpWMg9AFL70L0a4hPEcigXewAr-0rPBd1MorQHwFZhD79CKfs17iVjNPaMP_gNnzyA61pOf7h--2GjnHZw3pyeMTqVJ1Hkw4OHRyAcfIn8QOVAsIdPnecj-Gs8EH9j1SO0V8KzbRSOzHuWWemcmKDFMk9wiHwyS82W4HNaHHwOPrdSEvCS1OITHhZ39AV7A8JK7SEtvWNdTFR9xjikyCbPgOrBe5mBlWiodIrWn30FwmXyUhxGUx-Ope6d4MtxB8ZS9_n1EUk8CQmqJlIETuH-Q2q0tyLFlRHiuHIt5qWT5fyY7OwJKubxCbw3TJpyQd28fX_39tUNQVfqBUV8UdqFcfKKDwshxwOAkriQ2vFKglVgbnzmIJOpcsroDvo4qS-eoVDhdCAlnznIcaFIxckeNCattxVFF5gfKvuK_l8I63m9Plfpg5bOoTTDr3CYdJIjOOxeJI0XvbMEX8cXaWGchN8IlpeQfUX_Cx_GO_WLBBz6hCOgEBNZwP4Nk7QPpZOOBJMgDmCstJMeusNk3MEjCuNpUbp83InawS8Nq7FKaq6CGiEZnuOCJ3T-yVVA3yNAG2SqgPs3b7_9y80HyI3zUTRcLlG39oYJzOcwNRak7p1K3e_AeDkqeiPULGPoJY3vR_OjAGxLrVHLNRQOyhKafzwV5G1WuxHEuMtQND9KYFgm-n-ZC0KM2FoKKy0qPklaLzVFoTLp2Dckt0hYtAcnpP5dbpbSwsxIB94sjj-8ff3mPjAoIDYORpQ7ElzSWZHL726-uw9-21h4OB8myRgmsjDLI9a-Ik6FFiQSyz5SgVYXZVkbcMuo_k_omcowxuFKs9wInebk7C-OLZp7AKgkgWXoMkmeLknNNmEmwikNm2AKOUWUNsxZkjwNhm2YZQr87ArMxHhv5oxE-0MPEcwgSZ7OiZqgd7_6M_4I-d3NTzfvoEtiIrW3z-w4XVURVPDKg0ORKRTG0-BmdCD4En8qkcHrg_3X1pQ6g2lhjN0P6uYAjo-Pj4HOGL38FH8B-VZL1kEZWJQ0PJoov3OhNDyaopzLTgyj6vCjkL4yFsGzOGSvIx5pOpcTmavgaDT8mBDppqXFeA_9mZtXr29YWQlwciGs8DLEVKmyaSHHnRr2QWbon83hcDBIkk436aEe9QYOu2f1eyJ5nC7H6IwpD5OymEkHtz_e_3z94dXJihpnxsonL62i5Uc1juqMtwAqZd5nbR4_5fc8afysQVf4CBe5Qp4VmSod6sME0mU9xcoo2hd6TUcE139f-2ylV4XyFD_MrtgfIGfSsTNGfsPUlOjZkPMVrCFtLK2YFWlkrHSelGQHGRZcu9oW-6VK5dEq25YjnHqka861WQeHx8NhMH7072-bAJYvA-BXgX8bgdzHgcLww61AyFWAzUa9CXQWcc4CTODjdxg5HJPrXWE4OAyeJ27EGhfNdKpSOZLbpmVfYpAEPtCLwUbiF2aZSTta7ka6iEj0orcL6SM0dZMIxa82Y3Ew9ZiO3EepYoBwqDajkQIfuccUXop20WRYc5tO0c3hMMktlF4NizKp29vY3riiS27NaLmRkl70AQcbyNgMJHcBNcYHBm0BU4-jDE36LiEe1OP59ZbjkCk9elD-BQLVXOXFViy0pTsJa4zn11sIe1A-gG0888kaGLPsYlUMyK6GiG5mTbmQGds1ikwwSgqpwt9rWH-hlEyIqvfvwgtE3a8sSuXuj1ijA_n8lcKLjhK-f0ItE13_1_T0PrDrz2PXIKN1qCFZUdWQqEci5I_8dIgmwtg1TFYKTGZUIhWZaMqeeg0yf6CnI5nLdB1OkC9GcJUmiXD9izYcPR3hMPsUlx12k1ge3Iz9d_z_KsPZfJKzdwWYKU690LNCsrOA9vLuBlJjtbSN_K3iqAfjCoTEdC4qigrz-v3rdzeveF2PSrRzweTsaI440WeXlCgQVopOWJrwHOOiZjMqO1ljFBuICBm-rjySVcPQH5C093v1kQwvqnGBoXfIh7DjPMPaxOws8w4NWhuE758GvWZEyvsT_wiYEXJO0KyCh60KgS7TWoHj7p81BJT3c38VnBHWgNl_D1TXeo7FqtcCfkUPt4AZYQ04RAS1_DeAhxetI_UXfnh_BTggrCHHdGWFfNFC7jWQ7_nh_UoCv2E3mw_cKR-UDgoslYnIV6bNYfE0tQll6ZypR0m-obIUyDoQFTRWU6CZWzQYroakpeC4l9ICE2Flh548LlADUwAT8vBWzhQWNzAtUyFTLjNN8dmZFYu8gzE2zmHKGR5GzJ4_UOrpgXJhYX6q6xytn5GoaysO9nZwMOrjN6IowgmgzA8GG2Uh0DKtut1kJ4g3V5Rsp9IAZcGVL-l5-GMBGGe8sq8y9pIqMcRlnIUTt1SZz6GLR43sH4crVPoAiqw5R0B6KpzZFnZQIA1sOs3Ikgh_GdEb_ui2KRraop4j2jD-C-_I-vTOh4119JN6Jo4fNgKNFHODtcNGSpt84JTHS6mMXj5XuVC0guMvPCC1keXDJKkwW0DBRo7kkw9U8jqr8LPF1BCgrFNrSt-CjmaW_7ggxzQ2PGnh0fuKlF4goZjWYug2YDC0_Ic1vU1w_csK7nL7utHvSo0N5BFM7b0i-2oUktit29NUhTV87W9W8PEjBK9XTIt_IWDUrg3P5XLzLlUu6jbRr3NBbabUk4RSKlNf-anI4Zr83qDaMZykhceGbRTqOIHoVdHqJh9RByhXBIsJcVpB9pWpggPeuPBmlbNI5frAOuyiofXbVUHEPPW2wcEur8jMEsejO9rgy4rSDdXRK64uby6dYppipeb6EaWLOS6Fqcrk5KRfeYcMhuQxR5HtSNjnoODfoNuteX8e1hhikvVxXWRDQ7pafwfAJ3Lr8Mtk9RCtjY-eyKEUIQd_tA2s1_2UYA0R7g42gcVj8AKw7nmyi0twgL64VZmx29AqK7l6NC5Wj0YFxwLYCQlLfGJF1Opk9ifMsNagmXQPbfve6Z2T28s1njNOiVMSvWm-aoxgmtMcC-iIgRvSQZ17VCfnsUq0A2OCflUui2mkA0OFfpuOfouOFogtZ7C2mGFSg_QpHBxElIar3qhgmKkYFU2Uc0Q5q1EQ4InM8HaU1EynUo48eYkcTCJTzmv_D0_A07DiykYUYefM1YoWCqGG58OIguWTi2GCTqfH_HTvfBdVWPledeeQqMGgXtvqVm0GUUIbaKMknYvzem0IQ-f6RWT5xxFW3kHMBJaxot2rzMJ0irUeOuVNkLYo00EKLCc9idt_dlFRRcmAboUS4qm1jSu1rx2dFZL45Do5o3JkNxI2IM-k2tOzOEHT9tcThE9HTumHF06AocIuSOfNo2zsyAsgz4a7ITPl8qVweeDESyDPu7shp1ZltS_-Msjz3ZDU9DNKxURp6WFNfioXMG7URxatHFZLVyT7ks7bIFkpeV_uhpkI67wxRQPm4hJFcVjBDDguh98Jczn8JDDdpLsZZwWmXUtlaWjxONRKolRVgtrM1jWkyj5Tqm4XxvmgjbGxqEtPhKBka123VdNdrzBvQGnWqhsoscDcVheCTd4x5XTOV-VkUKmCRj50w1iylx8b2z7zpR4VptQzySCXtQoOKJdNw90MEbaDdFFnryjyjSAcGKh5lQxHSTr-uio7kmBFkUgS8BiPxgwRDE8u4Al6JwnM9xmK2gip5umjC4E6NfghrLt7UXdnynKn1b-oQt_j5rnYhRuK9Niv4mRqdCbsM3cyuU4oZdYts7GpYiaKgls1DupWx5U-yGYp-l9Q0-_B_o_UMPnnl_Srov57ExMw1HHCDTRTY_zCYloFOaUNdxFODLWaYD58UWBpODYDxOR4hwvoLrYXtbpEeQIKwJzC5i6YK099cSyUlFqP5eRQ8sdIWk5LJ39PGb5dgF8tvTcqurGjqsnnRin2U3K6LkdNZNYbOdjdDBZavzj3dra5dqfRX9kFM2w0kV1sR5rIrP8Rgi4bSKHiupko7t56UZFzV2EyHM3dVc7thclGXS1qiP27Zsf-psoa7kuVRQzlqkb9otlR903o5erFnjp-v6FuoaVmyOFFrInUmrMJ-Q4f3a_T_82qVYvKfvQ7ViG3UtnfSOWGLlSpe836za4H-ysUxE7VvZXqWVPnXmFh693x3ZvrH25eteteSysWtDWxfzVMFnucXdQp3FIX-ql9mnPjuc-VzTpQ6rppvOpONNNWvym2BWJPDdUmfN4ozk0k6R1BeocqIVHPVQpuvZYQ1rhWb2vKJprv1huOf8IRWHkTddRgrVeoqsZ9z3PecVNniIWTzjkZ-Jfu9IjbRhu0NcsYDREWmjKUIbl-VjshVHbtNkWYH91WJVlpS6LjfYW1G-z8RceT9gmvI2y8dsDGIxgYeJBy4aK0BNxpWRShlIQV05USkYD-SQJPMDjpwRzoApKZOG_LNHTuz1WW4YdTvGey1664E7ErxcfNlcfX_ORHGFAXiD6hNV-rEbE2owRqNDgxd_vxzD0rmTi4__sGs9ILWWO2UZTnrAefV4NjReMAfqDaBXf28VWdK-5Hjw31ynG2Dht5MRceGw0lXsgRNrNmIkNTjooeCBK1RNcFd8LMF9I3-xZJKVRNwYJJYm9STCEXeG2BbyZ5A2khhT1pLRUVZrPsErveiV3nw9aKtxZdUJ2uwvT_GMycCyF4uhlg0_gtpSTWZFyw4c0Ltpyy9sMd1RQeuZ7KjwdnDW24WgMIm0XWR2dsXApnCCxcESmeuXQcLieSRjrkMjTai7vbH-_f0FZ2oDCpKOpm8eNC6pnPYdhPkiPSHyRV3PotyBfNhZXZ6azEtkbsjsePl5R4plsWQQBP8CLDaD6OoiULNZHYfVo8N_TR7fsb4mmn7nkNJqK-eFOw4kOrFm8LBguE19_4dgE2mof2kuAWs6TiVYlapcRIJkwRj0os5-NUe7GEbkOxnC1sdQvChUsT-lFqhBQFpMLJ2GKbyalMPXfN0624QuHFLbqJCioe3sPxz6Nvru_fjH56ez365ubVh9vb78dHVYscXe2hTnW6vKL0yQqYFXjLEzS28C-F1dRPpaJeFwUGdni9wGj5BYx_HiH66P3t_ejm33-8vr_9MPru-tu371-PkTlhXQ5YlvroQqCPT32usQY0jTH3AV_n-YKedeoJ0X_Addzf3o7eX3_4cPvzmLsJVGhTCBcW-e4onad5aOk_PBskfEmJyhGoLo5O4Du8RykoUVM8OHYryGcxi8o3wfA6KLuJzD5zPBivDUCKttA1Yqqwvsb9HJLp9rKrKWNTUtx_PjNBUBzJTzx-DWVL93ieUTjD3V0m1cnmil24BaGefB7lqOmafBZptqb0pENR-CrXLlI0JsU15ttISHK8hNzEwqFYhlAuUiCi7CGoFtaaJd0nZY9xLmVl2bWal3PiEtUFg9SjBM_Q0SNjIHygMtzx3KDoK81YKXksR_YrVbZLt0rdbwzvf3z4hrLmp3cWNtXZerWxCEW7-sZUrxNuvy1jj9bGeuZZu-xXI_S3IVBZqOH-NkvfK-W5g1Ymp1Gfa8FR7i6GcQ16WnDBSHW4q_1PL_RtKPZNZNbMAvewM2RYJwyHsSGJkn3oy7XGa3QF8JpRVtXFGuMHw5CM3jq-cp5CiQ9zfP1m_-cT-V2N8bsXgM4CU7BlAf3dC-j2zpImQLWCbeNbC-j2uysrGKytoL-jREmSSJnfuryAjZKNAmXD32kk0SlviOi8C0jD-dlq9rjmwkaIFh-wEtCEaO3kSyAucSt-J0SLm8OkqkXWC6lrkRshGgVSgkBeXCbJWnV0DQJv1DabZ2OwT52ES-XkMfYOAlX4g3cUjOi7qArC--i0faywTvqmc96t19dr5tY3Lm-tsk7uced8W2k9gKzHv-j5FBRwUP9ihia9chu3JqJDHpVjFr7AX4U7kq5ag5VZmUp2WxruAsXFh-O1HzaIv2SgPJQaiy6E6v76t3HonqSwXGVfPa4Ew6gohjXn-rHLt7lScvquql_sIP_n_s3bu_CbAIGwkEgmrdypssKlR1mkhSrPF8mjT0hZ6fq3SDowoZ-IYA7MLOWxMXc4k1U0X2eiydbWZuAPVjsyTj1QwgR_ZSRkFJ9waNKhbFwHKOsK3LHOGRN66Dk8RJoOkGf4UK--4si_QsKIC2v-jj54-248-xh45Wo0eYb9a5vm74Sehc-xvr_fS3pnx8nFce98n5B_2_t_">
<img src="./examples/hillside-villa.svg" alt="Hillside Villa — a two-storey villa with an attached garage, ground floor shown" width="620" />
</a>

<b><a href="examples/hillside-villa.arch">hillside-villa</a></b>

</div>

**The site plan** — the same language pointed at everything OUTSIDE the wall line: a surveyed lot
boundary, nine `outdoor` ground materials from lawn to swimming pool, a posted `fence` round the
water, a `garage` with the sixth door kind, and fourteen outdoor fixture families from the bins to
the trampoline. The ground is drawn and measured but is emphatically not floor area.

<div align="center">

<a href="https://playground.archlang.uk/#z=rVtdchtHkn7HKTLIB1MRINz4IwE59EBbkMSwTGgperQbExPoQncBXWajC66qJshxOGIOsWfYA-wR9ihzko3MrOpuNEDJclgPIn46v8rKysp_nMJdJmH-893r-fwWVrlY20xt4d__-m8Q4Hb63Dpt5BOsxEblT5Dp0krQBQgYDOAR_9uALZelWYoCcu26kBqxK0BYEJ1T-Hh9N4NtLoqX4DIJy1LlqSrWoCxkIl-BXoFyXRBFSt9rl0nD3ygLa6PLIu11TjunMHuQ5sllSCtzK0EVIB_FZptL-y0taWGXCYdkqrAqlYS3E3kOuSpkD-4yZUEXEp_Ar5ApYpG3pCyIxJUiz59AWVvKFITtwi5TSRZIdpnOJWy1Khwyjh899HvDPtjSrEQi7UuIrXIS_v2v_-mcwhK5F-Yphm3pGCHXjthBCeJ7m0npulDgR7EuXaq1if2-YSOcNErkFqx44t1JlELnFOyvpTASNtIZCbp0exu2cP2xC_FKFomMYautX3yrdQ6ySHJtSyMrmVtnpHSdU1gZXTixlnwc_VHY46APnjVYqUeHtKQNSlpYlaZQNqPn1sKksvBsPOHfzincK5dksgiUNYUIX_H53s6uXsPdu9nHGdy9u53N4M3VD3cf4fvZm_ntjL69vnmLD8Dr26tP1zdve3AVBOXFj8d0M78DAUbrzUtQqA2dUxBLKwuH29tAnEqbGLWUcH7-i9VF_I2FGB-3f_9H3PXPOO1EbnurXGuzEEaKxWYQk1Doe9wgKXnnFGKbZDItc0lr2hicWOZegspZQGrIRZGiWlbIXpw1tiqskyLtwTUehF5aZ8rE0Xbe4b7xOlZHqIokL1OZ0qdWQ6JMUubCKV3g-d9bPFKh1pkDkRhtvfKiNn3XOQXnr4kA64STKTz0warNNlcrlRBKfR-DErGcaw5sJQS8kFY8qWLdOWUdxW82OpU5pFpaKLTrwRWJA97ezj99pEP8cPV29nL_SijL1qSSMStmF6xGaOUyXTqIt2IrTcw3gQl3kvaqWPX4Ou90maewlGATkcsUnG6oaA_e4ba8htIdZCVEzt5e3V69ncE18zm_eze7hXdX79_A_A19cjt7P7v6OOux2uBVh9JKi9BiLWOWLLJwr4oUmQ_LVIoiRWrh5C09f0Kijj8teNnF3Xy-uLm6vZ1_imEjhaUro9xLGPfGsPHn2QWxFqgyHnrQu4QN2batMPcyhTgRJoZCytSiSlmgy6ssxPTCs9plKatHlxGz3uhbmaASiLxzCrkUK1YYJ-4l6iMkucDdCQciz7uwlAm9V44WtzD_2-z2HV5mI8iYu0wUYFFPUFW0QVHkCp1ArWapsJlMwcjEiWKdy6YJZ2ZZ5YQD_SBNJkUKW6N_YU578AmtNAIjEXLC31k8dmXh9ez2-m-z113URdgZ5Zz0_shIq_MHaZBiKdk_kM9wmUruC2kt6NWqcwpSJBmQkSGeSRjksJBAuQzIWPTImaZGPUi0gMEwo-CDBQ1fxrT7zilbKZCbbSacSsj_IJuEF9QHRGF30oR7xyJhlZ3fXs9u7q7uruc3vPoWLxSZctu4RcHh3Mxv7951w10ptMEzKiCTG2W3mTTSX7dY_loKp80CN0BKbXXpssoQhYt0543JLnvi26we8JjxarB6eSP_baoKthEkv50OzsVlRkpYypTsJ0mW2ablViIRacNVSfOgEglL_MA6kdxbELkm3HqvXjA3M3g9e3_9_ez26m4Gn65ub65v3nYhlyuyFbqAbWm22sqX9DzAp8XtfP7T4mZ-t5j9x89Xd_PbxZurH9D8PvZp498zlzCAs1w-yBwGL8KRoB5kYqnI_NP2WS0KTdC8m50qUr3rwbzwsRXtgwIRpPdCgEyQ4tai4BMUdiuTOlYiXBQkC24r9TaXYHMpt7g9lIq0DtbStQ5MgkEzhHaqAJE-KKvNE9ryleMTAshkaZR1KuErIyAVTzkZWW-TNrKoOMGIi4WQCLS8qEXBPaycNISI1xaXRWPWg1iYJIMHkatUOFavJJei-K71DZyfW2dU4mIwcqsNqTSHcb0OyQ3NKAYd79Dqn8BvHYCyQMe72XQA1kal0I-iDgC5DbgasDNOxFZ2gJ0D9F_yI3QboNx2AFK1sSBKp4lxkef0cNPTdwByuZZF2ukAnJJYgyfrQcxHFn8b1xcrJneJ8qQgFmWnC7zsYiMhVYZtmf0O4ipuJOSGgm2FocCTgsyY7SGFlqq4Dxd8i8byTJBJPU812cKtNO4pxJ0E-sP5h9v5hxfEhUhTy5C9XLs6JkGNH01GsPm__wW2DMsnjLkTBzbTMheJ7KFYMOBFuUNQVJIjfVDvvvFh2B6cRd3oBZwNBlHUfEX_v8Bv-VUH4HcW8sdM5jkksnBG4m4sq3MzqRAFvH8JAvr93hgeYQqbEBDgbRTkRh_hAjbeiBKuLihWY_bPyWSvclHc9-iQHdzBKxhGEYR_pyAfMTTXpvYTHXoWjUIfTt5yvEQ2_MQLh9yKSl9Z2sQhANz5BwHOBuMo6o7GJIb-9OBNP_LvRtHhuyG_Iwj_BiN-Sdi_77GyW2R9IK1SFDzWvPSjCH6Ds4tJvTS99oAHMIPPwkwHNQy9fgZm93luaEvTqOaGX7dRZP_LzEyihsgmR2HWwhyFGTAMk46OHAQpK7APUOkrs8gQEwBDpqZEwap_ShiMougRNwKQi6XM4eSdyPMTqP9RdEkYqPhPzXC_tZB1ZfrkF2qoEC80GkbRI35QLfQRHz9pLaRXK5XIFrD36jUwS_454Pf0-Mk-MGO0gEunKtE0tMQDT6LocdgE_tmpXLmaZwIu-UPYJS3wkHpW4JOoBT5ugv_oI5XXFKmcMHjA8OHL_gI-NKUFmvpACyD240XzYEPEv8e9N0Mdtitozih2o4i9W5UJ2LByNITRm09n7BbdDdFyhJ--ShdMrwtgSyMcsQI7lboML0EE6IAkB0IUmDMgK2rFSZ0KYWWoBzcaYiKMMSiAGIP46jWi-Nd6Kwt2HpyioePiWG-D6TijzxYIuvjx-ub14of3Vz9_nHE0QWG2kavSCsoy0SxrrCaZdYkxh08ZKSsx4kHmFn7-QCEr4zryNQqzTvhFbJYYR_FuMasttA_uNaUgkmNHWrjQKARpNjJVGHhstfUXP0Cj9_bx_UG2Urnho1kLOuVC5iE5CxlM1wPj8h5S-fgmF8W6FGv5DWckiS4eZEHsrLQBUfhCmFjqB14uKR3FkQfK4Pnwf5pK0R8NxkErhlEUdVqU3phgTQHdhHBo-QLBNIr2VYeebiF4q9FAuBg_j9CwD6dwBVud3EtHR82HHq45516FhkQbo1K8JSE9YDHT0VofzRF4vzeEjUfWK1iib-e7w_pwphwnyzAZR6S6Qe8mUQTbvMSUntRJ5LneiSKRL9qCJkvmmeYdD0jKk2rH-IrVDm-eZ8cbHVRJf0Yhw9qU6TmZGlqD75JwTmAUGp7NhD1y4Lw-vthn4EDkyLPng002SbIym4ajTrultLeuJDWsDl52Akxf6creNrZ_Ua_evwg6xmYOUxdfMUTubZcvf3W_Bcd10vhazrZ0fL2x8Bcv1UrnaUwMEFceuZF_gg5mcovO8jsQbLTQVMFWKFMTQ826J0llct-DG6lwSY9td1JubX398KSooPIRhXr2gvKYosxzuqV8YlRXWWLdisxQGoeiXcgDvBPn_NVJY1DYPgNcSriXW0e5kUHNFSSa9pHT9oAlAnt3fNSvLxze3hYhbhJCNWaPcDga1AdXK67BHJAPkXNZCpVUUUUee4tPL_cP_5AsuP8m2RTjtFpjj1CFaGSP4eloz8cdIWuoZ002aJANgoJah9qBsbrjoG0aRd3xoHLtU4xLUECpMpgv-hM8Pz8_h2v2AfiaPqZyN9XMU2nv2fGrIlhMEEWSYRagt-fkj5EiL23GC6HYHi_9bmqkpdb3uIXVEaSldk5vGKyJ5GOpFlKS4U5DBDYcRlH3IqpDGAyRogiMxkIxYjQW7LSgrF4JAvKlSbKsLGgr1-i8YYzRpZUOBnjGHP4OOPxl4IYPqIFNua45pOwhGlUsEj2K6TMA7mGBNQECGFP0OqjjQDz1R1SCPYAWwg7ds_ns3qKwt8thYKYyrw0dME-I84eAJv3PAC2FVcUfBJpOPwO0S1gn_whQP9pHakH5C7awWI7Yw6OkzINcVLL2z7f1yGFQA0e4aqLUR34cZWVUupZfQsFc5nMoHPUvuKhHUX7ECjipFJCu6LQN075m7IvP-uMRWpJpTY2mZFRpTFWT2DtqlTwlYf0JXdHaFOHq_csWfdMeoav1bbLKJp36B24wAgq9yy52AuqeIwb83JQRvppbUCRftaaCG2wE7rqQjWCZOkxYYDsXO4wlMuHwGay2C3AqBPNb4RyWoH2obLEcRlub31AS8vHdbHYHIgRMVKzD7rJydZMH45yX46juRrDzTdVGFhbDZoUVHrAO_bderZrdq29CTmLkShrqC9V0zR4G0m1UnivqulqKJH3lyQdDvsSv0lfrBdX5oe4FcI445koXORlvYVu582tPcHIIuRUuA6xtsPsjSLQ2AdGr1MhDHgJQZphDjv35qiDBJr_B0wXm88NRg6c3lFEi2ckzoEvKPhyFkA7OJtMGKm905EGfAZD7AH2MHQICb-syABwVjNIA_o8vU1xQnemyVacYDhv7-oAER7aUowFrCZpigD28QcA7cvgUWIH_0yhv7DOEPnkwbR6-TO6PHTz2XIE7uAGuP2a82pZgAeJx2Cw4fNA6P7Y9Pv89NRhTde9y1HCMQ7Qt-F9V1jmuAE_CpIC1dszH96TfhBtGHu0QYCnThYV9BSCAQb_f4AdzicdnAXYtgObxNzRoEj0HIKGtgpMaojbWk2g_jWkNVXALNaZMNAbqnjeGSKg_LphmKYxR1NPDhIae9AMMoS6AtQDq6OcvMd-tSpBUyNjqJMNSkIOMBjwKXSVjPHsAv2hV0OciSbBAzahrI7YZ9RUPRiGqHotyUBaYeXH7H0cjuEiCZjV8RZMmf_9H3IOrAI1BorKQoiE1MsV-AXU3mlZ0Je75m1w6ljUnJLgLTr-UY3PqRZK-WvEF4OyeSq-NUvRZf3px-A7N4ovqSX5HVXBf5uWzC2W1au7Ft0V5Csm6p1xi-xxDkq0FzgW5x-ybl2SRQz8ueD710DzyTO_wxBUVBnhLGynJf1I9F4sJB_v1jHmq3-AMwwa6TGeX_fDy90M_z-n0gZ9_o0vjJKY-vue6k4V7Oid_HgZ7_EAPun1OTEMlLTby11IZaT-JPI9fBgrbSFu5aM7-Wz4mclsPkYhqZMg6UXCXhoW8UWmaS5_VoilSzTy-0GYjchDGiGJN7cY9LRLYWxGO09YgvypiCuM1ddw2QHfSH40OwrYWZblZGpnnAirDOJq2KKdHCZfLXxsle2-A9u3zpTdf7Xi3LBa5Lou15BiRFXjU36PrH67YputHzxK2KbGC1OB0QFuc1oTUk-gfyTtVsbfFAd-ui71o9OKLZMOLP0SW5HgPLbUt69UmjdxvzKlbi04-LJJMmDUlbFVlfhA1HeXj8IBsI1S-1I_1-SGXTf8RyNrZpRGbra64nNKxX9YJwjC45QM6KZvq0qfdRa3O0GD0JULyst3-pHF8KM_BEYHqQq3qCAIlEnWxQlRdChRof3xAmMkql2r45kHbNx8S2syUy5pwWq8Hn7tMx8guB3-KbDr6WrJB1G-p59eQTf8c2bCW5R_b26im-gqyvo-Kj632e93BHsDJG2Ws-4sa2Ec6pV_bpP5retR_TYv6L-lQ_6kGtfeNJ2EOqX-CY4rkTIUqqvmh0EGoZtNo8lrkiS6eKJ7BMrXYyJTq1MoFV16Um6U0e34W-yCGuiW6Ma2FE4w04A1W-jEg_z1nCitVNcM8dOinkEKF0TuMI2nam6LUFeaYmFqrxHZ5NIY6W6gW6flKmw1I69SGgsxQNI-dfHTnnqrnLE_VwclPDXmcUOSt0jp2GPUmsOEeAVUO-lHUa3e8fbDS6tm3WvZVYkQPn4SebnMgN-PhoSb2UqYDOGzTt5rpHruaOfMNab-pQ8jhHuQ0-jLk8POQXG1ot-ZbnfkAKVzGsvaQwg_77LHY38ObRPt44yMs9lsshsKVru0Pha98j3CEh36sQD0Wya1RbLVKg_0W2fNRP9a8lzLXOyzMGSWbgSfVn1Q1uAs2EytX5W6cU4UeLWlImCxujPy0GzR04McbqZN2Tw6fPSQfPtNFPUY-bJPjQX6mJblHHs5tb_X-My29Y6v3mwME31-9_2F-81-NQV9NHkM4uKdemsIO71rkOCFez8h6WxWDESq3vpiHMYiH9pOVbFHRytU2dCkzxekv6kA1ish2a4X_oVWyXUglJmop7ghrlx4ZF_mGTdVGpfxLD0rpeUjb72dxM6f5hRhWiiqBaFQ80xVzPhtvsKzwsYPpYhqIpB-nhEYctT-reWeGIbstcqtx3s5SFbWRgDWVD3_QgIWn-LDuEFgsbfidy4Gm-ieO9QQHw_FX9QTZzO2NHFzWrb1nOoJsdZpEk_GX-oFs_PZYpZbH5xcic7RH1GiW1r3A_TqRF0_4S7Zs2CoTjaglNWkaR3r65E80F1O9K8KFol9AoSWENf6uIm52NWIe1I19ExB_lEDNv_hl9VzsVZ7TdPz9kKt1qDQFvLmd_1Sl85X9Q_O51Fjik_gjlnIL_ice-BRdW14Tizoy5WsdCurYNkQfGJECUvGIMgkeed-WlIg63VDU-NPizfV_3v18O1t8f_XDj4u7Oc1kx-0Mfxky2M-0reqO0zh0GynrH1R9NTJX7U6fSfGnAPUDjRbtQWv2MMcq8DZQqaMRcE8bnnPM3cZ6_T-xs2G1s8tqZ5QsRg3kwZd2NnhuZ6PjhYqv4gyL489xNnyuMV498LWcCZe5cunpuSZXtdXJPrX76pfH--q-qXqA02yqN3EuOLJ6pqX6HAxz1IAZeW4apUkpHqSt5v9QDj60ocCYI3wMQjBfQ4tPxxA3f9sYZscofu60xpaNN-53764_0sh4l2dSuKwbhx_5YKIgZSrTXqgv-qE2q3DwLYRMzBnqfIinCs078EPnq5AAVGH2isfgRLGGcZ1-OuXyMEzuf8PTmvBnf4U_vlssn-DkyiTZe1Gs_eeYG5wMosHFeTQ5H0xOCPf3zv8D">
<img src="./examples/garden-house.svg" alt="Garden House — a two-storey family house on a 22 x 22 m suburban lot, ground floor shown" width="620" />
</a>

<b><a href="examples/garden-house.arch">garden-house</a></b>

</div>

<table>
<tr>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=jVfbjts4En33Vxy4H9pG3B3Z7UvSQRbIJD2YwQZYIJnZeUxoqWRxmyYFkmq7dxBgn_YL5l_2fT5lvmRQRcmW3VlM-qVpieewLqeKpQu8Qe62tcojQmwK7aBq5eOWbMQf__kNsSLkyjqrc2XwxufVe2U3oL3a1oauBxeDC3mqI-Wx8cqYRwTX2AKjWoVAAZ-VzysYbePn8S3ogfwjvHNbuJpsgCtLKORko1cGlTJmMrhAcHLyWsUKOsAyDJ5UXlGBWHnXbKq0gwome3WyvWzYDLK5cYEKKFsMLlDqGKnATseKmQxKvY-Np_CKN8A6FM55GFIlwo6oDnA2OpSNt5o3XuMjmfIqdzYqbYk5R9ZBb2vnYxizzTpKNLWhgNK7LRSCthtDKDVHqzbKYvgxBXr63Ychfh0AjdUxYLsdABuvCyyyARByZQjTW_lhnY8VmnowAC5wt4_ktfMIFRmDZ-CM6aidDdf4qSLsX8-zLEOhH3TBcWtskPh8__P796hIb6rYj7CQ6oCdMoYKyYgYz--NftB2g1CrnFKQvcBzZ5qtRagN2645UG0q8FyyiOfCfT2A8II6oxErnd9bCgGzLMOvGGWTbIzRKst6i2WW8bpbSCbxpSM7ONwjmyayeUczP9J8M-4mnbo6rr8ZOp8foWn9hbMlEdHFa_-pjaSKrcPpL-h_E5hgz6bCqDUZDN-nvc_xdx3ziuwQDZdSS3GfHp6wr6lgOmbvItCxsyP7mx77dylRQxz_hL5N4AmvpLLHm6Jy5J3Oj7w_KGP6pC0tU5zaymXa40zh6nEue7aqWH2FU2SbioEbh80pafDrkhUnjLb3gSu03dbJlYu_q4RroWyj_8d_f0tIHbhDKW4l3LP43SjXPm-MEkFYoiKcNJDxq_4RQsrHiOPcxLChCJXakIC45jpL2Qh5CHC8ik9bpW0br5ujqHe6iBVLMDsvsErbDcFQGYGwY3M1i6WzXRevXV-NKa-rI-fLLDsX_blJPbkt5wdZJPiLp_DWpNQ6kkmuiU9Ie7pYHnTxV6R9P5mUC1bbwu3aUpuJaUAXsMV5wE4BUsC86RDh2TcAFrMjYHUw9QAQBbS1zO0Yyji7kYyn1s7bb_muuMfv_0PuGhvJ8zJE90C8KL0uNoRR4dXOQgWEx-3amTBmuRzuqK43fBKqVjGT2YIjIAX2InWaE0x3HLqUsssJJJjlVzDJLvQwLxd_hWldOGJmq6fnLLJBvwifHer0wDPBPdURuSHFhSNRFB2JBsJpPIIrVYrDIpvMbw6NhlWxF6G3jeajK9XwBCoaFzHeJIW3UBbHfnbaT4fJaO5Wydh2tvh_tl4G8MTziJo1PzpzgXUs_UxIu74wvkWo3I48tJWHpfLInbfkJ1iroC3URmkborw91MkEv7yFS5Dgmva-F4F2E57UUKy0LzojxYsQ1WOQvsHjwqNreBSEymOT5rxINbQNuqDUOHn2-OWt9EubV87zrOYOdJchHQ8qNjRJ41KAdzF10dH0RSYG5TpE8raFCnHCscljZn939-HHf969e4XPpWlC9RlbUoHD3c0tKsrmS55MLHmUKid4FSvy_NYeiMVNT3lUPKVdBhlEyRtt6WgmOzDLsu02DVyXcqWVV8c54DChWrWl4kyAKWXSKaVTHC_Ql50E-XroZe4Oz_BRHAgYpQSPT5UpyRZObjyT-fykhuaLxLlW-X2XgOq8nR_ZdrkUpLZor-aUPKxdjCxlDvFhTtmvsrZA3-kt2cCZC9Gzam9TNKUJBqi1e6AJ3AP5rhXaGKA8fxykMdVTSZ5snlIx2unI0Ryjdpq3Bh072a4bbQptN5cB__j5p7sPktCA0f711TTLnq-mWTbBY_qx5KmslC59cZ66cZdOMUeM51QHVrqPHFB-KaUhkuFL25MquCB3yhcTIU25rt09NygJ8mH26AwVIe8qbSiVXa0sH6KN6bTaV1pb6L0ncilz279p_6_a_3L3y4Sgt-3VzV6Pr_42alecS1eWgSJmiwyR9hFD3jjsUKs-6kjxFHXTR2WTZQtJA_rZWXytJtTq5KxpN7AwcHqYTJ-gloIaAFFHQ_JdBNTe_YvyePhketN9mw7ltdyFn9aPGPIn6FtlH1Ro36hIGM6y2fIqW17NVvz0y-DL4E8"><img src="./examples/studio.svg" width="270" alt="Studio one-bedroom flat" /></a><br/>
<b><a href="examples/studio.arch">studio</a></b><br/>
<sub>The flagship: fitted kitchen and bath,<br/>an enclosed bath off a central hall.<br/><b>Lint-clean, and import-free.</b></sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=lZfbbuM2EIbv_RQD78UmgJ3S8iHuFltgW7Qo0Ba96N7HI3EkspFJgxxFyS4C9CEK9IH6Jn2SgqSkWDl4U99Yljmf5viTegMfgFs7z0k6a_eAB3S8J8PQalaAUJBhhzUU1jktrbuYHGo0MP3Y2vl3ndGPNfIUPk8AGqPZw34_AaiclrAQYgLgC6wJFu_SL2MdK3C6UjyZALRY16Dl-_bKK6prAKBbJqetA2Cli2tD3kO2FvAZzsRMnMPZQghxfLUVIvzoL4raeoL7Efs6h_gJ4WnW1hyxFyKyVz00XqwjagzJ1esgybZz7jnQdZ59CTRQXvYGWV21r_Zm9ZCpMUdhzPopzuUR5_KYMwGIHaDle3d1rblQZAC5K1T38foTQXj8bUBAjTnVMP25W_0V_KJvtKmmI1ZOchFsA6svzMDaPGb9ip7JQdePT0hZT-qDGHu1PCL1LZ09giCrkTsdJ0KWTyDI6qkjfZ4D4_KLjJ-wrqchv9JaFwDyqnTWcDTfrocatFqyCnUSqaT9GCltKoKaSgbfalOBNmwhedFTh2iydfQksb4WomuPh454hjZyLSbZGkitjQxZdGjgJfs482N3guGxO-v1Q2KS-fb_uTNkd_O6mMY-RUHSRto2grKjzkugbEh0r1Jji-1Ti9VpCzFbDj3ZFXN92iLpyvK4_CcsklaE-gwRjTpn9ahzQgrewEdFsE9TlZN860ERStAesHaE8g6iTFAn5tH-zFlGJhDnFzCM0VsPXqEjD8ZGcHpU2FuCeb-rzMBbCFtHfExlyQPbuMLbpn-ANp4J5cUEoGyc0dw4Ct6lxulycp7mabEV4jZbjAZ7-qzhMjTc9sFwFQzHijCFLrTFVowYLTrpbE6gDXSahaZQ1gHbwzy1Vlk3XnXsTIjbjXiBgRWGCPtidPJuy9ITpwr3T8lSjXoFdY0BrK2pYsJa6hgzKGpCB7ZM95-03Dfxfh3VFxTWJdgygsPtWD7Ga_KA4G2JgEaGy31wjzGvaVyI0mlZUSf5j2JJkuSpiieLZR_U5RBUt3WMgJ7tTc97JXCzPQXs7l15ba5fC1yc9DCkJY3Vdi1mm6GJtutY576FfrclTuFlTsxmP56zZTZwLtM-13M-hnXTMWfskLItudOdFHs7dRKyGrdi8eVcZz1ntX6Rk6PX5rWc5WrEGdSH8Ib8O9h1hrsgPqExw_HzrQdrKB305MN50WlTRSUxFnbhqTsoamw8gfaRa4gkySAtUnvc57pqwlhrvkg7dQn2hpxCU8FaiOTLbzfkemU17GdgG_ZaEpRYUEAd_34Hu_Dld3BovCIPhIUCMvJgteGwNDKt6dQt6RqHEfZxS4zuxzCdNkwS_AFNHzq7hmAhlkLAP3_DNnyzokjMG13LMMd7Qt8Evf33z7-iUdwt4vrwHcc6Hs0PdePT1EeZjcVBHhyeRWyYeWOZjtZoHw4r4W48lCuKWlrENO_6Q_8OvMFD53V_mryIyB9useD6Lv6FTrPaE-sCEBQaOW-dZiYDO6Zb3kFF7KF1QdvONEPjU_U83qW4zgNT6n1Mvh9eAebfjt4MermJyjtaHZc-s2wCwJprii81AAdn_6CCn3nriX9Lh625yu9g-sEV6ns0N-i7f0J7TTORbeZiM8_W4e795H7yHw"><img src="./examples/two-bed.svg" width="270" alt="Two-bedroom flat" /></a><br/>
<b><a href="examples/two-bed.arch">two-bed</a></b><br/>
<sub>A larger dwelling: central corridor,<br/>five rooms, windows on three exterior walls.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=hVXbaiNHEH2frzjIhJWIJUZeLSHBNnhDAoE8JXm3StMlTZOZrqG7xuNcDH7aDwj5gjzsh_lLQnePbibBTx7aVadOnao6usAdxPF8w8aLtNg2pKBea_FsMFitoTXjYblYvkfXUMUtO0Xod-Tx8vw3nKAmZ-aVtF2vbIoLVCLeWEfKAVvxkI6ddbsA8dj23lntPS_wg4If2Vc2cLiEyo61Zv9NcQHg5fkfrIN6261TFYKXAbJFJBnQkDWQXsHOQCX-OaQdqpEqVTWnAMJATYPNb-gkWLXiMF0bEf_nYJ2RAS_PnyEO1zHsFqS47iTcrmcHWEIMh9akqUSAykDegOCoZZOYYboOg3U7WKeynqG2bscmwo0ETokepMi6GnhuSO0DZ8IjnnW4jp-3IFfVEkX_nGh9K21nGw6oGiYHcgYdhcABa_JVjcY6XS-KriGHyd1ei-XHnyb4owB6ZzWgbQtg563BsiwLwInXGn1XFMAFfrQPsZkvsd-OpHvDW52rzL3d1RolJaRJXSLU5GMCYYUWhjutFwXyf5HDSTEtL8sZdtShRM3pdVWWZWKF3LY1N_6-ydWD_Z1zQEMbbjDJrCZAH5vNUa9SN2ziQ0p9f5L6MfcxyaljVwXwlPv97lHZW_EINTcNKK5v7yN_SjTjCAOmTFUNGnUPSl5fPv01bmJeOohTmSXMrulDOqGOvObN27AOzC696iB5p6NQaUWsuRnu8xx4zwda2-pXxyHgKio1ajj9qizTx9NZcpD-reSo5z4_f59DDBwUb9f_72SmN5L3tP-_fhQLJ5IdIZYZYrWHWJ1C5Ck69eQqjtVKtC2oEbdLamdlYpnLk9tMNx0f34U8zmQr5EyCG_0knXQCGfcyTm2BX2o-XEcyCHGvpp3NwrpoFnHIKcqaG3PfknUxfj8x0kx5sEbr2GiZScIx-ZHZ0V6wv5AzzLT5CTNLeI75dVniHGLDJqt2h9EJK3YavV8c0qLH1t6F4zijUGlZc3iqldaFFB_KL_bsV8lPToPSWpwHXZVlrv79ay-MtpL9zrpgDR-5YOr4gT1ku41HePitmUVSR08NsiVYd1BpD6fSzaODRVzW6A7ZJqJKj0mf0St-li1NziCTtgly9JcTyOxurzCXH8ry8ercfybFU_Ev"><img src="./examples/attached.svg" width="270" alt="Attached one-bedroom flat" /></a><br/>
<b><a href="examples/attached.arch">attached</a></b><br/>
<sub>No hand-computed coordinates at all:<br/>strips, on-wall openings, anchors.</sub>
</td>
</tr>
<tr>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=pVrNchs3Er7zKbqkQ6RaUktSkSIr5QMt0TbLDpmVqNWRBGdADiIQYACMKCaVqjxEnmEfLE-y1d3AzJCO4-zGB5c4HHxo9O_XDR7DALwyKy07Plgnd-DLRekWwsCiNCuh7RZ-__U3CIWEyd1oOJ4OpqPJuDMY33Ym3w_Ho_G7e5AvYr3REk6ee2f9i9Oz1nHrGKaFhI22AZbOmuAJwQcnZQBr6NP95GH6HoTJ6dNKuFya9N14cjd93wbFn7wtQyGdaR1DIdfKbwrp5BlMC4FgEpYiC5DLTOWSN9oWVkvQYmfL0AZv6eFGCwM-iCA9qHBNUgJ4FST8nESjnRqbxAe_0MtzfHcOuRNbD8aGQpnVGYwCGLGWHpbqWUKunMyCssbjUebCZQXk0mdOLSR0Oj94a6DT8VLLLNDe82tCpu3ncHJ_2ob5QmRPczgZV6pn5eBX8sdSBOtmXuUSX2nDQmai9ElSu6QF8bXWcfMTaCVRcBeKrXA5wvnSOOVlghuekj3wsZchPX08PYP3qIwomDA5yrwvinCSrTr4bgj4qA3bQmUFKI8OkgW9g22xo3cKiwKH0hkPYit26CNr_KZ1DM6K_Jre0upZmRU4a9ck1cKGAhYyxwcegnjiDek86AIC90zu5KV7VpmEBT74_dffWscgTXC7NhRC6zYsRCjaoEVpcnz4pEJWSEMKVx69JHuSOQhtzarhumcwMRJE_qy8dTvQygQUudQSnBQ5-lUb5o-zu8nku9l4Mp0N__UwmE7uZm8HN6Pxu_m3oKV4liDSOWCrQpF8CRZlABU8SOERd6tMbrd0JBVgq7QGL3bgbRVhXpLeb-8Gb6ej8Tt4P3y4G91PRzf38HZyB4MxDO6_H95M27gFCMjFTqtVEWAthS-dXEsTzmDgsuKjMCsohG8dg7HgSwNrm0uNC0GLoEKZS5LEWMhFkBRVBy7gxc5Ho6NRRTqAtvYJgXk5H3VbiCCfpQOxsGWAwm5hXWYFsHiZXVMkO1uuClChTikWEwHacJlcncJacdzn1jr4MBrf3p_BAHW9xG_o7HqL0uHeMq_chOLDSXQi08nlUpQ6wJMyuQeKflSuFHge_giLUulcOtjaUucgslAKrXewKSkRVTlFqxwP2UxsJFqK52WpdaeQdFZ8WTqwJnCaymX2RCgbmz3JAIzC_mqXSxDQu-h2Yb2GzDqncuuuyUh0WM6X7OIGU2N8gssJdKGWVucRtHJ_fIYCKxQCPdBuDdiNNBSAgnQeCmHAPtNfEtYiK5SRnk48IP2xblkQv5VyUyVJdhbUwP1WmdXJ6Ryc5PA3pdawtA6E1tEWMb08zu4fR-N3s8mb--ndw810eDuHTBgy5majd8D6WpNSrdGcWsLWVrGFG_qUhlK-aB1DMvScJZ7DYgdbpwIe1liyPwh0Gd2GTDiHruxRcBAuO2uRwx29ieXxCH5uAZQGtbZetwCOYb5yKoeL7rzKzejpO9gIFxTWBnYu5aHX7UIoVPZU5a3kzR7rJKYDQ5Do8J21DE56qjillzkqYIFO-Ti5-zC4mzyMb0F42Eqtr0HAUr2E0hFiJnOYL3XpizmIlVDGBxCEiwLUYmmBnm8NCN6QRDPSezj5_df_XHRPIbPW5cpQAkgiO-mtRr-IQhEwqqDjjdig3wS4Hd6N_j28bawHrZ7Q1iDKUFgncwwgdhRSX6_bnYOzpcklpT8sPYQ8Gk8nXOTRZVAIJxTuPH-cvX24G4-mD3fD2ePg48fZzeTjx9H9aDKe86EwYLDuopIxQeTSqWeZE2xDMkoZgKlfOsAzbDBlRBZBwikPS3JVVGaKai_BlOuFdB7zBoGWJitEnXG8pWpIzrDYBfRHRFJaMqk4awFE32kBbMRGOhics1kysUFMnwktoXfd6-IrXPvKTQsgV2uPurTot_RiIXMqTFguW62_zHRI8E6n0wFfSK3hH7iizMiXOv_HPw6J7cxvlJFzcKXxVQ6ErcpDQbrJ1XNF32LKpNpN1IBUFmukLBQVxG8rYC71c8htXO_FWlJSaZBOBDuDN8ghMKsjZcur-Ey1w8NCarslZNGIHWvmnGsWO7h7GMPt6H46GN8MK-JCzvgV2tL5ABurTGCTxx1Y1sfZ95ObD8Pp7O5hPE81mEXeCCMRIBPPKuwi8cAEzoJ6uaJa3QJ2e5W_ZuvgP_kSpFPWAdQB2-924Wc46ba7p3DS63e7zb-uLrr4If2Raesl_NLA3s4WMu8hdp0cauweY18mUPrj6yuE-gSk_wWQVwnk1edAyG_-HCQtjMf7I5RE8P4E5bxey3-zdg6kibzySziX5w2B-MOBbkQovqCbi6saiP7-I4FiDf8znKuGQFfNg9Whzpy68zf_Ed67RvCeUII6ZT7Pe2ykxV7Rq8ApUUu5AWXaMS2iyzOxW8dekEAj0ewsRYZJgNn-GdzXsQ0nlMD29qLSk1sigEZSHcEIInKg8tduFlsMrPYcKvzPq58koFe_oDuAFgup4egjv_xPuFXIi46w3vnUpeT0bA88hRCCp1hJ4OeH4G8iZ-kdRRkIPDKZQ9h-gn31V2H7X4RNAcKq4DDYgz3_pob9wC8n0AgbIfZgkYomaRsBRrAo_QuR2Qj7XmhdYyZYgsiUy0psROw-fgqjCp_9nPD7V93uS7_f0IYIxaf4xI33vCKGFGI2YpAx-weYH_nlA1WUQWkVdnuw1H9GUa8ORP26ewA7xJePDkUliEbYUs26pqAh1oqEwatQkp7gfwpbbK5oVMOdivJpFBPrZ7PBViE1XMS7q_rT6AAwzhgof53PGBgP3uvWCYiLPz7hfMYVjUBAy2WIpFuZViVho5lCAhd7J-Wpn8QGV2ZPVeNStWfKN-WOUwjCbM4YMsE9T2RlwsUOI7Is7NSRkQvucKSgfoGYjEZxuMSTRCR9g-pQcScGC8Hi6KVJGXwQLsQmJm7orVY5bJR0BLqQYSuTXNXhIvvmHjs2-JmzPlIoLbzfN0LUXWpO0RoYjO3KEv0DS9RnYQO8SbOXJ8zZ3KtSJ3Vdt1LJFDtbwgpT8-dbK-zzEJapMzZuaYZEXsV8LPav1BbRrKTRiqF97ILZ6f5RKfVaA4k9iADfYJ6JB8UE2XCz2s8OMPoHGL0ughxiOG7jP_FVzCvopM2-mJh2IbDB4JHCylpq5Fb2Gvs9cg7sdrTNnnzd68cWhft9nIumF5e21D62-F5RVxPnBnQSYfwWGxKcnbXjbE_TsIbnIhHXr2VQGUuHnthk1WhRoXEatpU-oKw4nuJOjT2EFIBzUfXcZLOErZJPU3Jbr7G4s3uTo-259g9ivaj8OiVhDvVmXBFuHMCoNSpBBFqSWWcwGxgfpMjbcWhDdKCkpjrOTVILjN9cXfAjbrOv-AWOV2QMMXEcMHfe3MmNdTiwg3MG8YV1h46I5SkahH0p8kcRsPw1fKmhytqFqgENZnhKUsvS0TSmMZnEZgeVibaP4x38z-9Ncwgy5g6ynYou68FIRZCVqZKfYeL7dOKzf8Bkprjx4RnP9w7JB7sR2K1HWfx1s7SzztM4C3dK6U7lr-0eR8HASDQlpq-vU_qKIXu4vMn2vv5kee9LyzeCC3hFNS4uLurlryi98PKaCO0BNAkA10FmAHH_fmN_1mCj0nOa_7sUnfDGPDDHTvU6su5CLFQQizgtwMTtmxcHiXYLv5FZaAz2KdVjNfCpwf3c5Bt-LBXOz6eF5IwuDQZXSB_TVELlkppcnhyr_LVJZot8t2Lph1ajmnWwNFJwXIr5P62NSy-_sLRf2ape--Wlcm8p9X_omZ-aOTXwxxBvYej0aYQHIl7VHIBHQl2DsxceOmENzhP1g9D-Crlkvge9nXllniA1Q5eX3X1t_bHcPhqtXScKhNlD9omlU-RcVvwvIl_uC91w-jjC_JteH52-GohSVeArOxw_LrzVZZDNAWA1IyWx2vHiwkiiMriMvd1ZvEyck1NXN0hYalw1yaITfeW5dMYhDpdOu1x6vPFTWOVz5YMwGXPSwcfJ-B33rnEFnMRZURyHYU7fmzSlUc5pfVFGZdh6FTum46qw_lgKF6Tr4PydGFecgu7Psr6NpvxJxsuY6ttMBKHtqpRnVZnywqgg3K42GOIKk_Fgl31PudgL7ZfnNJdO0zACrTZDzkzXRcyVlcEC_3ZwMyQlGns4p8ac5FQI1CNsDdLPAgd_LcDKaRQ5QDQV-3uydZP3Rq2fAxsJehhXykDdJdNsN48Oz56-t4UP9lmm1u0vbdE72GIPbulUvpL_AxyR3T24PTziivEFik22VaTDQCaJjelF9-WSZs316m1GcnyyemFDQIrSWN3tvnxzsNoXdkts42A10-jm6lfd7ssrZg318syWJqT1Vaf-OQGwPJD8-yLYpajmMu0-Z7q6vacsGvvwe7sUR3uLuU5WqaxXzzNos-biKb66v3oh8zQS6uPe9dZIaF6oBatnN59b--ovra0TKRVc8fw3Mylnp_qHIcrD2nq82HfWLjlN8uWRDfzbj3pQQNfenNMKkbJjqm_H2K7-dHjXKMwutrF0666xCePfXqjAUz5bBnqqfHXBtMDLWF_wLA77cYyP-VceHMJj_04pQS8pidaJY6NLj5WoDWsVMGmJwDe_3FQkyry2zzFFqWWVKz3OGGN6den6yMvM4nwTif-yUVw8psMnHnqCD3JzloQE5VM_zB0wzeVzmKf5ypxDHjdJ8lR82Yg1HhCbNypSqULZJRVmvIWCfdIyxyOIJKdlNfKVfJ7jjVW8P6HWGxkhQw6R4r2dDb57M3r3MHm4n-_bDFal5MHDMd_WhWiz5uX_2jpJl9bz9NMYvBJ-kjv-uYEygX5TQZ8a91jbM3gsBPesKvB1D9-vJS_7fvBuWF2y4764G6rPBOy4QZlMl8n7KCCqez1fSBni1SUS7WChwI4GJ9FxaLyvSgyvoIKWdAEMsHH2B7xcPLpPv6CqrojpexTHzBY7OMLfW9wI8yx8_AY5x1G_27_sdK86vXN8-kvrl9Z_AQ"><img src="./examples/bungalow.svg" width="270" alt="Bungalow with sliding, pocket and bifold doors" /></a><br/>
<b><a href="examples/bungalow.arch">bungalow</a></b><br/>
<sub>The door vocabulary: sliding, pocket<br/>and bifold leaves — panels, not arcs.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=pVrvcttGkv_Op-iSKmX7jmRIUbRk7TlVdETb2tNKLkk5J19OGgJNYlbDGezMQCCzlao8xD7DPlie5Kp7ZgBQkp29LD_YItDof9N_f-A-zKDAjVgZLRSshM1RQykepJJGn4CTG_BWlPizkTkTKIVWogMr9UrqFQjIpM0qJSxY4yudi2Fvv7cP8we0WzC-QAu4EetSIUid_nTfgnSwqKTysLRmDRYzL_RKoevDAjNROQRfCE9kNf0vevuwVMZYKJXQULlKKLUF6YZwU0gHRiPRauMTL9ZpdvHT54_zq3kfhM5BesCNdN6BN-AKU_f2gxRfIPjagDZ6QI9LJTWySWYNS2PXDjKzLo1DqKUvyOrKPmAOtVDqhA2GQPzbr_-E0qjtymh4uelvX_GVzkeQE0olM-nZifDbr_8gt2SeNEIlMgRhUfRBiQUqEJ6Z__6HbMhQe2tk3gdtYGEqnZOEhdmA0Nu6QMuHQJRCuxrtrt50kgpBeHiZbfrZ9hVYkcvKkdZgiVs4gj4rCGsUrrKYg3DBALWFUl797wFzFTaLDohMrh4r3Djx8-z8HOanH-Z9yK2oNTEU4G2FcP0_H749_fE9cWMv33ycw8f5j7MPlxdwdg0XlzdwNf_ww_nsqg-zi1O4-Ti7oRtE9-ny7OJmCDOwGIIhBjqYZQjaddKstw-ZsBzXS1NZIpDewQNaLzN05JEtvIX__HYAV__h_mb9y8mrbw_45IQGaa3wkhNIV-sFWnL-ysocMqF7-3TcFp1jcmeYs1OmxByWIhM5OtD4gDb5s_G10FtfSL06AYeeA9xUnnS5grdwNB2NevtgNAiYjmC9DhIpylFkBWizlqQR0QHmK6QARgcLkd3TxUNyDHmbAoRzIBNKOf6ztx8ekw7UVupVSB5SoEMoPbMBZcy9AyXvSfG1dF7c4xCuDXhKS1egUk2uJ4Ung8PBFLyVnPIgtfMo8mEsGjvOAeexdHBI-ojMGudYmdej0QhyU-s-1IXMit4-CUlRSNoHpZE50kHiBpTQOVUKTgByV8pcgJdj4tg_Go1Gr-DleEwMxuHLtPP3uEMUrk92nuBvzPQ9xVE6X7OMKlGNMUvWvg_0yAg2MD6g_80DWqFUDKqkeQyoqLMrEH0wVUBdGIWwlkrJNXqOG3JyjpbiLsRM5VO98qLEUJln4DAzOm_SQfjGcYVQS3CZUAiO4lRqJ3ME6anKIreDtgUISwGBVENTi3Dwbn7zeT6_SBX1JCRUaaT2jiMzOqHyaDsJpvOmBkut2WJ0vX1YYCHDvTV7huPS2HD-0SvBy_2gPEdovBG078OEgwWxHMK13HA9Eqq3D64099TKKg1CGc4DhL8aqV0IHgFr4Yy2W8httYalDAlCTs9zFd1JfuHbMtwrhfVQG-sLsCi4_vpaZjiEs9DNrPQeucZdXsy5gVBIkOUO1zJ1094-3Amb3XHuOnjpQ_GmDgeZMg4HQg-oxlJ3OqFaShfzUFKTLsS0EOoBOV2le9UHQxVJhEaB1OVIeKyD7CcynCKS8je7H4aLsbMKWFpEyAojMzwJPKOnNTeTGFIvHJxdXM1Oz3647lPJ89FHL1xXcHw2dh2pXWblAvPQoYRPzPoUYKbKCh43lOIoJI9REqdgfBHDhr1FwdoZHRT6ICkOKLCgmL3jtheFU_frOOGOY40zTqyxo3OsNkl1Y3Ophd3CzGbFudAraiRGP6CmfhCsENxfX7jQjolYOu4BdPI7Duk3aWCR4i4U8mDiljlXlETCwez0z7Pv5xc3NMZ0DbOC5y1fCE12UFdwhbE-NLSQwyHzljRmcD2kcPAweU0VqRTOt-fZOc3MWI2WG-FkMj3cOVRwZImp3aMToTrVnEmq8aSJQvEQR0eLjuynq5UmNhhHjJT40rNX6LxyuYZcijWS_tHiu9iMuDHGtlkWkstDW7IyQZlhStRSr0LdKo2TdEbIrI0OlggP_1Vm_ru7dM61UPfBLs7TxRZmV9_D-fziw83H1M-Ph5PJ5Bs61QlVmZVFGmLd3yphkRtePKRQNMhUkQ41VRBKKm71VNdTWfZ0_FQbF2Td7OLi8mZ2c3Z5MYxNazxknzgQlTepfdw1oanVNtxZmxxjQSqC46mUcPauJJUGIufOITmA-UPNvpkfs0JI3edrV3R61GJKtJBL56XOPM96aUQg99PNzlpg1sPE94aj1ayZnH3KzB2phlTbxEbydK4kxqIcRpzJILi2qfYhAhPfMLyTjann0innco3a8THDu5_g4-zidAhznXM7gsur0_lVUyXKKjYooFxs_FD50EPapYSOcEnd1VbadRrH-fz9DemwFlzQaa0ZfOcNhwkVfQSUlJ6JdSmk5XGsFjZvW2AqjWES9oU11arYOSN4eff59vTsL7dnF9dnp3MKVu7xifFaUK3EgShpzRALaua1KF8NYRZlXL5_fz2_gUKwqxcIC7lapcIhfZjpTkJpqVTjjDigupj6pB9p-8JRbAefihWdpt_R94XjIx_gxiMVsHeXP_LxcSuKm4Arldi2Q1-mUFgZHcthEjsQanYH-XR8HBqT85Luh0mlExLNStlvehglUtx_1sKupIawE4k2UmCBdKIuROzBEC7CqUFBB0Q1KG0KAu48bvwdp57lICESHek1Ig-beNIZUlrd4vYa50IO5k7LSg4mFzixjdpMaGZPyyVnEa-I3E5QLal8UWOhznB1eXYa9GEDu7thqhC1sa7ZLcuwdz4IqThgeAplvw1ocGonPBo7XVPMWN8kgEvoolI0r1AnSbylDzlQSBUIqURQ3R7weaRQvwxDYyrx_WYobSXEqv_CNelZa9DUomtTqRxWhjePMDqzg0qqLeQUplpswzFyvtyF_Xrvt1__ucc7Ly2rd_1O5qc5Mk4GfEIL6TDzgSdJr6m79ckftdjCAn2NqFt3cJ-NqZ04h1Boh5RQrjGeAcendDRtYsd0UfnCWLjX1GidWSP3iy7b5nxzg5ws7XxaCoXeh7KCVtLOzaiLACd5A8uMojE9-IWGbQwEe_sHy9fLQ9wLExFpWeAGHoSqkKfzsFRyOPE6wlvHklO2D6XJCuzHhs4DtdbG864MUt-7YY-xnL2PseN9irjTHvy9B1Bp8vF63YOw2k5HPYi7yfiEv4SCX5U9gCeNsNdjROSJIXR9HwaDwSDspiE7w1CUOu_g__Nhfp-Fuk9OJX5Ig1TcOjNlsvtaOkzhVIpV0794Pkkty1aauY0GvOaweQNi1ecyMRhPmst94C-DA9pII2WNRMlXBgfHROpMla4zY746mBw29_rAXwaHvIIGchIYR8U0MVFNrB_NTSFQjUPm3K6hbmcKLdFSXIpVF9gTXSSGOjdPiAr1yheOu5I2zDVGZ8sk5OAahXaw93ioCm7cG_Ygtoz8bYAfqPFYaWxYaTRhMTQdU5Dtbv7xQrv9hwvTR9_Hjx7oIAE7HNorvJz1AH7phF-qESecVsuKZiHeRvrdHZFyoLPGPRd-yVguOLR-yrh9JGN5nft7V7VWeYbpps217hbU3u889IjgsUEUznGtHvyxD_Ob0xzG81WoU3p3I0mpRTU6TtctoIAbWODWxOUhjonEtLMs8qwQNutYnF2YMxpUI2x-ZA6NOG4nqMi-W4Rnfc2uhpfjg4NpCyd1sKVfnjDS-FVGI3r28Cku9Qyj-muMjlo-O5jWUz71Vy07PGoM28HDnvJxv68PW_cIS3uG0b_gocSpm3o70UnjwB8Oym508lwh87dp6e6g5sfPpkkE8veuwgN7LenxhEgrh1T1Qs9K3FccF-lFwpfRyd34aKOOkzcJDjhUEBxoqOBHyUrSUrgrGjqiv4SFHnUFt1p0BV_7KpemY_BBa7BZLmWGu2LrVuyXUNdO-HU06Aq9QQFXxqyDWKbvWJtL_dha1xH7RYB3J1xbJXatNRY7Ut8cN1KdN1asdq118NjaZ7Dkx-HdUaMreq69FTqL0o8IzBmPjxrxNBlud4XjkxOePC1Wj8rY6HnhHwKY0Q2vjukxvNpELI31QrmT56CZOCEFEPP3EjE-RQaVlC0dFCdiMlDL3BcwPuRetUsPXfqD6Tc8Q3-Fvu7SH46Hr18fffMVerdDP40KfYV-R5-j39XH7dj75qk-rcMxBge3upUSPxOTP9aXaSps2DklcwJbZ4QJLUkdWknQxWXM1bQ4ChgPD2ENBId5tINcuiy9yEmNuR3i0irEgRpA4IBROC-2ARX4Ey3eJFrq1V2QzJJ45QkYsSeYOEy8jmAhcLxIE5QBDIog85S-AV0am-6ZU1rueHOh1p_TBkMj1u1aSA1RPJkcJkzCRSmLOgcQ3AMKl57OopY6NzXxqKWO0do-ezQdpcM-CIf9iB526MejVtbz9PUu_dHB9Kv0bpf-gOrXV-kf6X_8iH8bfA2w8m_13rDhPYF_4-VuzRp8t9OxIlQXp1UmbjsL0bbFDnaIWwuUIcBjWVktPb2e_TfG2k8d7MaBxWVCFIXOaLsPvzR4Ob_9dD77fn776fL8p4jEaAL0IsQWaAO-JJhvA3W94oE34B_0qmbgvAgYbikxQ0gvkYQGsXBGVR7hTvi7sO_RnhFADpHdM2MGr1u0gdS9SxAfzWgNUE756UDhisBPAmx3YKq0-Ekf8j3hiM2-zL8AYPTM-PZqQI4B9vmpmWZweCCUXNH-GSySJIxBmASqd2DN9A40qSzg-vzy0_w04hP0YoE4U7ovhY1vORoQzkYAnl3CE-lSWhfALNKTHiPBQ3hnfAEL1EwelmUngq1j3tv5VUyEKEXg5YySOVTaSwV3n2_f_3B1cXbzw9X8lnxx-_3l-fnZ9dnlBZc4S_YSlJ9-IcCsmU2CDfn1XMc9f2rKYSHCy2TICszuMR_CfzOiR69UCRpgvCbhTNvAmV8QLG_ZpFB2A8gTX823QEEDxy9vHdJvAwJtmtvp9NrMkfnb5W2O7h7Cuyy00A2mWE8crtb0TmjczUdw8mfkvzbTdqL-bOx98PseBcLqVj-VR0yXX5AX150oJ1RtkkML8-Z1K-e6QNq-oxBXP5VCr3oBPGOnPAZRO-hPp1MqLMzzzWi0eTMatWMq0Sa18SlHjwK6HCfHLcMvcESxR3Arc3xGx3Ca4d8wqr2ZjvrHh62O5IHN4bSx-13Hte4ZHfnIOxzfHE5Hff45w7_EkTE66RVGcKK05q-Y-WcAQb7NMPHtYgt76XVrvC48wt7B6OD1YHQ8GL_eY1zil97_AQ"><img src="./examples/hexagon-pavilion.svg" width="270" alt="Hexagonal pavilion of six wedge-shaped galleries" /></a><br/>
<b><a href="examples/hexagon-pavilion.arch">hexagon-pavilion</a></b><br/>
<sub>Six polygon rooms round a circular rotunda:<br/><code>room … polygon</code> meets <code>room circle</code>.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=pVnbbhs5En3XVxTsh9iIpGnJl3E8cQBtosTGJHJga2EPBoOI6q5Wc0KRGpLttjYIkI_Yb8iH5Ut2q8huXeLJZHb1YMlU87CqWHXqol0YgDUVmBxyU1rwaK1IEbIKlZJ65mCGGq3wmEFuzRwuR0NIzXxhNGrfhoUSKWYgdAZzaa2xmHVbu61dGDRQ0oEvEJyYIz2u40Fyjq4NzoD04ApTqgymCJWV3qMGo1PswqQ5aQKPW7sw4eMmBFmYCgY2LV4LPQMnlnSI8G2WxBfSQS7V6uy5UAqdZ8kVegS8F_QJTN7a5UcWwnu0-pSFh5WKUGrp96o2ZG2YianCffgAXz59ho8QX0avzNUGUfqCrBCstZe0k32QGqR3jPvdr8ubEaTG2Exq4clSC2HFHD1a6TCD6RIqmfmCQdkqQdCbXhteDN-Oz9vQ2wfhoOyB8LD35dPnfYIVGkSWWXSOdIGL0fV4MHo-hC-f_g14h3YJMgOpnczw78k7xdTM0cGk7HWfyuzZhE1hOjJzYNF5YT0s0P49UKmdFzpF9hO6JXYdYRGMzdB2pM5wgTpD7RmY7oV07q90Dl4J91-DC7AoFFjMFaZeGn0KmTEWXEV-34ZC6hk6cqi_JzTJWRVGIeTSd0zJXodAH4IwHTkXM2RHGxcWkfyVIk1M6RnaThFJWlbG-oLEzKSeQaqMQ7UM8fXm4urq8upi9AreDi6urmF8PoR_ji7G112Y1DpPauXWsesrf-TAVBqMlTOp2cCitdsEMXsThU8d4J5cGF4OruAeMJshe0zZp0eODpOEvBE5-FYbeslJkrShKmRKfroovaNgN5p3fPn0mR_owkBR5AlPOpKEUXzpoCqEh7l4T9fQ8Enz6ZSdm6-n7MMc0YMyqVCd-7MKvFn9U7uPtDAVvrDGzPle4b30aYEabKkdTEX6Hoz2hiPaFcIiQS-E9UuohFKBXMi56O1g88Rk_cSkC-MCITXa4R8l6hTpW228rPlQ-Mg71lSPHPjKwMur4TBQjOPLnxpf8COMCnQEScGGZ5sGCy1hwpuYFXuQGwtlr7UbhDzkt4RXCYrOkTpaOcsUBp0IhdYmMp_E6Of_VyzIlycg8kIldUZJQ7MmQSzC0aYq0CKgchjclNzy8uXL6-H4GgZXQxhcXYzP3wzHF8_bMLocw_iXtxejV12YMJs5VoI4ylqxZMjb_g-3Bz_cHrJJBN2UlnrW2gVXzilrSd9t0kIqtDYeZqbWQcAkN3YCe6yccPBUizk-C6eQpxIzE3vIXKJt0w2x5UBqj3ZhlCBe2N-kHyV1vKFSW6PUf9mYrmRKgV4IPaNjWRuWP5AqRRMh5x4txcDc3KEj-1FQmUqvjHU9Hrx6NbyCi2tOtc8vL69eXIwG4-EqTgLVO3DSw3GSQF5aX6ANGYfTnbeIPkYeGM2uJh24gjx2jkK7xo2DYVdBu4QzSMJXvdrR4_L1cPyPwfOfg29zWJArCKUcOC-VgtRInZLdzR3aoDlTG9uGPeWYCMEZQJEW8HupmXchs6KKibowlgyF95TojAWLvrSaPE9U3nBE1DSQ-lIotYRCuGC-m_Nf2IRvXw9GZL_x-cU1_9PdKnKk4yOpymAjs12aS2bmY2ldae_kHVLmjoUEMUNVGEdxyyRiMequcCYpowoPAv4ohaWbNnnIBuwNG3ErWILgyUQT3gpJ9RT5L_t_WkiPqS-tUHRqiNNAySErTJEsWxhNdQ2LKz1k1txx6LZ2QYmlKX0XXpLKLG6Az-UdnoKSd7R_nQU5r2okP9Ked0AlIwfNqIBaUvi1dkPc4wYzspoUsnDUPYR5wBAzZrvmpqalVL4LI0GFgsmDNY3NujAy7CitXdDCWlMh0ZXQ0OuewDw4nCc9pWMVdjKDnEuIoKTCHfawsBoCjqUPN-PEMpZflO-IAGp6iMEXfHiHL8gZmJDxIUOXWjlF6HR-d0ZTKl0YyzkqbwxKFU0T21x4IrwdvSI3prsFJ-89ooZSm6nztkypjFZiiiq4TlMXpwWm79tkXqboSixdNxQHJHa-Ih_Ntot7LebGIry9GI2GL8JdTRgddr58-rzDRdB9e7k_aTd1dSD_1i48v3zz9nI0HI1jHbBWa54SN0qta1kjWxqpPSj5ntL8EgydzzGzYl9rZQgWckhrylnwnZwK13ZjIFJwo8ygHsOvZX7MYGGcZGqgxJVbxC68wjpl8hVaOSs8qUNOxCG7CpDmOzJZ4IaJL3COMFUlLqykfoKVGg3eDF9A_E64UNWIWL6lS6GNXy7I0xV6j4Fha69ts8XJZU0NHzuDCUyVSd9Tzp9TWAupuy1ufXbGkb2uTLUDH1oQDTCftwB24SgJIdpLktMmxNgQ4c57SUJMnr5vjFmXmJw209B5THJVumIC3jBoKHzoPi3kIqVeItCQEjrjJFQIlXcYV6Nz667QbQHMrMzgKGkBaCaectECyCSxX0nF0h1aoVSrBbBlY1pS6EM_AgBn8CRJkvVSeXctPW70iRkufPETGK2Wawx6J9jBAmrMRnDGOXATNeCEhHEKYjtvelyEam8rY0bkUIqQvL9SodqG8Pc4qT__Vmt204Oz-PivyW_1Yn-12GsWD1aL_WbxcLV4wKC7cBUKnLq8aZR37JpcDmLuQwlu8pBIg_l06K63bo_OuSUxk_ofEu-2B4_hplcvkXC3fVrq10sk2u0BLR0EwTqdTmej1-WV_-nV-ov-ukW3SFLwBcMZHH7lN3xpCnHB5YXQWZvYjlZDGR8st1DGN2Dng9evX8AZ9E4eAkutcY4iQcEUfUWsXZMVwbs1mcbnN3AG_X6SrBaHL25I0Ao64YHmm5dXl6MxnEHG3zz_GTpBkBY_wZWzzM5cgUrRQlP4wCoe-0cJfIijhL0q_s32aSXbD10hfNyAq95Rn0OTgZo_1uCIRD7AHonMWPyBRNv_CoXM8U5_CyWJO_eqb0G4v4aAx8EuDdRq4WOwFad0mZ1NMeP23UeTrL2c_BeGu7iPvhPT4T8w26k39SiaT5LVztKhgylmdMDmScGItKm21uZJ7ArxqPok4YudtU3wGHq9JGn3e3RiOIpgSy-V9MuN89j7as2COTfOq-A-ejE0mp0LpXZqJRgglTYtQ-eygV5XfP5rkzfowVtX6K95T6gkKvgB-u3jJ7Xl-MQImkkmrVhJhvvahZdcSPJQxeT5GtFSfxU7qqbW_CnWmTZDHfZwhnZKZrHQ0CbiKhQ5uApxEVJGvDvIlTG2yw8FgOws4PO1_5hwvIRU8uQodtMh8njmE6QKGm2AWBSWBant1-sn7HoBq8fzjzUwEplpurWCoWlWdpa9Y-81GprgEh76B2GA4gsgbloTZopZ1HliNDylQ57RjqcL455NwMfRiJKeknBTNjW9DPG1WSBfTuhbMhlGahE2zM9cXdJzJrm5eDE-50YjFo1iVf_F5zhJkzSPHKSovUXqirsPqEu-Hrynw4aKfr3Slg3XWGNdd-ELBqwVkNmZ4efW7OcI_Eljvl6SJJFZw4iCOEjqd0rehbg6Dk4QX9EXKB-s7u_h7f1GiycNxOrMb2_nO28IoQOHR2vec_KXp2_Y8CipSS9sP9raHu_1sq6cKIGFsof7A8HVdMi0XHaHmU59Yl1jcHXPewtxhyAi6qrjC-1HKOpFIy816mvPxG6t_j64h8zj6Wdn0Iu5flvj8EBgqkCc0dT9r039sWGbWApPl7EUPo3V5UJiGLvNUbiymc2TTYg2HoXRH4cIQb8cPB9GyL1YSu9H_gnTDB5xUWxw7K3qLTAWxFYxHXTOS6ulLy0yJQV_iGmMhtz8OchMUz9v5h0u8vhwalaRW4JA0xRE9z3y2bXc9tAplbAZ0B9rprh1SuiQ4iscw-DHhN2vY2gLkLpatBDfCJAdMyB6swhCbyE-SZL7J7FS2jaDcFIDxLcH8BoptyQ8PHoQr0qDK6WNWdfwol0D5BoeWfPHP1PY5AIg_JV6NTL5k4tivBOy4Mnqdq5NLnZqFx1vTFLAygzd1ijlFCZiJuiHjwlkaGn8tEbr3BfVzV8EjcOmDg_Kmo5mNbDmFiEVXigzK8n55T2rOLX8q0M9BMmN8dy2PeiyTur3AHWCD_9GOTdSH87mVNT3KOGT2x5Tamts9yCyp5EVxLf408x3IP_Y_yvk3ErqkuLb9yOf9LaQP651QPXPM53_68V4g9W8o_6h61u_uDAHlX1IqeN2cNv_8unzbf_xTTPIDV8w9O0hfXn4-Oaw28xxD3lCs4xlFhFsrsTsp7VJMJUTG73zI9cUaMze3_FD422vXbfm-1s7-s2OZH_tZ7rYePJq_cvV1s6D7Z0HYefBn551uC3dYdhxSGcdbp5FkwvpFcZktLDmd0w97NDgtBOmwWFqE2iWR8fvpkvYqX9_juuUAnb6Sf-4k5x0esc77DkfW_8B"><img src="./examples/terrace-row.svg" width="270" alt="A terrace of four mirrored houses" /></a><br/>
<b><a href="examples/terrace-row.arch">terrace-row</a></b><br/>
<sub>One <code>component</code>, <code>place</code>d four times —<br/>mirrored in pairs, widths from a <code>let</code> array.</sub>
</td>
</tr>
<tr>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVrrbhs5sv7vpyg4WIy9I2lbkuVLZjaAxxYmxskNtjM5i4MDi-quVnNNNTUkO5IyO4vzEPuE-yQHVWTfJFt2JpsfsWSTXxXrXkW-gHP45yiCFQwHMIdFMVUyBiWnRpg1CKOLPAEBsTRxoYQBgyKR-QyM1nP49__9C1yGcPN6PL7tnr-77N6e__RmfAO4EvOFwt7ei70X0O_BxcfrX8aX8PP4_dvx7fXfenCbYRtKWhCQmGL-EgRM-FdEU-EEUm2YSqq0NiCIn70XAACTpVBqAjqFiTDxBDCZoa2WYx4rbQuDHf66ENLAJDBm_yJ-LYSRxbwnTJxNQObO6KSI0fY8NjFI7BBjV-9uLq6vfhpfgswZq38MK_pvDjHmzggFU7HugNUgHW1wIp9h7sBpEEpBqgtDKzwyMW35GPgZzbpavNAyd14OLjNoM62SH_zBaX-sTY4G7ELkiUFliZRC8Rmthz34Z_8I5gNAEWeHMEWl8xkxkGsvYCIYC2PW9BsbZ5gUCsHopVeGFzaRXxrpHOYgAvD46ufXtyBMbMEIlyFJV3g5uKUGi3PpN1v-nc3EAiFHTGwHElRyikY4VOuX_GeRC7W2MmDPjExgipnME5gkaGMjpwjd7t-tziffWZgEu3NS5xMwwjo00iLJiMQIU3RLxByks_DL-Pr26mJ80_HQVm-xp8QaBCwykTsyr0ybBKwzQs4yByI22vojVPIyuNDG8e-WQt2D0x5bOhAORium60yBoDCfuawHY8a6R1zYoF5PRuZWJui1KWIkBOtEnrC5doiYR6YFl9fnn67e_Uy6kAnmTsZCAUoW_VKs2es8todiiyEmhIk7xJjI1_BF67l3v0EPbl-PvY_2YLIQCzRwPgBF5GOxwAl8DxMbC4XQfzmIogmkcoUl_yLPtWMFMDRY-QXh_bvgJSUwHdChSMgZBaRGxLyDv40imMO0kIq8nc9K5CoD1HPLHCicYZ5MPHAqlWJhzIWZybwHP2mXgRNT0qMwCGmh1BoSNPIzJh3ItcukN_hY56mcFQa9wXlYUNK6YHQ6Z7uHBctTKciEizN4e347vr46fwOFxQQOJrHOY4OuEYBshkr5aJJgKgpFThuzg5pafQthnKTT20M-K5EjUgslYkxItq4wCBfnt-Of31__jbzJQSZIiwslcrDr-VQr1vIy7sBUWJkHm76XLs4wv7Myv-9ArIvcoelAamQyww5Ypz9jDz5a8j9vL8QAeypJDmI9Rwu6cIDzhVt7-xh6-xj_94c3VxdXtz5Ww8X5mzfd9x9vb0jrPghpR_rkz1JhDyaJnIMRiSws_EiCvEpegcXZnKLZj_mroErWNy1NpJijQwM_ktKvklcTcOIe4af3t69hhnqOju0tAYcrB6nRcx_IFTKky3ANuZjTSYMjXp9GUVQdkoMxsnnkZLxg0K0XmHhWLYjC6QkIRYlnDXaduwzJnC3r6Jq05GEvr25ur95dcNSDgwSTYqFkLBwmMF0HMt_7k3PUd5m0gOT6XdoRYql1ZMQzdIx_WEuDLSKTbBV1YtV63qEE491urhOEaeF8krMTtgcmhTYEXiccC4YdIuSWLGjLZogOlrpQSeDDx_6ldFlLGnbJNkWOm3ZKSa4h1taVTlVCS4Uhv-nSIUnUX9Dork5Ti46loykjxq5DO-KMluNKxE6tYZmtK8OMKYUYuQiZ_NPd5dXbu6t3N1eX4wloU_7m_S_j6zfnHyZUFTQJkT1Zir7v3_lDSwdzFJTurTfrSyRHrOQDky86x4llOSYYK2E4brCdyDxFY8g5yeYW2rL_duqcSaGFyO-9KA1VxpRaBEVn6wPNzS8csqdrh906bpPAyeFchvMenPuotgaRJLSYmbL_878T0Pnei-0UWJm2LaZOO6FgZnSxIHZCKcK5qoymvT2OIPvXobK6pj--8bXcPvy2B1DkJLT5fA_gBUw4_Y6iCcdP6EfRy40IxpIbRBFZeHxfc0OBEIZRxNYvypjGoCHMTVJV2GwCYiYoNTS2cd4BSifQ6_VGEcRam0TmwiEcDAfk0F3oj6LDHpz7AkGnjNyPaC1ZNHGLq4VBTtjC-URI3AWLz8UiBCofbKcivqcaT5e5XPX2QvUxivYAtpPiHkAjJe4B5Nq4DIrFHkDlPlTd8cJmMtuDkHP2mOtut9ulKqOIHeckLwSZw2QuqJoRCqpM02mKPii4nWm6_G_PV5Egk796OFwRFKcpGd_nJJdhFMEWBfgNDqJOdAgHoyiKmp9Y8If01_CJimeE3_0hbstibyFzLz_7EpZoHSzJzv7RrIPhH4Ai_KXX4HR5xxuqEzZ4JQv7DQ76JyVP_lPg5PcWCGPvABkOSxD_qQKpDjIV6-8s-HKPj1LFvVDx594Jk6q8LIv49nEMpncWnj7QqZesZ-f0gSNlQqm7_GmgwVETKXwLBxtz1viMxuGKq_8lF4a5D75s6t1RFJoM4ULm5Hh3MCAT6PSPGY_i49FpFP3l-CiKQFpGFzDsHnVHHLEps5FnJI2U5JOfbxK84YSS1KfCHnwS6r6Mr7R-fH5z68MFM9Q09EkcLydgitx6O-q-Cr7XfeVNrvsKrC5cVmaYReF83V61TYFpB4PRn-CAdx92YBT9CQ4IwddlJ_Q3Bjos6xpSyXcWrj---4FEx7mc0pmcFg6p4wrAJg4FP1z_2WXoBHBkEY7YrpKKs774b1sNm9ijqt7jVs4r2CuEf8N1yODsNIo6Z8ekpbLuIi02VoxqE3tkRTR4AsObWjCGHRgDsr_DXXwEA314BZ9lF0ZTBhsrgslzBUJRxobiRsAQ5iCkVQg6rxyanN1XhkrmXDxykwxzpNLM93KibMM3IhaD7fbNqNM_GkV11Arffn8IyD4BdNICOhlVDl4jxSLFO4SdcefoqIyB_tODLOEzzhaUEM7nM8UuMPsMsJMW2MkDYNaJ9KnQ2oqBAayKiE0wpafT9fPATlpgJw-ALeMly34n2FkTzH97MJMt4_mTYEejJpj_1s5oXF-IFZZV6O31OQ9sypKDa0YqonK1_oEmeYX5jN_Z0qUkhzUqaTC3xEKoLwgxhKMVOUjUAW-V4IUF3rKAhcXL1uUy4pJW84-BXzYIewctD2beuWjq-MLWN1hJVbqHeucZ__YAvnBf5QeY-x_45344gh8xJn81nGuBg4zbSKs82OB4s-LcCEpMUcH-mCqbPEZ4LZTa5700IrBAMWUNma8BmzTKwWbZCBKpVo5thLOSSrNk32_uOBnQDib4AKk4kyoxyLOZOoDw_IuPQwdcsUZKQhdhx3e27gwYXcnP1Oy18X3cCuKqfH8Df9gU1ydK0ee0K8iqFFdjlLd5CJFipZOqfquJ9LcPIdIGfINIIvPtQ2DzEK2Q9tghxuKrD8Fxpn2IlmE9IKkLeEOb9jcP8TiRZXy33JBUiA1MhI13xDQaRD7pOeZbRJbxNva8xj57HvbbNnITm32cfdI6Ed9b2L_hn9s-Gf7uTewJ832_wBxKINpxSmGm7wsJJm6dNmKGWz6Ztr1-h8dfY4oGyeVLQhvAraOlKZ8sTR88WJq27e5k0-6ORw3KjAOftLk3HAeYrk5TGW-eJ4wCGbpK95Xgjmu5NV0G_svv2i8VFVA2sGmI4ALbrQTE2KNtQ_jAG3zoqoygcFJJt96I9nWN_vzY_mC0f9G6omncuHBtR30oZ1rh_LiN2owwrahYoIRpkGevTsMUIS4cI7vM6GKW-ckkzRZsddVFtWk1BinvDnxOJ-pFnIXFYWbs23bfXzC2xViHGaAfzIV7gLLd19osxboHYzoGX1pV3ZyfG64tD5b0AvPQYYePpDzN_QWVOzqH0GywIqnbAVjKxGU0Gog2t4Ue1G8LX-iOI9q9janlW9QGT1ALrbPfFr48l9pyi1pzGwWCzW3U8931j_02biF5G3t-c1tlVYbWhJ4wFBRGFw5J2KQggk3u5kLmjUwdyrIaz5uFH9DYpZ_ZOQ2-BnlQ_lU2rzklYZ7WfD6quir98FZunFkPo51bWfQ--pZbS6pH7OGPC9Vvuwup1W8tO4qgk8fplge9q5q1Rov09G5qgcqcXh64QXr3mX13UW5v7mbSp6MHjMLHZfJ7i-azjL2f2nB1SpG1jMf-6k-Q39_TnJqsRafelDxNy3eyCoWfalrfwbJp-AY21sbIJFwLcnWul3mLMOhylMmKXgs_ZKhNs-QmcLElov5RbVJUXYFVdD1pKJq1gFjUJRrDhP6zpSQP0TTxOrHUWOUJyGVC9zdsuEx_8JDL6KLNkNeet3bmp2wW2do3DtXkiLe0oHwxxSBlk0iiGdV2v41CezZB5tsgJ0-BzFsgPuFucTKslXRGeC0Q3tNIrDMlvtCfu9_0jxpUmSd6yVo6btQVgRFvOJWW2utJhdWGZ6wf9LfWD3euP_u69UMuDp_PT9Tx_dlz8auGrl4_2L0-tATP5Cd4STRqeMnxk-sHzfU7-T9u5K3n67eV6HbrN9pav1tfX7v-eGv9RhRprz8aPLm-diiapXOl1WjHOsDPOKZr_zPUbDxT2FWpnoOV-Uxhl1oIXId7fq7-EiOWFqY0yvQX__YHuvu8uT2_ur77-O7t-e3F6_HlxL_ymBfKyQDCwL8WaP3TjDwJY-dUGhoVoOFqxTqqIOmeyDXqFXaLwXGjFTmKohW3C4k0_pILFX4WzkcoJdPG9mHE20_rlmAwiKIV_dcQXypdly4-vzkevYByNhKef5jyJU053OUXNjTbtR1-EsVr6_cAU77GVShM9ZJjkUlGjoVSzGVZ0nP1UzUIJMG0MLnkS0T_hsLHLZIAjbAPQ8MVGtXteQ5v2n8MJ_LN66CS5Nm34JwefSsOn2sQnVY4T52LgMhGyBWiXm8UWuAanLwqrYJBx6fX70HCn6FxbE51q-OaTGi8uXlskzjaQaJ_WqOTl3fYvesBhm9bN7v8h6gMt6g0pFQTCaPOs9qT6JSrQYPMbSnwZ4INhl8L1hZxG-y0BhuGvr1q2mXs78a1fljS28pM0N77EHDUELTXa4MS5SiaqJSULtHe7z8fajCInoT6Gn09QGGD1_7xs_W1DXb8HDAegTRUplNRjqMGfsAyqoMJFQmrs6YzaLOGKeZxtv8oTP-Uc1vUiMqbMCiczGePQ_hy7Kshwju06qkHZ9NqiBAe7HCdwJj0aXVSY47zXwtpJNp90mXVHdf4zXFU36eus6gZoRjt4b2P8BaamMDb8FHebtDQvXrgjHb5DHchnFB6VtTv-Sw_eaXObkJIk5fVo7mF4dGTv-JeuKxqB5mX6uVKOR-id8kOTdcVxj88oEd79cW5H2qVD95KNh5LVGF61wgCx22FfjC42N-5-ej4KzY3Hyi2ZR56uvA6sF-KniMWC7fuGLe158fSz4AjDh-H8-8k4flwo8EuOH5uCV8Bd3y6CdfCW8ZPAA1KoD5nUUYKDekfQhlG_wmUo8d54berm77HI4tS_afRN2w-a1P-gwcYNVHmfxDkJPoPgJw-zsmDwvC30aUeom_YPGhTbo7rkV7aKRlL56-Oq5rZwoFFX4hn4eV3-Tb4ELaq-MZb4TC6LY8fhb9Wz4OrC1Tiw0mnMCT3hdF_x9g98r6Rl1A7ld9N17B_buLsjfC5CiCh14X7g2hw3I1Ou_1jn5N_3_t_"><img src="./examples/library.svg" width="270" alt="Public library on an A2 sheet at 1:200" /></a><br/>
<b><a href="examples/library.arch">library</a></b><br/>
<sub>A public building on a real sheet:<br/>A2 at 1:200, axes, schedule and legend.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVprchu5Ef7PU3RRP1ZKSO7wTSlrV8mysquK1nHZclypVIoEZ0ANVhhgFsCI5CauyiFyhhwsJ0m6geEMH6KsTfSHGhL9daMb_cScwCWcR7CCQQQZZNwZDbFWsS6M5WBzKRzM1yCchXvmOEihOPz7H_8El3J4c_N9-_2nN7c3V-03n25u3968-x74imW55J3GSeME_qg4LFjsQJt7poTlluiWqZYccsnUBTBwhikrHKRMShAW3FLDvBAyEeoe1zMHNmWGAwOj9aIDdylvnMCnd-8vb96CFQlHKusM564FTCXA1ForDhlbg3X4hVDw332g2DbVuW3B5yvbAifiB-4gY3EqFLcEDAjaONnA5pK5hTaZB0bhtZJrWLI1sNhoa0nilFfa6cBHTd8khi2FuscFDKxQ9xLF7kcRZBnkzDjhhFYtmC2nSDxrgSmUQgqkXhRSomUyWIrEpS1YCpeCQvXPdM5x3cxCXqg45bjBxgl4UzGYLbSZgdQ6vwAu7lMHE88U2VjaCKqn2_PfLnGrTFjJO_BOuxQl4NJy-EkLRZtrnJBRUiYfud1Y33DHhETFi3yjHcvNo4g50M7n2qVgnc4h4SwB5rw1l0xKfz7uUsM5EEtkJGx5fEqt2lQvY2Y5LLS5IBKA2S9a8RnQH67JmUjgWyhU-KcUwR9eYeHt9dXt5Yfrty1Q_JEbEGrBjeEJLIzOCLL-l2tLhunAjSMbWlBBK6fI7uOfvkfQ-drxtki4ciJmkqyjCwfCnbVgXrigtu0_o3UGFg1WSA73Rhe59d7lrcvAFnOnHZOQcwO4T3_uZgm3sRFzDu32T1ar2T40z7Vx1ivH_uWvM3_aNTRTvYSsiNNSQQuptQn6Nbzpj6fhLGnhPkmGrOMVTaadbRS90IUprV4oDAnolXiU5lLHD56eFqVMJe1cspgntGnbgWtGIgj3jd0TXi8WlrvS5qUX2CIDvQg-999zN-cLbTgI18J9xSlT97iMkU9_YyHhuUv3sDONZxbtvib2MOdSL1HlqFhVO-9-09zGTDKnjQWYbR7g3__4FyTCQJH_PdFLNfNm4ZI_4s-zjSZsyhYOOIvTFh0e5S176DTEKX80WtmN73x6_-3bd8CM0csO_FFtokbbOm34mgImLsSoJqQkfCTeQ_Y_67l1pogdxMLEhWR4qH8Hs8_Tj3eXNx-mn979eHl39cP125k_AlkhnShZ_Vxwi-v3oElp5EULYbgFPEMdeIOOrkhy4CqxaDemKl2SerhyRnBbej6HWMsiU-UpIhV0e5CBF7swTMK9EV43M7bidgbzYj6X3IJiGW-BxPM8X4eAhwdeK9SzdczxjCtHbmT00h9NioWcK4i1NolQGA07DdJq8y4koR-YlE34WwPCCc-yBsAJzEiQYTS7qCK3FxyDqEtF_FCFwJRLCYMoonPKYCFWrjCU79Af2D0TyjpgBLxgMQfJSGdo8U6nM4xqAgKDbhR5PcS6kInfySo33NpOAyAI1gDIGe72sufhYpbzBgBagEP3ohfhEqWNS6HIGwCJyCywwmlgUtLCEJbIXxsNAMkdvLn8M7yiTBGR-U_qxpmzdZUW2UpYEiZQfn95d42kg0B6AuvSmzepskEqaLfb7aC0EqwqNdov-msAJRcQySsPyFeOG6GNN5Hi1qJhIGP4NZNU6hjuOPwNTqNWdAan51EU1f9D-fFp818steXwpcbK5-_qYNSYYbYnaFTHBtM_fKltP8RmrDouthPr6ZJbd3Y4v55yhr8d2v5y6lGmh-XqebnIsKVs_iHscnt_pnsMJWr1oiEpyUOEpx2I3jMQ46gOMT4kRf84RL9flyI8kZYrDNTbdHkMZzyq6cQ_HNQJIR3V7qRm7PBwGCleTi08j9TrehWd1592obKvg5psQU0OQrGvgur36lDhaRvKOrZYTO1XYI22sEbRxoIY_iksA6ywkIxaPiq1oDegD1rcgsGEPkYEAGO_hOCIdl3SeiI6Zi0YhN_rHklh8IXh52BAOoHf79VNlLg4urSmDywpfGfErQOe3PML32fwqmqCt9fv734AYQlzaYRzXG2XQr4A0flLip5NlYdFAEG_v7181769_tP1ra_rKLEKBzFTmHsUiigUNUisLMZPr6cf7z7cvJ--u_54d1bWnrijB6Htg0-VWAQhAxSTil8f0crEI4V1lAVRQ3qpWsAWjhta5KhRQF4J1nnMOEzvlAB9mCQNMleF2nuWQ-R7p5C__OmhGlwkr8wUNdUFK37hMBpGEUg25xKaf0CBoduEAttVvViImB-g7D1F2XuOsv8UZf85ysFTlINdSjrJqC7fHTXfM5E09zRAv3mlRWcem1xl5bN2YIG0cFXOBAInatZrheUWz5DNmp_oc59v-B051zOQ3xyyXvVGNQE8zPMi7HCRej4nf98K6cRkn8ctLm5uylxisL29OvQyni6BoOsxnqC7pMBxDfrzFXzWGVfNGvQy3kfM6oghuj8N-eMG8GlEtoU42UWsG_kyjrm1Yi45fL5q1iArq5alR_MNix-wlkt1gcbY8yuM9lBnHZLCE6w_0voPWmfNcjMHPSDWyhkt67ijY7hXYb1HPuAfIdL_LwXnTqSfaQXfYd57jVJ-l2v7egaOPeDUBW5v7q4_XN5uBgyhPbjnihvmsFMuFKrVT2mKMCwjXDa3WhaOxiAZBl_HWXLhpx9aKGqdQwdFO0ERvrEQY8vFaVvzNda6vnj35_kETtfwiur0szBloIwdplHUYvmGPNXWdeCaJkk0T2Mm8VK28PeQuaopUgNQThA4dos6nUk4IWFqRfbro7XgtyDgN5TAW16OEK9xXFWThexV0Yvklabvp8RTq7AMgQfnWE9UUX_HzAZzV-hCjEaF_gozJzQ_SV4l04wJn3QGw1px57nTSaRN-E7E-lmgchrKANjY3ZTPSLShTfXOHPR7wwgCLCrrEFlvn-x8_DxZf5-sO0J2x8kG-2S93nibbJeOwvFUecpQhqPFqD_0dP1on50ns7tkPUrp2-wqw1B8rii8FocVIwwW2xZBil2IbBeii43NMYhsF4LtQYwqubvdAxDMH9mtGBtCSK5pXo0MLA7OB5CBT3I0wPm54EWYFyoucLoHkrOFH4MvOc8JmDgJh3WfFAmfYdSxwKQOc-cQOpxhj9xYJuHUDw2cBqsLl9LE54xiFxWnOVNcEnJiBFadxIAKOy2FD2pz7pY8xAkcJNMOwDCS0aWMnIhBrI3iprOlwzKZhL3vaLMXVdo8R2XilsBgpNpCKVPHEyiDQyiSL9y-KFMMqb6qCE3KZFg5PY3U95xeF64Wh-4l-wW__T80FleFcUyoNnGcs_UmCfhy2V-J4IiJJRirQ88AzIYFZPqaGQjU8keuaEy2GaPh-JZ6CZ9QatmGtnk00-xmg0HIBkuhEr30NeCwlgx847bR6GgnjIYpFIbPNrUg_nT6Pe4CY6M3rrBHNUv1D-GG3gTHaNS2tHw_tgH_srOX_oG9TCp-51Vz-fR2ToJbeSaBY0hRqFSm4r19DQf_IxOcGx1gQl17XX3j6EmNbS_1vvDC5d3x065zaH1v8LL1_UFNnu5we33lkI_c-DucWr0fOnIfyMo7wKPjgEbt6gDjBbfxdNOUDrokT61aHUTRCqWkSwVcd4i-yEMZPRgcpaeBbnkXAUgtxcJNUW5_XjBv1ckx4q3KtFlOYMNgl0YPfGeG7kf1OEqHZ-NS3UNGwUMCPQqDI2V_dN9c_rkF40qqSRStJmEQsw0z3IfpeYA6VO8JrNoemRKOmXU5k_91Ax5f6pdzfDpT34nkdXmN9V2WvZ5BXjhfPeeCx_wbC1fX7-4-XG8uQROBpXTMq9Tr5zpMyt_562O8zkJMf_fGYk7VNvxcMOO4abvCKEr2p6gpBjFzTOr7Au81_e7ONqgLrV1usFGge3S8O-KYrRPK40pvXTjQhAi760W7GtMJu0kfdOXzRFRfFEYJuu1YxrCloXLMGZRE7uhtR_8KVRVhz8Fkz8Nk5SHaAM2ZxWJ9G4vahhJrQqmiLsiLqCfDl1FvqWOLdfZC4snwSeJlTJd2u8RsR4MlMfsazjXi_jZx5WjVKyQL4dp4Mf6rHe1u-y0NmFNlXBaZm3a3rEhqNyk0hpx5UWfl7XLpd76v3ip7N_F-y2NDb4xRZUZ3dGrj-zO_lG7PbQ1w5Z23Vc5AR5DBnKkHsDlTFrrjdq8PGeFSP22p7Ky7emfLELEuFE5CD52_YAlfCfsJWuRzQzkH2VFg0xsstKAvZDP61Wz8lS-ztox7CbcPYHHW-1OBQ-9aSUJ9PbJtQSw5M_i9H2b7Pj_PjWZxuq0kwgv5ckhTxa4v-KqJH9UM5cBrI0nTN1wc36Sx_nUVm2pTFUhlWv4Ws2qYiZ-u4PUroLxenrzNuTt7PjrOkdveJMRfYYSypUrU40pqkrL5JFi9-vRgQ8J6BuzLviJpyNarVVGE0N-x-VtuH4KhqTs6ijP5KpzQqtViiaTBk9NFnF5U76GU9wrhXvTzVWiFlxzfJsCWZiksxjAThjxbsmENuPAq8ydlENUm4Kt-bTqZcvko1H25TRzRbEHh-wMuQPUIa7zBGkXRalSGyH3SHSl6vfMXSNE7KkUPZ65PSdE7KsX5S3TRPy7F-RFd9I9J0R--RBeDo1L0R0d0MWg0DvvSeDypeg4fQ4YhhBAxHbcn-I4nk-oenGiHUbSiAVSNtgHghJM8RIfc6J947KD5I72FeYOxmK72fCKrUqrkj1z6IECvGE3na2hemji9Zeo-fI9xstmLeqN2NGl3R97LvzT-Aw"><img src="./examples/transit-hall.svg" width="270" alt="Station concourse on an A2 sheet at 1:200" /></a><br/>
<b><a href="examples/transit-hall.arch">transit-hall</a></b><br/>
<sub>A concourse: paid and unpaid sides,<br/>a generated run of gates and kiosks.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVlrchvHEf6PU3SRpRKYAqElCPDlWFW0SMmsSGQKouykXA4x2G1wRxzMrGdmCcCJUz6Ez5DfqRzBR_FJUt0z-wBF0pJt_CB3gelvp3u6v37sJhzDv_cSWMIwgTkU5VTJFMR3pbCynMMvP_4EPkd48W781enJ9qvTizenl-O_w0yJa5fLArq3O_3BcKvf2exswukt2pXPpb4GVA5BasClmBcK3TOQDiymXiqpUdgeTDEVpUMotZcKGIYfpYS-LsU1wkK4PhzrzmazHel4ybSUKqOn-FWB4HPh6Zfzi8sjkN5BitpbLCSmSN8LSFdK6szKVCjwQt_AypSdTVgIdQPCmlJnPRA6Y-FogZk12tMupmbh-nCZSweFEqQQ2lQ6dDA1Poe0tLcIM2PnjiA6m6BNywLV3jQujthEAMKm0F32VltgRSZLB2P4Jl38K00X38I3c_He2G9pVTQ5fH38-jWcnrw67dGe5qx_YfFWmtLBLVqPS_CGkT_u40kVoxGEMvqarCNtqhDMrN5QH05wJkpFW_8kZIS51Mayjr60muwwSdPFBISDzIqF7jOeNWZePVd46KbLXto2SPgIeHE2fvHu9fEYXr6-uBj34cw7EBYFmXSOwpUWM3Kx1KvVJ2y0W8jxPwZbPdB4i7axq0fnUCnhpdH8xbWV2Sfgkg-J7L1IUacrUGKF1kHpMETH5cIAu4YDb8CiyMDMZvwcMo3U133o7mzBZY7BrTKYiRRZY7gcvzslszoOybdfvYLJ8aSzCamZz4XOXA9O_vYSJsfjFxNA7aWXGJY6w0-wxpc6E1FjZcyNY3SPGZ2A0Cv43pg5HU93sAWTTJJDl95MIBVaGw9pLqQmd6Gt9QhXesjkHLWTRrv4lFJntZI5xfAKXn3x7LKzCaNkJxlCZtAdgdAwGU9AocjQQoEWMum81Kln12E7wqTIJT1dqW1TehCpNS6gkueUStjOJntSDxa5VBjYg9klbNaB82IF8Sydt0Je557UFhk6WORoWWgFU6RYCMd05lyJGUkdD8g0O0eDJOmF5xp9S8Y1WihWiyLRofbBY2bk-RWBNByVcxA5-T32YCF9HkLYOElCtEIs0X2wS-dtmfrSCsVeCEarVb_DFLTxpbBTU1o4jry4Af_sAJSa-Gs-70CQ2EmSDkAhyLzHA-LVzKWiwA6AS4XCoFkHQBvrcyiLDkB97CCU4oU5ZqVCtrPrdAA2YXt7extcjkodgc8t3mNaOkCimOjGdLl934fwGJN83pnS59sonIfUWI2W6b60mlyUaJy09WhbhDXeGSRJAlb4HC2RrYa59EQKv_z4EwP7JpjuMvtMpOF8EPJg0D5MiKuK0kc_40RSHc347NWXl2BmAdeKW1TQDU6uFO2V8glm0N1LkiTpDQ6SJNmC7efQHdJlb0hfb_UgR8GOEfRdoPNb7MFpzsgxx0ntZMZKtjNer4rnYGnOTnDx7vLr4_FJH94uREFR6U3FuhyNyLhOzBH8wgDqrDBSewfX8hYrx07FLdZ2186jyPodiLpln_N5Ay49WmnI1DK90egc7CYJex9AN-klW-EqWGD9LtiDv-EU2DZKxfzhONNFhRd-5btUGUeK_NByQt76ndx-xN42K5Wq_CTQ-8KAw7msqCNw6QdOaLli0GQ_et5kW-ht2i0lePKDorSFcXhEPEgLslgA0Olb6T1qclXOJQvDoLlQt-joVKSLxww3iIUDYuIVYHaNT11lgFvp5FRx5eRDSNgU-_AFlRoisBWjZjE_8zHXTnHHETmUtp8HR6ML8jX6HwJ--zmv6K15yYS4GyfPJo4S0oT8T0BmjCXtpee05UBcE716uPzy-BIyyXWd0eysrbjwQl-j9owrfEh0xtiFWG31qqxN5pIeFqZUzLmiIRNb6v4aQcTzpAAJyOTolfua0jouJogEg8bs5dDdDe43YEdjXU2tLvGpD-VIFA22WRPdC3HrTGUK4QElUw6Tati3RaEYk9GmlAmFXfEDU6M1pkQq5IUFJfV2bFW5uRDWy1h7VOE1aMJrlwNmZ7geRqxX_LbyIlrYrGjL3VnRDqYPMs8DnP34p6VWfSpX-mHVKMrj0XQHO62D-uF-pMFjULuHLYCKdh6Dc49vbDdpI8W7GukR0aDJwzr9qg4kuqbNxz91L-w5SO99oPzMrNBeLR7Faasb74bJA0j4GNJwDWm4jtS4HhcXv8XbPigm1grXOo8XuWzqyIvzwERSzNGjpcrOmvI6b2d8KpwDVctYJzI4l3wLQalTeo7suoYMUa8px0YuI35YSIcwxT68MbdVrXF-_OY0JvnAjKXPjX3q4L2ZBt5MzbyQCm0s1i0qkwpPZVVTbxOJzcVNfG6oPJWYomKiiqVPbPSodZWay6ipqTJ-UJTK5VCUTlgafvnxPyD8hOiJkRt6urLtji0w44ekEjYBGxcpCg3jILrRFklGJFJSB52HIrN-EOIsNlKewi84L3-oegb27-XOXusxYxJ5JZRCu9qghYyrJFm7hXyDqmiQ26HxIPJfSOSlseg8Az-AHBJIhVzHfb3nHTLKkoEr5JdSecsdQwAOyCVNRvyqTnaUKkJcVMmW60CzwOyeSnlmlDKLptptxisi5CRMKWeGJslWPpoqIecwU5TTLt5dvj07OV2rNo8CoJhRhRJFTBkzOoX4_Of_Bd-bUmTt7B324RgmbJvCqNW10XX76MlZqe8TNp1w1RN7SFfV51TvVhWwoOxP9QRNOCQ1wTFshU17sXLa749-_m8PnBZFgRlIvRC2Su7U_MB8zo0QFxFwpl1q5ZQXtu0UQFHQPrnJArQUTDMrQlFTaupRuzt7B31WuBobMKq5RdsPxUldgzBIqmThqh0_dTCT1nkYwJy1pqiMsxtqiEH6dsA1UNGI7SS5ltXWW43u6PCgRbfVFVcC0fdeVNAbwetiOUyKtjbAzN44dZvEQ7gkHC5JK1xOtbdCpwgvSXYjOjWRzKoF7HJTtCM8gjYR_iHw29wUG-0hCwOb2Uym2LaZmLXMtZ531s0yOhzSHQU73R3wb7vxt4MduhsOK7N1R_v8zWg__L7Hd3sH4W7IsvvxbndEdwcRd8ArDwfhLuHfDvdr3CFz0O7hYciM7V5oLU-uHZ6YVeeWSZoctFKoKVDz1OV3p1DG5Iajqkup5nXgZJ07OXT6MDG6XiM8_LlI_fMJNx-uaUemKxi_O2dQhfra55xchebaNDXaWzktPceA4-_iqvGffI5e9GieGlgiNzarRlqD0ROmCcat5gKxV6aZUxhE1YM92slTHgdZX7Uip8dvL0OdHwJ4raUKpFlqVzdRdc9UNVFMwr3WZgh0rXsI8xwxm4WuQWofEnOTAEI_sj96UnV7PmduYNE4rwjNVxwU1vG7RYQRYLPPsytr_BXRV_s8aFsLmfmc2-oPlrs7y_eb5QdJ0qkT0ZzGfliFt6wnVXE-HQYRPZ6UjZ5UZ8DjAmprS90Mauk4AsH76iyaQqvupNanYGwSOr7PQiUnJJ9zHNhs84xkIXVmFo6haZK3YF-NUORS0jtUM-Z6aaEQmmopnn632tSqDZYW3ov5NLTkQq3bmY3RFDMxYoPZBsMkCT4fhiXcQYMkYg07JIjFlbDpDm0uLBIehvuV4QehK7uzerC2epTcWb0J56YaB4UZLWUyL9MbirLIC6FFbUa3EyW1n4DFwlhPTp6y4zFc9-uri7-enp-dv7o6v7i8Ojl7c3r-9uzi_PRkK76s4WFGU4tiRlGeC51xJDlOqGHcHxkj5MpIUT22LyVq_t81s5lDD9Ri0xE4L3yoUYOazUHxaLgetPTDuJIInamWzL-1_bw7Ipbt7YYys8IGj0sPG2SyjVpuFOh7EOXoorc7OnhELp4MOcBOHHHFXZI_tA5_fe3oE9bWRfVHrN1rF-H3r-9A7QIy-9xccQZuZfXRvQ4cm8S7wpxkSXj468J4VzgUFU3s7LZjZ1hvu9Wc30Xg_iDYftTUQHf1bg0L7gJwG8D7P_w4gEErw86k5_7xD2lTv0Cd5ujAVl1hi4h5vEvj_e9KkVnuNlNFLzUit6bCZpLeQHBeDiE7GD15RgTO-edZlUjiu6VyvkV1OVECesjQ3RBBuqoQ5oNZnwLyQV8jZWSY4QK8mCp0PbjBwocEWO0llu5NQxKZKDTG9BRuLxhVC2vpbWoHYEYvB3nGNCVLBLcYDkdJ73A0qtsyylvL4SihndZd6APSg9Hod0vvHAxHVY37KdJh578uvSbO5xArbJ7hxSK0bhuXB00VfNmc3QZh8pmtwRH12wg3ZCbbHdRwoyRZjqgFvVc09rCsyT7vZNDsZD9Jlvtromuy7BkhpnbvihIxLelPrQUt5v2Tgz2Es_8H4YT9jEa_CSfYhHG4p989aHD2QkcPUEs2LHH3vV5ood9ejo_57dF9b_XgAY44ju8WcsFvJDLhyzkPbKqXr6mwll7zaqPxM461OIiRoZquEzRFHL9kDJPkJemVNJc8tWhueTzS3HKS4dtVI8eXg8HaL7vrC4dJNWP-ofN_"><img src="./examples/aquarium.svg" width="270" alt="Aquarium with a curved drum on an A2 sheet" /></a><br/>
<b><a href="examples/aquarium.arch">aquarium</a></b><br/>
<sub>True arcs, a circular room, and exact<br/>πR² areas — never faceted at any zoom.</sub>
</td>
</tr>
<tr>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVltbxs3Ev6uXzGwgUPcSM7qXTaaAxw3lwZIk0PjIuinmtodaXnmkguSa9ktcrgfcb_wfslhhlxp15Jlq6k-CPsy88wLh8OZ2WO4gH_3kwTuYJJAAU7qpcKewltUUFQOqwL-95__gs8RPlz8_O5t780v7z_88P7jO1gosXS5LE87x51j-JILDz6XDvBOFKVCkA4Wxp4D3qK997nUS0DlEKSuSdwrIhKQrVApqZddWOVokYUZlXWO4YiZwcnfMZAurEi9NBrMgskyK1ZSL4_AVgohF2WJ2oE3oIy5ASuXuT-FCw9kYgHSQ2bQdY5BG892WWMKUGKOykFqCgRTeSjQW3TghVKn8NkEs0olNGSYKkHvBHz-8e3bq3O2HaAUJVq46IMSOnOpKBGgqR8pL52rMAOjQYBFoWA26sMdjM9GUBTgckTPWC4VCqF_PkgSWP9WuUxzKMQNuuBQEFobL9gXAhbyDrPgpk8f4erHi6ugHwPu_L0Yno5JbsMBXUjCs5VQCpTU6LrQ5yeFsEup3Qmbe9EH4aOC0rGZqdG3qEkZoeDdm1dXUFp0qKOCC2NBQFnNlUxhXkmVkU94CaVjtc87xwzUCMWFMb60UvvgVJI55rdDWsuC2KW-gZX0ebCCpBCGzy1i5xgyWaB2JD_NhdQOhM4CgfQKYa5MenMKP1hT8tNrdvw1G74m5WUBUXnTW0jvopYL8o0nDfrn4wReQf-cFH8VnfKKHyfgaU8QG4cahXY3gIoiLvBph8Pq6FL6e_iJt9sR_NEBqDSxFUUHYGllRn7p7AqzTiteOgDaWJ9DVXaA7HesOgilOh2AY-j1ej2ySSl4Cc7bKvWVRX586K8DIU5k9joA4p1HK3kNZHqj0TleqT_gRdJNTuBFP6Ff83JC_yf0Pl6lyjiEr0HXK_JUKTWeg9EIEyggNdbKLC7zolIKVjLzeZ0M6sjqhqDYJB7GMyXqEHYLkP4U3nsHfmVgIVLa0HXe0eqeDQuBvRRKoZXoQCNmp02jSbXfNJTCeslRvrF7UNs9mAQLo8Hx9usWjNsPMxy0YOJt9NNHXnFrVpDJW5mhdfBirTYHnA5Rh_ZWpgicjzhZI6BwHlBnJ2vL9ujB2vP6hauH1uxhHQ9q1nB1AOt0VrOGq4NZ-6OW8-JtdN5nU-1zHmpvhU7pZFEqbN4vl-C8SG_WKSIVC3yW_4bNxYt3MfCfY81o1mQPdwewT1vSpzuly-z1Kv1tRbltH9KkhTQ5UJFZi302eVSR1f5tEQSPWjijwQ6c4jk44xbOuLXDOGvq9TbrfcOvA-GsktnrJR-jITnyyc2Rfcf_4USGo3ccivfQP2oyDphxvR2fYh60mIfMvN6QTzEPm8zOG4vMv96VgZ_Q7nhn1fyfifQIKocOiE0ssQFkFgtKRRukuCubaIMG2iemdxEvcDfWxtdHxV-1NgEsLE9MOKxayCF3TUddGp2ayrra2FTatFKh7skfHLzrZPNXhdAo6hh3E-vIieVuMNuxmKPmYpJyzN7KS8HM2RbE2zoT_iiUiqZSdrwPRjZ0GjNoK1s1lnWnXuOmXoqqOo6MLb0mWwgfzHx-v-35BtwqXQW0yZaV7Cj-r-G-XMIXU6COiKu0BVQ0gEZPAv20G4YKPt8AGm8BNe37J1FHmMpLJf19A4uOHoaabRs32vLVpVjUQZpJKoUaoRmLI3fOeylW6tZU_qAtxXg_Cerw6nB5EYJ-IVKR4QlI7Q2LWB-o1L6sZBbKdpcblUEk4U1IB2tmqH-gSD1rHBah9OMs4bimMZXvwLrM29BHtwR6ckuw-926tLMoMi4LN3nE59ZUyxxS4ahni97pct9I6rjTB6L6w0ZxEkTRk50KPUU1GT-Hqj_eMm4H1fjsOVTT4XOozoZ73Pm5UV6exxTt2l6N3Q8fIrWDueYOxF0uqajvMSvNmOuWoq5dORJMqGfDgRwCqxUls20n90Nz9IAkHjr7SFqvG3G27lDW5eBLCDub9yZ5bW27ohzV0jDmouke8THLPE0y3rJzs6uXSvxOGvd633jgrKTOzKoR6O0AaBEMz54gCOG9hyDpspAHkdgiGE32EtT9VvIcqtH4YUC3qcZbSWebaHy2m6hx-Nfd9nlsKu8hNaoqNMzFvYNDMuw_TGUjswOaCIStEGG79QaZi3uqdm3WK43UnjobK7Oe0zQlCy2fQg9vLn6F1zCbskk0Q5E0oktOT4c8iQhEdwm8BgnfhVKRH0ftyfq7BF4STpdhNoc1FUo7aQfw3UH0TNufjg4D383wdb13qfvPEMtYmG16_VRYS75DaSkX8QqdPvDOIHqnIT1UAC_ZT3zdhVE_eUrnHVzjp7nGowbX4LmydnDtltXsfJzQ0gt7T1NGCmD3Z-dFx3AtljSJ86E7-15mf7-mtEknBYo0h1JiivDmV7j89PHz1c-_XF69__TxvD4kHHqwFQ3ylNFLHq8x6mrdnGdY-pwHuS7OeRzPd8JbWw9MpYMMrbzFDBbWFHG66qgKkXHcGEZGGl5cSw3fU1InVWV6E-ZCRHsSDiwBqfBCmSVNd6OLeFrkQBu4Jsde8xhZUOkfcBfw5dKF4anF2rYwJtQGUmNsJrXwyBUH1UqL3qZvFVb6vEAv06CANgxai04FlV8ZVCUslBGejyxLbuBBdDhe2Wcc0pXVkvlWKbRWJzTg0e2UBCnwV-nq-UyUOA9mmj0iaS6c1G2-enYWOadnyZ9lnQ0brE_oWuzySvF8po1XDmCaPSJph2ktbw6TP8c3bfBtMgH3Gwvpe_SV5FvqiY0iqam0R7t3dc44Q246wFljzICWprxHpCtp18L2Yq6wUczFgz70R5Tr6K9GuiLip3BCBXwIzsZ5FlMsOf18YzG2USxDdwOh6Aql-azdwzc99fNaPHGxgrFzbyxGLmTstKgt7Q7PBmu8cZLcxSDcxxcclIyfxbfphUcjrmUbjp0myd20wdeoamP55DAkt78FnEMLXQb8pBHmqNOcMyl9Zwg6UVVVy6Gs7EphHfZQ4VJoH_pALEof3t5g6SFVKCyYBePW9VddpYm5ucV2vo1iqQI4axSrm8WLXlv2H_HZYFiznUDbZzvYNtJG473SBo-t0NleaYNHpE37e6UNH5E2He-VNnxE2iCE0WPSRo95MvRjO6JvB9tGGpf7raBtSRvv9eSj0sYU6uET5R9QWvMvTP2DL4T0VVn_Nr-Howub5h8EfQDPhEc4GiSDSS-Z9gaTI_ja-dr5Pw"><img src="./examples/museum.svg" width="270" alt="City Museum" /></a><br/>
<b><a href="examples/museum.arch">museum</a></b><br/>
<sub>The largest sheet in the corpus:<br/>A1 at 1:200, galleries, reception and cafe.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=pVbNbhs3EL7vU3yQUVhCJYGS7URJkQJGYwQGFNloAxQ9WdTuSMuYIjck1yslCJCHKNA36Lnopff0TfIkxZArRWnqIkV9MQnNfPPD75vZI1xbvV1ZIzWctWuP7t1oOD7pPYbEUlvr0JTWE3wlc_KQjmBsgKM8SLPS5IfZUXaEOTujSljobvrbHj68-3WOlbpjtwgOaUCbSqtchT7UOp30dpBr66mAU2YFZXwgWcAuGVaGOb7G3KvXNB_iRWPhS1klxF0KyKXhnGhTOfIpx8LJxqAkR49jfsD7P7CSWpPb4sO7nzmVaR-Nk1XFUUNJIBOcNDmhlFrDGgQOpwryQ1yGiCvRHZ2MsX7_ew_Ks1fEBmgj8wBfWtIyp2RqlxGWq-rHpqngMRrjz18wOsUaC1ubgoMv7Ga4y1HbxWILpBwRnKzotVVFH95GtEWtdHQqpeciYgcKeFuHctCQD1jKXBY0xIuS8NIqE9oUG-4GQil3JlgThVhEckfDdSuPU_H-tz6aUuUlXxt2Yav4u62DVoaOfQu7VsHxE1RtQxxhaV1ixcUduW0oOV3SntjCukIZ6baP94i-H4-FtY4rKjAv1NpD1sHOYUgxJm6NbWCsy46Qy10ZLauU3xFP6mFWaWnQedY-9bSDNxlQG-79ep0BK6cKjITIgEpW5HB-Ai1N4XNZUQYOEkrUVQZOa01gUpEJMihrMmCfHKTWbKSCJrxB5exLygM6raCSnDqJiTeLLTrnLi-n0qw6eJtlSN2kTSCnrEMoVX5rmL4nQsScga7oix66o7EQh6dHQvDlAZ9Hp-myP0UpZcDbXQRVPPGVMoRKuqC4iINYozOBNy3U5HPYQ5DYl5sls_sLkVK2kxYpQ_taxZOdDvfj4p_rPExo8i81x15puSC9f_fOQbSkqH2s-zK8t7mH8FPG6kAGdCdjthBjNq89-Tg-tlzmUZTefpp4pl7sFeF89mx68fRztUZ5qwBbkfFQJiSx7-UfUVMhaTCwWhhUpveJclA-Thm5UX4gtVoZKvoorQ9URLSd9NDI7ZCZzBiqeBITZ7A9GWXA2egrNKoIJb-sgG_SbN6X146QvJTKeKxJ-toRpLZmhU2U8TYWZayJAxpB5bcHiXNC7exiTn0TgedamTCHo8q64Lkh3R9vrq4vZpezZzezqxc3Ty-fX8x-uLyaXTztoTZBaTZSnlVJxitrqMBii1Kagieg8hGXc2CjuBSuZqkbFZk4mV_K9QLBpv9du1x6ChC9YdI6upNTfmgmR2_wbffRA76NIkt2tgi0CehwozoHfVXGUKw16Y-bKvZNHQsBHowETctw2N9GmcI2HyWn1aoMf3-e8R7pRAiRWDcYDAZYqjCwdYiX__MXET8ZZXC0rD21L5eX1vGg5y-Gi5vr6fl3FzfXV9OfWn4aZWhQ8fZpbSOeISo-Wd29yBG6i9NAEe9eXiAqrbaFt7oOFL8C-rilKiDXJF27WSPk9Nhjrbzn9r2qZeGkCehuwAIeJElji0m8sZzbLZXEdOzTYt6BtYPp2Pcig9sFzp8BcTsdt8_0qpYukBsUyueeebKsnVGBBbAgk5dxPsTQkTUA-PsFo4kQGxaTMrtI9_hO_rMvb70QfUfiTIj-g7PoHH0fCrF5KAS-xDdSffLlvgX5W3ystxXGQc4TIXbD83vKqYprg70690HySIkc757GETs6KOWs7cKh79vsLw"><img src="./examples/gallery-l.svg" width="270" alt="Gallery L" /></a><br/>
<b><a href="examples/gallery-l.arch">gallery-l</a></b><br/>
<sub>The polygon-room flagship, furnished<br/>and tried against `theme presentation`.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVptbxs3Ev6uXzGwPiTBSaokW7LjNgWUVG2CS-zADs44FIVF7c5qeeKSW5LrtZoEuB9xv_B-yd0MuSvJL821OX2IrBX5cF6fmaHShRmMpnALJ1BAIdZo-64UCUKdG4dQC6UcCIvgc36mwrN-ITxaKRSUQqH32AOjEUq04GSKg06304X3JskRpANtPKSYGCu8NHoA5xoEWBQKUitqqVeMnguf5CA1AYDgY-DNJX_lSkxkJhPef9rpgvTgxMZBYnRi0SPkaLEHSyuTdW3smnbRA6EJsFLCYwoKRQZSg8-Fh0wkIsUeeKlIAGsqnXa6QU30YI0paHsKAjIrClToHKyU-A1TcIlF1FDTGeGkoGWQWXgQSg1gZpP8rdCrTpfkJzvywcKxqUxJuggFiRKVQzAaFrR9ccq2A9hamMz4qdH0E-v4KWoljf7kpcJPmjB_dolQCN_p73-Bn4Ve0d8prr7_hSFnSoGTtyDKEoWFJSpT9wBFktPhpDgqLFB7ELCspErRQm0qlYJIfCWU2kCKXkgV9KjFhg3U6bYY0WnK6BWgNtUqB2_I0Sn8-5__AhFdvDEVJEJTVDhk04l9D_OKXNxgp8uxU1vpPerGMq3TAQ6HQwCW3dcmHBwc6_hEjh1vq8RXVihwOSoVvMpbcpms0Xn6g930wEsGy7A9KE6WmLC72ATSQU3vibBWouOV1piModhPAWR82EiJwnlYiaXCHiyCt0aDCQRfPR8uTjk2eGtf6LQv-kvpybSlErr3sIi19DmDJ6ayjsSorMaUTV9pmL09P_spxDU5R2rnySEmA5FY4xxIz7jbiIJxa9WazBMs-sTdSaUeZ6-mgJbegal1OMGZYB2f48MCcx6Se8i3dIpwDoul2lBaU1jqlSPpaclDJuYoYmgK_Qg62ouEq1dQCuslqeN6_NhotYl8dtepLO4KPeOljMz5dBfZZJlMMKb_aWSDHilMfORN6cARj3CEcXjLVe5DwEnvHrZG2bBkikou0QqPagPzd-8__B2sIHYh-TSkmIlK-SjfU1NQTqTPAEaTXc0d2hsSclf9OpdJDl6sA41HpHhytGanCx9ez-Hy9Xz-gWj36vXsA7yb_XV-CR9ev7mEi_nsh9nLt_NGG5KY0wsTw_kUDCkdZOQUejd20OnCohRUFmaHoIROXSJKXMBf2ug_nQwXTAEaTEnayxsSXtpTwBu0G2CiCHG5xMQU6EB0upDJW0xBV8USLQVzIZWSBXqLDs7PWJf3s_fzC3h6OJhAUYASS1SuB8P4UWp0z8DLIkYVy9PpQoraFFILb2zQtSGS0kjtudBENqPAKIqtpdmJnBJjel5zHeMKcsgrSWpOJZhCUQzgtVA3kUm8gdEp4TWHicqbfib9E7KMq0lH4ldXCKWoyOaIPogRyGzT6UbzwIgOp8eHUBSnbeY7cF4yO5s12G1g3iu9PseCVFkZTYUcZttS5ERR0vFM2dvaLTzkglN2SZ53FaZcBYNNt3UyRBzVw8reyBt0vUAW0fic7IHqISU62Q1_hRmbadc4oc1YKFyhThctV1AbE30a5VW4kkuFkFlThC_YfkIZjYFyXc0moEhttO10t4WvchiyuulyMnnrK4uQCI8rQ2HaLC2VSIgViApTtPIG2xDiPiHUtJAuhmpZJleEFDmj-WKNWBJROY8lLDeQC50OYJamTZWVHA94g9oTGbY-aqsbVRlYWVOTs6ypKYIiUQ8o_XJMK8UFq3ALWCI7PyR2I3egcCcKCqHNKW8_Ox98czZ7N_9mdjGfQYAP_AbeeBIgOpuBmzajCdPm2wY2JLCDhbBJDim6xMolQr__D2f0AiyWxnoHlaZupBX6518WwffnZ3P4Yf72zcv5xezDHK5mF2dvzn7qhWiRmitnZUvjsGkerq4vX83ezq_P_za_-PHt-RXcjto8CsqLpalCXXo3u_jpzVmvrVOlWOEAPrTx09IdI2NBNpAO8FYkXm32KA-eHo2HcAvj58dQFD24kVi_NLcwHg2H9Hx0dDIZUtIQIT6LfRW0ASEdJEqWJabfhhgncTLpwbILo5VkqMTLKl2h78FoesjYJ4F-oGlMmrInVoK6ARgdT48ncAvHh8NJWNfmtrAowOgkeLQQdiWbeprKArWTRgdQUjR84aVXCEtlkvU2GGsTd4e4jDOFWKMGU_kBvPGxL8UUZIC8GQ3Gx4MhlS_UsKgcbXyvhH5XLMB5YakRscgFL44QyyYSiT3aaFm05mypwiRJVW4ij3tbETU5ybUn9i4Wya4KBXVUW4s4yP_bzS6p_f-1kujVhoFdiZpsOohR9oENJFbaOC-TJw4sFphuAnEmRlhHJE6kF1NDrNnNPnbcKWbYelnhAGahSQtFgrp45oAm6Xn4oL4JbWi3OZeXG35vkk86yFGkaJ8E-zjUHnUSglc208kf7tF3O_QBXJq9YgrkKJ26NhB2KkgsFNy-ks-Cb8BTaWqYPsTMINLDjVAyFR4XjciJQqG_vfMt9PvOW5n4LX2w8lzOqI-Ggytj1y435QF87ABUmo4vig5AF0bDkO-T4SkI7txDI8_2pionYDSaQC5U1ucBQqNz20p69aopDSHEQzVg5EWmKpcv2rRjxB9nr-aXHIexEq6sTHeqKZO4N4C3paUJVNw5mZKawEOvFObPtjgtRbImvb3pgbHB_lqUUFYujxWylJggSB3tHSoL0SCjuqok7uRZwknfiD7oQJBzNOwA3O_vOgDb7q5DLGZ9DlXZAWINx_Wb6iOv2y1DHYhR0KGv_CbeNsBHmuLMGk_hoDvKxmJ8dACf2yW0FT5SoihakE2zI8xoAevQ7_f7YfI7hcxUNjRDvfD3Xkg7Xvv4qwPRPumL-jrohLeUgGzbxiFMtk0xbkfVj_B02Bs-g6ej6XDIf33eg3Om-sNwJ8PhFjF82AflafMhUArrFjTE9_1hlA5ppf2dU3hGfPCUXdF3xsvWFlu8rafCTBFmGErj8gtOedRVXfgxjBK7YyCx-r7PKcv3r3ViKoRhjxInlVrYDUNyVQsXTJHovLHbW6T48OrVYMdC5XUE3g4KWxuNdm3EQydZfRytToNe-HB4z_DltSslDakPwvJMuPv6uI_UfJqc3Metk-sa4Mvi8vT9cR8pfjh5QFyTZdfuz4s7fcwMdXKt_7y4010rbMMwNK_9r3x1IJCTTF_Yayo4ANTjPW2cSy8nf0NgmW7JamFO3S1RFXUgFUWY3-wBxusIAtyNGAY8IjyyFjSA57z6ACAAhs37AlIsww5esPYWb3yyg3dJqwku4NFmsdoHrBPWcAsY7LwDON4BvHp1EE3CgHWy4w5Toubu62vd0Y3tuykhNcaCUzJFJoHx4AiKcDdlNFDXTUJwN-ZqGsYE_FpR08nXDTyGStf0byKUSyW5sWYQ3uTaDj7cCvPAqw047q65eRdlqfhmi26RiDdYLpm-SEPENKBGQ1MmhAd2bS1Tn8P4iFpC0oPHnj2EElMy6P7e6bTdy9NHEIZ7gBClexAxymiSaoiMxpRJi_H8LkQbWjuahNAKIIG2COTocRDesYcRo4kxIkURxqjFOLmLEUKoljo1Ndcqqa_1KFgj1G_hqUrtWvL-hvGdDdMvbTi8s4GM_Ls76uihUEmF5-RoPHTywAYTN4QCv-8OYrT7JyR3Nkyftxto_TbTMun7NP_2vz7T5tyTJsILZVbU6t_vS5vLjOWGeptwVU8_8TQV2NFPMZV221tsRtaioMmBEyrcaJY-h3A5aLKMx4lMJLjty2Pq9ulufPeGo7kRCvlLObSQGr4jDvt-AaVM1m4AZzGH-QaHRh0MY1xoDTxSc01XLOGaknI4q6yWrKtMX2TXTuo1MzO_7U8ATaBEbSfkeqm3mXgHaok6yUd016-Jiu5AhQiKUBzZTLbEFrfH2-LykkAOvnjM-H86ZjpujhlP_tQxh48ds2eY55Ov1ObosWMCMf4fjrEiWY8A6C1SPvcXvcm0LXvj6XB4O92CXoS1B9ufmx4DD_d58VqPoA-PqEQf7kOPDrfYs-ZnFd7zu5I7QXS6A37Mch9twckYo-Eda4AT9cEXJU_RUdiHNzbK4clw2DtuwclIt7u9xQ_o1gf7v8LtlJU78CbJhbSxobkOH_iUI9JhtD2GonPSZNdjaLZa0YnhLQgbW6HGEs-pcTn6Ig5z3H4sjA_3PUYefDwYgkW5DN6HD8Uw_MsL6wSETnJjYWm8N0Wfr_iB7xzajovC-YHsEE5qCP_ewfKmjEAAu1jksKMJ141w3Uf3KAClNf_AxMPBu93_SdB0sryEfyC5Xm7goPl9PD4nHj0YD8fT_vCkP5rS08-dz53_AA"><img src="./examples/materials.svg" width="270" alt="Workshop (materials)" /></a><br/>
<b><a href="examples/materials.arch">materials</a></b><br/>
<sub>Per-element `style` overrides — wall<br/>materials and hatch fills, furnished.</sub>
</td>
</tr>
</table>

**And one that is here for its furniture** — the drawn symbol catalogue in a single plan,
from the WC's seat ring to the wardrobe's hanging rail. Twenty-six kinds; not one of them
carries a `label`, and most carry no `size` either:

<div align="center">

<a href="https://playground.archlang.uk/#z=rVrbbhtHEn3nVxSkh9gAKQ9JURcjCaCN6bWxjhXQ8gbZF7I4U-T0qtnN7e4RxQ0C5CP2G_bD8iW7VT03SiKVG19CjqZP1-XU1TmGm5zg7efJx_c3nydjWGhc-lyt4Zef_wMIYWN7c8qctSv-U-jConBG-Zwy2KiQQ8gJNrnVBH67mlsNKQbUdlnQSee4cwzjO3JbsCEnB3SPq7UmyBxuPCAs1H0oHIF1fA8oA2v0XpnlCdzkyoM1BMpDTo5gwS_l8azpHJe3eX628qTvyL-GkCsXtj1SyzyAXcj78mPbC7kjamTL4FaZzHcBU2e9B9QaFuqOOsegTGatg8yuUBkPL-YY8i7cqpDmZF4VQWkVtl0ojdIFre6UWb7KlFFm2QW7WKiUXq2UT1-ewPvACmDn-JEhwaHYJORoAMHndhPxvBW5U1JamSVYw68EMMVqTo7R-K9vP1xfTzrHcDUZX3XB2BDPVOq9BhKzrxWlFO2nPHi7oo38QHCEWuy7sYXOYGm7gCZjlM4xaGVCvGvDV3vc8mHo9cDYEnOhLQbP2oIKHjaodRfmmN6y10JUIeoz15afsg3YsF0gPoiQakKHJhX3p1ZrlZGPnEKzDbnQYIYuzeEOtcowEPR6PjiVhhk4WlsXfOeYSZUGvYXrj2PYoIteMLiiLCruLSjxAltppXzAWzJCJ2fDa5h9P_3u6ubd9Ob6evrxajK5_n4GlgkmxEZ9C6rSp-RAFza5SiPzDd7B0qkMVoS-cOQBA5wmCaxWEHJni2V8rz-QZ51jsGsyotr7ALheEzqOpJxKN7uCIymgC5SVSjILEL4dX336PBm_gQ1uOVKU8YEwY5qzaRc4dypFPsUXRW9GvTUtAkOajJHatDNFtqQMkCF7PVjZu3hXdHGwHGZKE_sIKw1XZAQ1txt-U6MBH-zaw5z4MN2pjA_E4H9rC75KmaWHYJl0mVCGTeJt4VLakYcfr1XKOeG1nAfon8DHa_hw9Zfxh08ncBXDv0o1amks23ymcU56JilL3GYdGw_TnP-YkU-dmtOLlzO2isACMB1ykVh7kpNl4FmjtxDoPrCVA6chvpPfTO2KPCycXdX09icCNziBb68_3cB378ffjD_BN1eTyQ8s96f3_xgziZecSoJECXypsq_hl5__y_BfMsbXM2BO-t0QruVcWBvWTpkALxAWTmVLCeazJAHU1iwromqYb-FslEBGtH4p_s_IqbsS2NmAQQmzI2ylRgxdbyUfhyCpseQ5-5fTTgacBCV1MSxy8ouRqiQE5ZMTZnOLLospi8BJGhbJ0BFsHKMbOWeLwDlPmaUmyNFkvdSu1gVfHvPcSYU6s4uFpzCLyYjjOZKEUvrCwzfjjzeTMWg0mX9oDVeYUq1SH35SwTJaKQ9yMvL0r0J4bheQkgmOfEyr6CG1zpDztUjXQpCcYOGIenVgiUy-5uCHnrcL7AK6VZqjcl1I7WJBBAHnmroQ60X5qxGLVelCRv62KiVQHudQC11wxbILa4XGii-0LcySnFybUapRsvvMq3_TrIadU4qFp-gyY6N9QlUWqkDgLEdaw0wMOYsMmWW0DvksKj88gZt3Y5h8_iu8_wRXH-HzxzfjyYerH6pCx_mShADtsHa2YKXK-CrtVNmtktEaTlcOlScW0d6R07iuMnpVnCBVLi20MJlrkM16C6U1SBUnDyqcwKRY-lp11oUAVxU1yrahK5SMyaQwDPF_krMNa2PktN2hLS64JKZoGqNCrrKMDMcddyHRRqdso8l4XOWCq8kYrv8-nrwbX72pa2ydUqrSGsseZCiNlS2CVoZel-VYPg7NkiC3NgPPFZcNFDUK9o647MgPXDGHOWS68mClnLOueXuOXhnAUME-OlRJKBxJca4MhXicb9VkliGveysskxpnZrFbbfY5CyUOK4JQl8rUEc07J2037PAUDYdZWf9LklhPsEblfM2HmiUPaMEumxcBCqPVbbzQFS3v-cDssHMfMNUkRQiFpd06KLB2qM220l-h1k1jJnYojApfeChMRs6rjLg_xVA1Y7H9zdRiQU6SyJzChsi0bcz9rbTW7cq8ybexwkgZTdEIL1oZK5S3YBoK1HpbZuiTjhw4elu34m81hiP4sQMiqudWA2JjMko6AGtck4OrIXA_4VCFDoBPURP0X8sLxrqQQ7HuAGRq5QGLEGMQtZZ3c8q4M5Ga1-lANIvKvtpM41Gg-0BOWcfqqvTWkPfATc-P8CLpJi_hxcVpIl9-2jktFDp4ujoXv_STi-QRiLfFsyKUBw-gbOg5UaIcreM7528VH4c1uqAkPzXn-_H8KClVkS-js8cy8HjxKzCGLV2GT6iSo9ZTcwimuj5iPCWKYPjDGGctOc6ekIP7hMPqDM_qo_H7k67h9uMwzlkjQvze9pF0Lir7yk21uiPJT6H0ZvxwuQS27D1bAqSdhKMPMtnBK3gjtfoICi4xcd7bQa3ClVErH1eow9MkuWcfVah_iy8fQfUR1BJiB7YkQwMbXd3A9luwn-NgerSDwD5s1I1ergS7EIRBg_AOtW6kqgTLYwZoMOeU9RvMaPJa2bMkuT9NGsy_lBNv_6iNWc7BD2EHFWyLFAI7uNgDO3geNjJHYFscibDJQ1gM-WMLMASzSNYCKvsqmy6cNYE7ljp_YYAzNuVGZSGHyyQBLnMEhtDFcQ68FHwZJqNjdiAjMQWyDF4MgvOrIRlhBzLS5wHk6LyW8uJZSEbYgYy-byBl3D1vpHwekhEeQg4eQY5Of4OUjLALKT5_LOVvgGSXQzWr13QQyDLNY4D-WQ3JcSTVgLdHm_hiLIwYYDhs3jtNkn2vnfHw1oLbfS1WJ7714hBa_drpMDmAFismBhicHUKrXzs93X2tA3AMvV4PHuRIfva7PgJ4U7Zv3PGYerh4HfvI1vRUN6lxyIqzRJwgyg4SQ9UqCnDZqKGTLlpWGLvrN-k_vbKmaYBb0wU3jDyxOIybxdgNnwh0ueHT7e1BuZ6QASvOGNXkxXDV_qhsAJsmOFeZtLCCK4qVbWJ7BOFbZQUrm1O2Vv3hHDfgFBdTcsxx50lyP2DvKdMkiQYg3E25YywB2nuKiplxMOA6uw-DRZ3qlhBDrr9DkSIKIaVmlCRxC0HM4T1Y0c3T0s0BXlwmSfe8pVBfqvReWapxu5FFhOnXSf8ySe4vRrUkl3uVKsy0Gq4FqH85Srr9Ua0Ux8H9efI8kgzubR9xaHZb5uGiefZAo2O4Kqf8FJ1T5Hmd1FpfN1sha2BduLX1cXpq6DSvh1fB29lCVbsyDLwJXZVb4Lgv4u1wuSza3RJJaCwwbUh6S9u48pG8ycP3dxpT3hdtZa3D2_FbKmlsTbV3LqffXSpHbdtUHiXd4SDZNXh_P5XjRqVFHeZ-dzhs6n2fY2E_jx1mCoN1T8WC5NUyFCS1NhB1Liw7u9fNJs0VprVRam2oYmgJ9tPJsB0RhWzjnw_REReQaKpBm1JNb9mgls-mXpnbw6hSlvbixO0D_ArpzoeHcCQxT2W98YdwMuXzDW9R3LM4l4dwykXr03rFpu9RYnwKp1ivyU2rPcpBnItDOCuVOrvB0taHcAYH_R43jO0wG10kSZejoowS7mruLx9i1CQv54zfXeif5HjjsT3KVZFXR3_ZmrYc77Y1wiGIUbIXQmNhMreNMfEAQprpylPDvRAbDOSmOfF_DkFwAWtB1Nat5yX4E62b2WKuSYbxp7JazZzLfi1V2aY3GIY7n9hnHcQ4vxyM_ihGPxmcj_ZgbNBlzs7psZPLVr8dBXsw7tAwg58gSrmvqAU53w-SOfL-ySzzAGQ4GO2APPL14M_0dXX5k9phk_0Gl22pBruqkb_di8H47czX1JvzKioeAcZ_yJjGxkw6oNNR0r0Y1DlnpwN6dHxu7a3PSS-ekWdYVwaBaAzNevf--Ge38OV2I63hEzZuEkUtUBwoWzrJHv5wJj-vK8Kj4-Va__ce36TP17XLQbJf-JCHYv7weJwWq9tP9-uuMgrP3H4x2rm9AxBU0AQ_wtrZf1IaHm-_ZdKazrdwdOXS_APyxk7-r4GjQTI46yUXvcHZEfzU-anzPw">
<img src="./examples/furnished-flat.svg" alt="A furnished two-bedroom flat — twenty-nine drawn furniture symbols across five room domains" width="440" />
</a>

<b><a href="examples/furnished-flat.arch">furnished-flat</a></b>

</div>

**Two more, drawn on a smaller sheet** — the same language, laid out to a fixed scale inside a
titled A3 border rather than sized to its own drawing:

<table>
<tr>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVvbchs5kn3nV2RQD5YiSG6REmVZXu-G2lZ3K8ZjdUjyendeRLAqyUILLFQDKFGcjo6Yj5hv2A-bL9nNTNSF1MX2zurFZBE4lTfkDek9OIPx8egQHmA8Hp3ACrwulgaHPliHG8ht5RHWufUIztqVB6eLJagCbIkFpLZyYaNcNurt9fbgJsf2EWgPIefNBqG0ughgF_yoNKoYgCoy_rbQzgcIOQEHC1WRofOBflVzW4XeHuggYCrAxQ1cXMOnyxs4g6vLyz-P4JOVrdpDhqlRDjNQAfanSZIMDqdJcjDcH4_py-skSQ5OBa23x-9m2ujDvNImizBrp8qSUJytimwgrAbL6_zdRihPlTG8PoCCGclmBmsd8t4efa88-hmsbWUyKKsAkzGsJsT-GlXI0YEuIuDCWOvApzlmlcERfCEusUiN9egj56q3F_UCIXeIQ4_LFRYBSuWCDtoWA5itb1n0MyEP79FtokwJ0aHKfCN8-Mff_k5fCDe-eQCzDH3q9Bz3D0bBBmX8bMA7Uu3Syih6D5ObDRfaGMbwelWaDXhED4WNzBCDGC3i53P48ez9xaef4Orzx_MRnD02EJ-rEoXKuUN1J08Lpe8R1mpDUlOFXyNZXm8P-utcpzn_klmkxaQyXWR2Dcbau3_vj-BG3WEjkdt15CMusoVwVdPxiozhy_n1DayVMSO4IUroI9sC-sZsmx0D8BYUuMpEulO7KtnwOq-JxkBPVjrLDNYwjamJeaT8psBvGi5UqovlCC5Y74UNp7xlqYxBt3nlo4TZfiMfTKHXWcSvaa9PFxuv0rSn3oHKB2ahQy1JjkDPz65vRnDm0vyj4oNOgmc7nG-gdHZOhNsC5SUh1-ldgd6DXSwAVZrDQqUNp4LN8rXrAnJLlEbTZfrUnRgoCgOFZScDNk2rUqMfgOhae8AHlQZiQLVqoKNWZPLQG0tHdqFSlSEoo-9wBFeoMiZdpXesj1M2SgDl0hxqcyfsVWnQ_0uDPGS_N-Jlw-Gv3hYwHHo0mIbIlGcken3HzMBhaV3wMOuLIvun0Cdp92ftAb3Fp9eRHvszOlW9PREl6YTkc_b-6vL6etcEG9GsSeferpDUwo6TXTS5VFzx0ZSz-JfLT-fXI5j9ldYZfU-rfod__O2_4Q8ijx-XTt-rgM1z4ZB_8ujuddr5aelsVUYvwmrzQQUk5Xpxb2tdLD0ded6fKw9_Ob-6hCXaFQa3ORUn1W4DXbAZOPTW3COZDavdbEB50NGm2Dk7WKNDyNBgQDqPakXCsS7ThQpkOfxEZ34A803Aoc6wCDpVprcHmVNrPmV_xtUcnc91SXL8cP7-49nV-YcBFEQY6GKBjg71wtkVrMmp0aEnTnOiofAUFPz_2pforKOQjdh0dK0wR2PXkKoCUuXchsy1mrOLBWal8dKFBbWyFUfK3l5jAKLLmm4yApNBru5JAE7fYzaC2bZJ7xotacDPwFlj6tCnHCoPVfkWZsNhV_mzGCz4lMtxBx08HeE2zEePJF4F4ZfLj__10-Unls6A_JYEKnCYBkWBy5-Cgs-ivfrMt5HAFiQ_FLdUhVxCmPJhBF-cDoFcmK8hOQ0hh8liKJDdLv1Cro5MDuYY1oiEWWpM0df-KFqJczqzrk1AGj0JotE-sJuRdRE86BV6cswkvxSL4Kwmf2MMWfsOPxQaid2tCCdZlLpHp5Z1QkTiqwJbfWNH0TEbNUcOQaVRKWbkf3OiOL4sysmtRCdnxlsgEz2FmcFFGNpFPLxqbu8xRsCwtuBQQrkykGnSj7YFB2_LiUl0hkAZzNveHsy80eRQZpBZ6_z2ObB8Cmydy7QC2FdgUMV45NkRwJskgdWKXQMnSeOpPOiYUtwVWVyrzcHb6OIRZqVN7zAIHbCQPENUSpZsi1GPU5v--4aKn8mL9-H3HkBVkAmvVj2APZgtnc5gmsxO2wzK04GAcZJIUIshfrYwlc9nsNAPoXKklIJPBigYjUbThMPdqAcQEXsApaIzfXYoa1NVYg_Ap8ogjE_HCS0prAs5VGUPINMrD6oKFpQxvDDaIpt5D8DgEousx3TfcPpmA3kk8rIsgOAQQx3aKY0ZwcxrOsbkLziJoDTwLRlYoVboYaHvkfE6-rdFm_898h4Cx_mevG3_y8FAour--cEA8LdKBetuyY4ZeP96EJmMJy-uOBiArwqnPfJa2e2rwmOID74cUAKGG9aGgg9XZz_eXHz6iVF_Pv98dXF9c_Geta_IJ5SYhtM2XaEYU1hChJXN0BAVQOYeKsoKioy-Zyqwyogr-L1midOoHFfal2zhQv4fIvjhcDgEn6MxxDaZQO07WpPnhGj41b8exNwye8eAgA8BnWZzrpOpwySB32E_GSQHsD8-ptql_TSmc3NAv8ZPXCrUlN6sLSwqY4ZrnYW8a96ZhZVtk9m1dXenfLDmmOvIjTA95yO3EBMcMCyt04XYXeNN2QPVi-eY8foRnCsJg6quWZjfOaaKakl2bboQO9EeUlsEXVS28pQOkBXbaplLUqMpXSyVo4gOaa6KJXpQxnLZNepIcn1LZNwWLb8daU5qaR6K4ESM8uWPxyD-ZZCTLshJBGlOZ6e4CR7N4rTJlQcxjsT81w9gpUOsVec25BRvCnR-my3Ge4mgtsqNn7nIhW7FW3857BI7niYSp8dJQqFZnKv4VgqppL6d1wIWrBpKeohCu-a0oFQFmm2ql8rcruFJssdTJptoqcnmzydPqINg8BkY4X486eDIl6eAKFpvXgRiGhpinrKNTFNu8RLGm_qcvnnOvu50SPNvYKjl5mkrDTl8A8px0rFU-bIDhNn4ZaBpK1H5HF3OI5zJVwgat6clfmmQWgcr_kbqCsw6NQTlPlyEzL7NwXYrnP5H-ZeAJBUAyV109s7dxkXUL6pNwOu_IhCzD_QkpmERpQ-cF0Vsxtrr5FucqUlYFpNTS6ULH6LT41fRu1_FvgLXypKkGb2kHlM5i6DkIhlJu-iVMSPvV5UchynIYWqpD9UUPdK64mxZctuVvY-pdgPakEA_bpFK5XH0ql0BxaMTWYRWYjXBIq_DXXmd076-SEswcklwuuDxTJH068PzNNoHXhjhZFcv8tQpRqTEkK7ddnDmvL3N2nWTstfdkbodUguKX9uk6EtNkQkfSqNTTeXoPufKa-0RZl9uqQ95-_Hsh_OPt5efb64vPpzPDnblWCe5pTWbpS34V9j2g9_rymuMZ51gx7PGtVGcPwkxfZb8CaO_niYHIt5uty_qjA_pVn-g_0v88PSxYs9C4DUp9Nc5WEmr2h8kb4Bx1G7MIx4DTqSr27L3FcDJ1wAPGbDrmgQweQbw8AnAvbq-qks9KaIKXLfJ9WnM06tsQzmnj7-YDSfttuxkTzAeRNhYcEOGJZcK0oSQVq54kNYrDMSbiIPgg4nZrv3J65lWqPXDR5hOdufUTTuMX9OeyLRdLHSKW7ZQN4T61_HD07bAQY9OWeiEt9ocHp30P8nqPkRPG3fvak9CYAfzsFUgY046mD-okNPe2nvT7h3AKmizDSgB82nAz0EbHTYNkZV8r6UTw5nUy8N_8k8KVi6hQRezWMSE9lGwEN30jBxgW96bzTC2DoRPuh8xeo6UTpsN49I9iupCzSAot8QwaPJ1MsSmiyNtsquL_zj_UF8hcO9bG25jGUOkMXLs4XGVVoXcUqabGkasgyIlnV4SBi0t9CpQt8062NhqBJcF7a7LI0aNTWdsfDGVMc1FQmmULjjhVsVmrTanMCOJNU0YNOYVef415ed14c4Zr87eZbdS3IjXGrM_lBqKHIS8WQo2qqYxnpsoONH65aM-CDU_qX-CrmnUKinPctTLPMBSuQyLunMFKg0VKQ605xDOsEremElvhItTaVT5NWIJqNnldK4JIPZG2mKESg-fW5Ntcyz9aAOxxUP-qKmkVIBjZlxkcJIkwgkz_gTKchtFChdGmTYok6RBccR-WzexexrwLYJq2SjMBsaHU-4SrWlXbOyx8rizHMuWO8TSSxlFbQTPuKlB5d5KAyu-kHoius57uHCJVSwfo8lYGlLkj40q7kTp-9Q3oYqIQU-mCVt-7Z9JLqWpqFz6Va3mB4PYIJu1wqrvAZVe8W1hiMqhcm9bH-KkI08sRqmkVIBJK8WTx0JsIcQzNnuRVfB6mgB0d3ddR_SGLYT4wh2II1LdcxC0YwtCCh2GiDWPCjBmMgTizS5E6-c7vHB90hqlZ0KmyfMotGMXYvII4iR5GWKyC3H4CGLMzDwPcSim_V55zJq-tCQCZTU3Oq1v0_mGiraJ25L0gXNx6lzRgSefYbjArr2Ezt7ZOjFvKhfxWPVxndYuKxa_u7t3M-_t3cft7phs72yPBT5tP5pM6-hbb5-028WZPLUdY7ClN8f9z25vY2q8fDulrjm6eN3n4wjB98TUeO2ps3dFXdIwPXWzjf86Xqv1_zuboySFmYSYibt3ZfnU5q3ciCW5vfno-c24vfn4kRbfsJE_t3krg-LNR93Nxy9u3sqWePPryTdu9nXXgTdPSF6xE_ANAvN1q0EKl8n3bz5syD7stDO-vnkdfTPE_ECyw29UVTyDtyZunryZbm8-2RFYa--j0SjkWDzRav6ezLIOsz7Oj3BznYdP-PYZMlzZwgfHieNo60Zbe762x-ypsQmCbQYnODPlwMxDBG-3Lrxl-ICCJt3q7a4njLdyxVm7m726zKkb7dvtk44sxCMwS5FEbklvvQKuLz_f_Cyt7Oaatrk-ipcTMoPAALGXTQMKWFdeuOVzRjsarlOppqL-ukt8vH3dDi5Nuwequ51XPrkbO_WsbP-e3Vn0YC3tj4PBI3e8qFyh-WLsnyxxWiBvFwqoPdO2moo0p4zWlsC3cVKUTY6S5OFNp1i1C9XfQgpqbnALiRpASJUIIxBnXYQbWt_vPYcRHf3LGNKokm39Nr2tXbWrCnCUoG5VJFLJx4uBtzCzi4Wni85oo5mmoQ6ZqqG5EEbli-1XHt6ff7q5Om8uRcRY-eaoM2BnbSidphvD1K46Bp2qoIxdVmzNLdOR2luvi7umWusUQPUITwJCKYwPKXNmKbV5XEelgboO8e_b8E5ewktpQgLdd-AdHb2Et3A6W-L30Mddki28LUAKrqGaywqOtK0NDzlppzd1jHn8OkkeXvPdcIuyToWiRyhzG4JdDbkC7aIcPQEyV14XL4AINR0QMuijadJ7UuKMwtH_6UNJZeLDMZOwxwnIAycDdkE10mpOt11laTRb81xtBnFvLJub0FDPv9EFdsE46_pmuW5LqHY-QlZdfKLGa1OXNTbfnAKHNFiKrr4kphkknUoQoyut3JG5y9BLyE85yz-VeQCUNkP_i_I5uj699GQypVKRj10MOzR9MJJ2jbM00wRvkhlNf8oxXqk01wWd2R_O3v-Ji0gpFYlkX5U0RymBywdkT0FLOiN7bQeE7kWDXEOLtVLMZtrYaTTHOqOpGcV7hg5_qzQP79azDIq6egx6Px5NTrgFblDd11Ot1GlkNpI4EERgRUeDtU6lfqFOOk8nygTAl9sfL_7z5vPV-S2xe3tzyW1yud3vaEd78L9VyuFQ-7zRFXs3uUPmpk5sKcUuFFNa1GO_xdZsFF9rbLszkUxM-47eTJPB68Omt_dGDLb237WGGwXutCg68zjdRhtTxJehMm_EeYOae2uqEEd9PDgVGzVK-JEj5JtGWkxtyHq3Gm5xxkv8OV2CsxIb9qRnEhcxMDWCY88hp5RGMp54a08jQDz-xV25tuO0QlWEbcFl6O9ihUlJwetGaBz1XneiHvq77dg7t_YuVT6mJNyzb_up7CWOOv3ZuLgR-_hkx4lhkbbVCtWLSXsBQOnNFhot3gnjZKUdX8rd75d96Zh7vp1m-AdbcUzftiyXOTsXLo_kVrPD5pH0tlvbktUvsLlD5eRrzvqbqHwEe_h_hm0OA98F8SGtexUzXcC_kgn_2yy2LNiwO2MfDmWmWdrRwfI00gjOJJ8xiiNMM7_6aKZO-w5Pj67vmpn3dipb_KW03vxdPAXSCg88kkk3yzzByTPsPExOnXXFrjjYeBvavrSmkbRNBW8smVuRjTt3BL_I4n4nWxZHTu3H_5crAcpNZp3ed_FKZjF5Hihr54rWtS6iM229y2h7ZqUZyal42ltRUL05v7q4vHrmPxqw04vTspwWx2n8mCaJGbyVCMsvKlIaWq37uzKs7lTZ_D8HUU-8I5X5FBWnZ_ia3Fm6Zqe-sDg6enH7PxuYUQpxpDZaCvYeHXlMykJIEUEHg_GGqnT2VxpuezQvyL9yUnE730C_Hi6Lz_n2c5JMjofJyXB83OdLnz96_wM"><img src="./examples/courtyard-house.svg" width="270" alt="Courtyard house wrapped round an open court" /></a><br/>
<b><a href="examples/courtyard-house.arch">courtyard-house</a></b><br/>
<sub>A ring of rooms round an open court —<br/>the case where a window's outward face is<br/><i>not</i> the side its bounding box suggests.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=7VpfTxtLsn_3pyiZh4BkfMcmkIQjHghhD-wmcBS8F62urnB7puzpw7h7trsH4z1aaT_EfsL9JFdV1fPHhpBkT3SflgcEnp5fV1f9qurX3d6BUzgcHsIjjEawhJA7xH0frMM1BHROpQi5rTzCv_7xT7AGIXNqpc0CSnQgAwcwd3YJ0wIfsJjCrLDpvR_2dno7cLoFoj2EHGFW6SIjkLAuEUKuAlhTrGGp7tGDR0NDDXhMg7ZmAMpkDbz2vR3I7QoUlIUy4NXag7dDOFdpLpPTNMqAdZk2yq1l3MxmawaaYWqX6EEHD3ZloFQLPO7twFS5NIfULktd4BRWTgf0EOzKsO3Dj6Ohf1gMup-Mn3xyIJ8okxFihj51eoawv_-rt2YKC2dXHlRcjP-f_50O4fwB3Trk5A5bBa8zFB-xG9nt08ro4KcDmC6czqYDgi5ViY4-8qkqkP7I9NKDqoKd8kvagw8qYAbWpMgrV2VZaF4TIE3axG-GqaLwWIO9nTY62oP2vmIIjr3PEQNwtBB4Ygnz5OIcbianl5_h8gaur87h-v0fz88mcPv5cjI5v4LJxefzc5hcfjq_GcJl5kE5hMrov1YIt5eTi8srUMAuGYC3vHyvlmTLVGcnPkzJAFUUws9oNhkHxgZQkBbK57LqUHMsw7RQThGBhGEhR488syzT52oehjChZ16bRYEwVym_v6LPhIwEVZVE9nlhrfNQ4EIVx_T5GnL1gGAs8d8EyKx1vR2wc3qoHZGrpq42YQo-6KIAhyoT2Ll2PuwzLBTKsMuVpwFpjpkkVWQEhbwOUsOq3b3hA7qgU1VMIbXGYBqI1hRfdqGk8QwLuxrCWa7MAiVy_OCVB00sJQvXtoIFBpje3nEc7_589el0cnZx_mEKToUcHfnQgAKvCzShWEOmfZyTbKVFCBemmXaUpTEAmHUqBc8Vo5ZhaiU8x-KNQi_yAK4yHlRhiX7Bw9zaUDptwitK-4_XVz-DetQ--jXTDqqSZ0MTkCbjQKvAo155KJRboNtPrRSDgIAmG8IFOskymoh88Mhch3XDv4WzlclidKJtnWk4OJymKr2PIYecKEqGpYVezsjgYFfKZTEaDjH81JC7XRowQxGCLcWRkCrnKFF5gZldmemgs0DCzRFsWVqv6xUxjanuFd4Kf2mMUQ9ANSOyjjJEUVkgds58cBUxJtUurQoORW9HKsMqJwfhY4pl4DigCW4NmC1wAKtcp7mkybobOh9s6WE0HB3CEnxuXagdQ07q7cBKFUWdcMHpsk5Vrv3OVgFbv7YpVdP5Xoc0x5hSRGOZtrcDBZpFyGFeOWaqt1XIKQ-WqHxFPjs4TGC5JGuothH3yiD14iBJavfXvhqAWihtfADV24E3SQJLbfSyWjI3Yi47nFceJbLcXlY65JQ-v5xOLu4m19d3V6efP1_fTofwyT5wq2sdxS1MKsDjgJNhpTM0nP-85GP6UDqC2CbOofCCUUvMAAtcouFU53cl924v_sK1-JfTz5PLyeX11Q18uL56NYFP1_99Tp5H8KU2yJGgVHk8ORgnyYDnWGHYd9Yum4frk9dHSRJ7GY1InfW-8_hNkiTEJo7Hc_XZtGwvC5Vik123ZzwnVTUVcp6VUHh0blfogD_zWlqNmtkHyVfLEbZSibhm-6DS-5b_xhIjUluu90vlAx6TFaqRIaFxQZ1jEhcu7bUJmVPaUHDi4xUGtsdTGa7TS9U1TXuY06qDhVRqrPZCaR5H2cMvc-tJVVFQEpssPq29tIyddGWF9PfaZB5QORO7CTtwoxjroqh8cFTUCMBj8YBeorxRvW7PqCuVaDzY-RyU1KnR8A3lKbFHyFsXBm1AB44UmV6gmgvxpqVN7zFMj7nFcHM0ln3tnM6s40UZClfM-jfDN7AcQ1pYdU8eiEXbFzRlgfMwhczph-jkUhkswFhHuWsCIY-HR2QipW2hzH2Xu7s6gEHMPLw9TGLnFzn3NkmgLCqy-Fe1nO1FhyiXoRHXcvopMUSbxZTXuFHWOLwlVUR5Q6WhUkVBsR7CKVBmotQgT1qYtZKBla0KShVJEyaS5qQOalbgT-BXlWg8ciAPBr9CLOPyuUpwha5pqJdoPOmXNCdCqlqbUXo0KoIbEBb4IFKHCugQrixFYj8ayjHkqYjjojWPYUpLuyH7d_emvR1wGCpnPJiqKGBuXdSIRESYVQGmgjaVMnh7d3N7efXz3fX7m8nnP59NSCmkylAxwwc0rDXXwGHUgZzWujsGgXcShhSPgvd_-eX05gZK4h-5IKwsWU3coAq4shCcIjmsTS2Q2eIHVEWkaqSDsZEsTJNgoVTungtG4ApVO1hoOJVE5T2ExF-4SwVvZev-RJWAw30MU0cVnBVH011ErbAAsD7wxK88GfyAzpN9bWlDesRFhFqUqwzzTRX3VNKVl3qOPjSFkv5BZ5o0FFNqQHqFnhITeb7CD3vcjvqTek_Sh996ALyDgOWyB7Aj2wg4TKbHnXpYKhc0U0h7GEvd36r6HkbULHy9fZjOi8rnU8ac68dQOWQh66VAD4fDwwSsoz-ShMS17CJbMUbu1V4USqoM4GPp0HvAR5WGYj3sAURTewC844HTAyitC07p0APZg8DomAdI7ajKHkCzF6KY99jA6yqQiFcpejg8TBLe8iZJ8hO8fpckkBaoHMwwrBBNzEgX1rLuYWcjqz3MCs0tj3FnlqQHUc53XLPSJrOrugM2m9_YzkXckLSpE5j80hQgIiBBd3clLGp9rsq6XBYqCueMSshSZ1nBlZd2D1FGhmYHI5U9RpSx657WspMIjxQ8ei2qDmpbJdqS-ixtrQyFpMAAt3ACh8SS-LMj5IaUZWqhDfo48gOcwCh5kyTx_wmcsOpq38THgE6zN3R6b9DXr978cnl1TsPjRDtRsqtshspRuWTqDqI_gyU37JNnaivPJwBwAqxjGoBNocPlplYpZPizWiYCvj89-xMBsvJpADu6SJs6uK3yZT_2GOEBCxhB_2duzxIlyU-Ir2cn4kdovdK6BWg1v8FuMkj2YPc2_v6wR5982KNG6xH-vonGuQ2d7G7RyKu_wS57mbHkL1rj3hbM6o748jzMSGCSwe35pAHhv7cx2BkvY8jku7eNFQzB0dLZibtj6QJA1bw1HLz-G9JykkcOTKFmWED_QhVFH9qfyqMX7SO7me6-Z3OWQnMz5lnY2fzDsxAXH5lPcZaPPLa_OYsAbKGuUhkhqOyhDdTx6xb1rBZN_Q7qKt1CjFuiiCgui4iUnI8Hb1rEP8nY__rAmqQviDWACBVxtrTn7CS7EyYz-mvaJiR7JBdDTuFKJK7CVlYGLOlEELGAA4nWFmZ0rTWx7agAYyoHAkyVeAOh48gdFnIiQoebMpIPDVoRyTzrbr1ppldeDlygtNqEQYTcPYgLozLADWQgU3tb6KytEKRrpGl3cFPrDDpWnMslqJXijtVd7SqNBm8s-PBts2D6q11Jd52sPvmRO-baPFuXyvtaFmnp-qPhGJaNEKp3jX6FZWj-jagkhOQoj4sg78WjF1tRQ3oDaPP_RQWyIYi218uej0Kv5c2HhjfjTd50Zhfu0S6Fo5-d2A12M44QfBtK6oq8X7fd7MRsJPHoaIO-RxtmbL3pNyYevZYFfOFVfndeOaNZ_Swx04pi09QQZdKczzDKfc4PlkySoiMuJW2GfqKX-1uI3s4VPIc4syHYJQ9uIbkG0o4oQt7YuepvGyl1iCFX6Sac2NhFfC1FdQtipjxtE5-F4HB2IY5omYdJr8Pu2sOkgJ3OapUi-hhuz28m4HHBJxy72mT4CAeDWifzEdFuMmBRsRdBOXUpMfdke2Lnc49CaUVHlUHxIXhU6iSlIjzfCJCE4_JBB2rUmejMo-3vf62UC-j2aX9EFwSdYyqigpzpNcd5fmtIqoIq7KKKydI6MTrhzmtz35w5dbMjmngAshrhPDs9vrrNlUDHJPHnWwDHo5cB505nC_wewHcvA_JOeGNAVIyYxZwgvr1rc2JCL0QGx-MJuhCQmjA6TAbjoyTZk3ffUccjF8mxcA9EPojqGkP_D1z-XxJdP1Rz_RjJ9QMU1-8SXM3FxDcIro8ytl_rlY7AgkYKtNAzzEatHnpZZb3HjF8cReEyk_-3EVXIv1VhvY8Hj_1oLL371MBxC_eyvKoNHG8ZGMvIlW3Jxe1SouHjzYkczTK_-bpm43SSdyZ0Lh07skpT2SMR8MKpMo93RnE7XYeM1lct8lha6bJru1tTABphQsscbSmTrhSj0U_afcg3AXhP-CWA2sMbFowJIDJVBXg9ftGC8dM-36XR9_R5s8HtLYE7flkhdJlBFairEN6-qBBmmAnPuQiy7V_pwFwSx500-2ArLopbXV25zNkZfhH4SV9m_cE74wh8GyH63VYt2-BSIx2cLCzI1jU0T-RgiA8i4rkeaWW6tY90ZeEYj5_pXFegZ3QazuQ_5tSDymTYORAh2AHcnsEM-cRPN9dkcc8vEmQmN1ASm-ETlRLyUM2iR2iSr7n6zbNqp964fQnniWdfEk3PwDTicEvNbQinFyg0fm5d3WUd_nsMGj9n4DYznyfQJjLVplDny-vDw2Twbty0bTJu1DHujAb3WyN-QPM_gP4NpvYrRy7_6f4_qvt_owDwocrW3ygAbmhsf-OQxc7nOsXfIQFu2qvGF1TAkg_Zv00FfKJ7mtj6nxMCbeeLa__m7svjn2u_8LsacFzcl1rwk_MYGf-0CXdD-f_VhLuB-b4mnKG_byuo2P6VUnckbG8qKPr77So3s_Y-VR6fQf1SYX67eQLwPiJsNGCWf91eq-qLv3hzzopRzvFVfX0uX-Coh1FXjufcEZivuOXe_6HeBjc9nP0W1LqDEu-6mya9hLIK8d56axMqBnxzz30nG77nW-6P6bg_tuFG2n0lsgTF2-vvaLmbyF9i4tt_u-m-PXzadOG5ttvN8u9qvPRdpS53-axy0P2CUyQSX7vydxudtXM-pynR7Uu7LvQ9yj2aHGdi4WveytGksJW2OjT-lYcpp_m0Pp-kK6BXng9IuUVnbW938fR5cnF50xyMLuS401iYUopN6QuF8caObpUxG9Y9YQ72AR19zYMoV6uMoEOBUVSUzv6KaYD-pPtd2oncHkqM-OL7braG_qlL84_KLOLn9FWO_jgZH-0nb_dHR33G_3vv_wA"><img src="./examples/townhouse.svg" width="270" alt="Three-storey townhouse, ground floor" /></a><br/>
<b><a href="examples/townhouse.arch">townhouse</a></b><br/>
<sub>Three storeys in one file (ground floor<br/>shown) — <code>level</code> blocks, one stair<br/>shaft, one drawing per page.</sub>
</td>
</tr>
<tr>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=zVjdbhu7Eb7XUwysi9iopKwVOz8ucuEcu7FRxylipSlQFNnR7qyWxxS5JbmSlSBAH6LP0AfrkxQz5OrPyUHQ3jQXgSxxPs7vN5zpwzkUdt5gESAs7dAH62gFtW09wb__8U-whqB0uFRmBg05iAcGUDk7h1zTgnQOU22Lez_q9Xt9uKMQlJl5QFNCqAkajWY403aKmgVC7kGrBcH7j5O764tLOSM4UQSbRq8gWKAFuZXcb6ten4_Nz-TPaat0yfooD8r7lkqwRn7xNVEADPGPAjWN4BKLOuI_8TC15YrF0IB1pTLoVr2-aCg_DUQDVXpAR9Aa9feW4NP15Or6FjCCiFO8Fa1zH1C5HKak7RLoQfngWZWpDTVU2lrne31Whw97nBMUNl4byA-SgzCAr9ER38uqLfmbkgqNjnyyCqtwBnlJvnBqSjAc_uqtyXt9cNRYFzyoAK0pyUG-IBdUgXpUWGOoCMoanye7QsRfiT6Vcj5ELcEQlR6M5aia0OtDyd_aChQbtDQcDq1MgEITmhjnydUlXF1ev72a3MHFh_NPcPue_fR2AOe3FzC5Op_A9Z2c-tP769vJCM6jn9n7UFunvlgTUEPRhkFyaK8PeU1qVofOp3O7IFFsugqcB0Aq1OTWGcnByOkB540m_3STwCO_mOV8Vef5Xh8qpYl9sEQPU6qsI_7VExQaW08-BpDKEXyqU8xKDO0cKvGO8o8i0OvDcOhJUxEg6u1z8XSOrqilrvjO4XChaAn4YE0-gusYBadCIAPKQKgdEQRFzg_AoHOWTTuLKS8-e-I7v8D4RZaJYbE6orVPfIzjMNihfBiIaNtwweZd2v4r6QjPsizj5LELck6VJOlTWZeSMTIAamso5g1C7pXW-dO8JixzznCEpTKlXcLUtqb0UZJztVFUsLNtBTONX5SZjTrd_Yg0LZAzMofzX375-O7jzfnk8i7GSG71KewOJcqhRgPzVgfV6JUyM86T5Jbt7PWcpRh9IxnBB2aONYsnnvjOdP7VWKGIMTyIJ0bwzvqQ7OF6rcmRxIf4aM1pJpWK95Iw8CrLno6PswxKqrDVwf9evg5LG91Q2iSNMcPkF-SiSklboGEdAmkNK9sCTm0bRj2pjoPJHgkfwNceMBUFD_N5D2DmVAmnWQ9gKyWg-9ffywSJ63audDpKWYV1DoAKPYAGOWPOn4FGU_oCG-oBGOtCDW3TAyjV3AO2wQJq3esBaArwCV7Dy2yjQx9sG8jBUpWhhsMlag0FmUBOK0P-KIldwGt48R2xkppQpzMTeA3jHevoIZBT1oHAhloV94a8T-evzm9uWKST6afcQuWgZoGnYhkHwbUmskPVah0v5cSOzagK0TgunGM4eLuVSzEeEO9X5WtfcxjXaq01ggl8hcNskB3B4af0_8URf3NxBIW2nuDbDhDr93kJDbqguEa2oDjZvsIhWydI8uHiaA_gXoWiJvMTGM-eZ1Gh-OFbT3CctfNOES6QqLxXX0gc-iDB0jglDQdXqPUBCGvy8R15rRZSMwEOWW4Ncvoyyx74xg7kRg4mmCi1A5QM2iBFdbfATjZgf4yHE1oSjYZJM1Pla2luHOQYM-aA41dZlhL1mM3zUqDKBLuxqxMvPyfLrIEULAxw_HKN8GoXYMuiDURn0w7G6bMfYezY0YdzCBycxL2WTwjXoSvJnDGdga2qmNZS_UxcbcPte3ySZQNQxnOxh1r5BLnuIEwjI5jU1F26pnjykSAirXkwqQl3rOjXlDiKCRnlVPl6ueWytdNPs43P2XncW0R17i6i5yOULa-tYY6fbbx2PM6y6KOqdUaF1hF4WyG31y4dTVFzfdoGKt36ml1B0gtTimdZ9vDydJ1Pd7bCgz3IrsK8MveAM1SGGwdHZFN7tqoYlzXi27sAMlDkIeYM-cBpfZxlg-PTdVa_yrKHMVdIqVxkXKnNLvDkdvqetMdNrzvbPJ6U2byq4ery_OLyw1a33zwrBFv6R2z_ynddwhq9gkN8BCkP6KVtdQlTgsvPN5d_vrz5_O76L0ejNWOO4eAPGzUPtp8d_7fkOcVQ_zZANjiJtCkAJ4k5dzCo_J_Jt2tP3-Hfk23qjMcS2xXKFa2Wl9UOGBuVkE421Clg4y3qfIOhTkgssQtB5fFPUPkbKkXiuMOJf-9DjX-Oyzu08R5aoqxbu0kZYda2kUfb2XeGsgKdU7SZA3jIQr9VNb2tV9MT300igEXBgZs5bGpwhGWUWYfH85dFTWUchG0bhCQXCmWQ2ebWqMkIDt_EoaOb0LbDJkPJ3JakNZWxEDeTGZWACXGOJQ3bBqaoC2tW0fzd4exor-NIBH-yZfHZx-LjXfGT498QH--LY3xXpfri2zfiL_fEOfkecX-n_3f7x-l3mkWn8Y87RddM-UJJtCTOxF2rWS1s2Di1wGJ1loafbiBK-SG9ygclb8c4BkCwCVmmAx410PBrubY83cuklOapJCKLC-qenZKetiHDQ9Njq5IjN2-Xk_HaquddGxWH7HWtKa8WDMRKXnfBoRNS_m4vZJSH8dZz78K2U00HPwQed8BTG4Kd_wA120O9U2b2GHVZCKhQ1zbokJ_lCVnwTuKbdF8p9Mr8AGHbZIF4zrR6mv033bm0y_WzbLLFDNraey-_xqSWZOEGEfmIuzAg12_rg8MykpYjHul5_8JFn1D563W-yXDoceXBW16l5AurSlkE8FRp4LBEz2zkqAjIboXfxTVUqXBmDWp_lGDTJuj9m7vJh4-_TO52aIiTlkfSNKIuUd8DFs76uLTRcSe4VKEWrfh3nOqO72rUFnzbNI68j1u5OHpSOaMBTKngRUt3AXucqyGuWhwqLduC6zSd3r6fJNjCcmGkd23y8xNZ0eFZHGdNO5-S6_Y9XNLdSkRO7Wy_MPS2RkOm8FZT3NrsL9iiB-OOTSLh22lwWPB-M9rPtRj3BfwkSsCacBEn_27i71ahgZ0FpfI4c0RxOfLoUi1rxG6jlzAl3v6vf8s3zo99NUCFWntQZgDLWhV1tJJ1QjAUoFIzrgt2opdmFbmF8TjbZ_KuXK3zfbyT7kzW21nOlvlBx1j8mN5-L8bdi_LrdWsubLVexKVdljVdwshTrtx0c5dmhcnV9R00OIv5byzk_MbK06ZOakX64qh7YFRSWDWaGcT5QZ5VQQVN6cnZOPsr7-keL1hix-Iq-jxdwcG5K-obNLP0PQaCg3E2fj7MXgzHzw8E-1vvPw"><img src="./examples/two-storey.svg" width="270" alt="Two-storey house" /></a><br/>
<b><a href="examples/two-storey.arch">two-storey</a></b><br/>
<sub>A void over the ground-floor gallery,<br/>and eaves on the storey above.</sub>
</td>
<td width="33%" align="center" valign="top">
<a href="https://playground.archlang.uk/#z=rVpdctvIEX7nKbqkSlnekFzo17acdYq2mF1VvFJKVkqVJ2EINIlZAjPIzEAks7VVe4icIQfLSZLuHoCA7KSSbPQkAZie6b-vv-7RIczg1fQEtnA6TaCCSmfOTgpbIVgD1iCU-IQl_P3nv0IoEK5ub-8mv7--ufo0md1cTT58nM_uZjcf5oBbVdUlTkeHo0OYQdBmB4VtPIL2vHLR6DLXZgWbAh0CPqHbQaXLUlcYHH-m3KrBHOwTujF4Czq0i51eFWF0CHWpDAQLvrAbfhEKhwilMqtGrRCW1lW0QgVQDkEtbBPgq6UOX4FToUBH7wz4QtV4yUcFyK11sFDOAMDff_4b2BoNJNMLAFBQolqKvEKZlSej0La_m32Yg13y7xtVlqCND6hyeqYN6NCTrJe2zFnyRuehgOOLJIGwsST7CeNp-RttgiWR2oHdGD6INisRpSvISlQOAI7Uy8m7o8VLAD5iris0XlsDdVOWSGJA5PAu1zc38zs55FJl6Fnrh2IHSpTmQyqTg7EBFBTarMgHBn8L96QdBnDWVuSJ4-n5OVSkBk5h1n5KJhodgt9osyL_agNL25TiuIcPb_dvyBk6gN8g1vLamnJHZ1tv1I7PXaBEDcmn440OxQVxjbGBdgXybylRmZICn2iLo5cpOAyNMx5MQ_paF-PMWDOJx11rk1N0jQ4hfXj89HB98-3j7ftP93d__HA_v0ohU4YsgU9oQNV1uSNj6sB7kZlq5dZdHIjvA2SqQlg6W01JrC91HmM2BY8m9_RNsBvl8m7ZCw9L5QBNDkf0zJOIEpfha14ImTVPaIK2ZIOUD59C49GPwVGkqdKaVV8ahUxw6gmdVyXk2mFGq1-OYVPorABOuzYZS2XW5DTbhGKCytN-zqBrg7rUT2Rn9nw_cxYqW3OCyld2GaBUeY5OEj9tkyelna7uZmTeye3Nxz9N4Sb6rkLlG4c5q0GWuWQLUn6hB0psskun3uhQrEz71cpgSZJzpzamjVqWiiUFzTUjxsbpENCIxgvMFMFQP9x5OalfNLxAm1z7oM2q0b5Qi1J8OcgG8nitakIm2pZPY7UJrcFIJEe_Hx12CCVQx5aiIF5Z9PTMRGQjY4ndONOUy51dCBIyXIaJNuAwQ-_HMT3ZIRyKAY6nb2BLxqakFIlkucbk4p7RIZxBdQLLknROS21CCritMQueji3SRJ9MlSUfP7CyG9v8E7MWZLWl5jCKtiWj6YqzYmMpF4Kmt56FKEgF7VI282UP5caAimJQlWIuBsEIcOPRIeNfCxEdru76sNqhyOskgaoSsFSwUmWJOwFRhqjXHURFy7Kl-CmFBv2ZdmhKgFFbF_wUZgasy7VRbscfpG2gelhg2CCaFlKpDpHrPexsAxtnA76FNMojDPaiLJpcQkRTJY2QrA1l2Wf1Q9wVd6zQBHCN8aIkubsLpKgvQfleQAycpbMmdOEpO9GHo8P2U2NdKMAXGMHTy6FMUy3Q9St1iNWGS9YYcnT6CfMxGOTc39WYE9TdqzXChTjELmFj3TrYuvWilsMcn5x3H7RQ7xnqWmhix-yiEZZO5yvc16WBirFmZgRFNhQUogw5iuI2iz6_vZnD1fzj9fv53ex-Dg-zu5vrm2_HvKU4A-rG1dZ3HODh8Q-z--8e729vH29md3e3D7A97jgPHbqtqA-xHE4hVS4rIEefOb1AmEx-8NZ08dRSAEnGNNMua0rFibQobbbGPIWNDgUo-H4--_THu_kVpBS1Pjyo3bX5vkrJXmdJAmqlKA2idQBeibkrbXTVVFPGjpgTe4TTXCsFprTJirdCo6SQX8IxCdnCiaxjsUXMQMXQxTgHDx9iXi-U12bgLarAPXJgQA14JBdxlptZT-kVEc7wFnWNyglTeTqenp5Ok7HgIh-yKRF8sHWNOawsLfC6pJSwJmIWC6aiwTBFijrOOPLYApeWc0WR-toLZxS3YP6MQbQqbZSn4I1H5konK-jTMzYSA6APiqr5oCIifWOanAqF2qjdJVT2SSxZa8wQgmWprERGkNpPcy0lT8kxSW0fReKTzmlBG2pPqtS5CsillbLTvGW5w7cwmfjgdBb2ochWsAanI97j4J64-XfkoAP4cUQxqoOnMAA4hHTldA7nSSoV5zhJLiOH6sC-YxLHRGQLna2ZrVOp2IbGIamSYQ7psmx8kbLYNoi5o2AbsjOpHkxYhEHv4Wg6nZ4nLyGzAsUBxzEAaSs-mVQmb1TNcv9JzJiSXN_c33ZoOh0BRDVGEDGvqUe8YDKZTCIA_rrjyOwnrok_WG1IWWkhsgDKgw-uyVixyfCHBb464VQ6TaigtcTINiFir38LF68l2QgntfHMnikd5BTiG8hK6zFnibYJpTYoHZCPxMxDpYOL9oiFk42opdVpOU-qAhxtx7uXUld4D3GBEFhq1LIAGZrgkLfhGtUmAgGrsVBZZk5gl8tJrE_KQGoN9zEqwG9q698xWSZjCw3OvxGNcBvQaetg71iy0Y9wlIyTl3D0Kkl6vxAGvaRX8gvbAX4SZ_UbEGK41C10YTiFG1VRTWoZHteuPgIWDTEKNtFiRwWVhRLVU5SIzPHIwkvtfGjtcHR-ysfr67V5pFPsE2Cv2LEoFtfEX0STvg6xfF1SknRFWsVuZQpzSjDBpVDgDtCIGTQFny7LSMcnjH0kVCidEsKnpGxzchM0UCF0BnPx-DMC6WtFZXKgG7Ul8O_US8YnCXvphD2WiHrPZTziv5PRWxp_71uJ05LU88-T7L_-YXm3Jla7nDi3mG8MvkSsGZqJ8lq75qfDqpZSj9X2P2sdsgKNJJBXO38ZibZqX3GTSeZvwY_KV0uH-11U14z2-pURxPKZf-MeK6WZx0iWcMH4CwIF1JbrdKkWWMLBR5H5NXwiZQ7gC8cdiKXIZbFtjLJYIgADsS2xOQD5YbELFYqefyiv_k_-oayQTGiTtRsH9MYKg5HAvvHiz7hNEQbFrYGUGZcRU1sj1kJgL-FNx07_3CgX0E1y7bMBp-_YpeRjt88CTVaQk-SM-Tf5Y8zeAEcnr7oYlrkObbTHXFFDKKeXztB8DmpTSPllKuWw16FS2FLGVqgMq0gqRUYq1deQBeiJDizXqAr9fjrVdZ3t4Ersl2qTtuaOg4NfG-sqVQJVpste989SpUXsGtlY-PeUnycJcbwUM0G69MDt4RosV4jBaIB6Zd_79CL5Vb_pa1t_InA0zyiHLiDbsaGsAQFm6vDOyfrsBwrq1uLQG8V0g73PcZmnTdy5vvD90RxP5Xpzm9ZZ3H2R6XmiFVs7lirt2aAmtd6SvF9goSW8KjJRN_d7piPtGCeHoiY9UMzHkv4cURS1Teil6Uab3G5-aaISvLMgOpF5jH0nRf6rpEWoXuT3Q59JTEuFvDbrZ7IWmPPoMsDR6V5Y1OpkmEYDWQtmSHtRm8cVT2sibB6fJX1Rz441WOkfObll5dnps1R-dojBShREhdYUyZhir1158WzPvVfEgJdxYp2poErL4-5YOLhC95jvl_0XU2m59Bi6PO4YTUwiprMvPHyY39zfzWM-iTk9rrjtSLrulumxpHpDLZ4q13Qo4kZSidrBJxc5a0PtePaR2Tjy5BedPtwKGBsHB0K4sA4FWLcfQveHdDnPLTdaWMmycUZzHY217JHip2sfeoGx10SsAYQAlPJSSQeyfLBPGAvbfySLA-DLsuJ44r-Q9Xogq5enbff8y8vpzGSFpY46jilYLMO99GDsFW6RpSXtRludA6mL4tsZrgnSW3UDpEHD245Gh62btxXK5NBR_BAwLnZUe_KhW2W4IPZg7OaTQ7D1hGslAPCRhaa8SZLtmyQZSNhkbPrnEhY2BFuJkJ6EsyTZvkqSPebzKGNPOPB517rYfdZ-MojHqYKsiTdCnnp7poaBWm_qJSiaW6Ih5D51lt8mPFE0Hg64Y42e4vQ7YP-0H75JaIwYxAncvPOZX_g4fTe80Xz26R6QQpETdD8kkjgct9zp8xF_W6uiKzqqEdQaeUwveuaYlTylScmQDDaq3KjdvtuYqC3NnFtMuIwHRvC7amFLkKsYaXlBh7GEJmZBmVWJ3cbDABH_ELhenJ0n45PjpOWsZ-fJlvC1M1MXA72kKlt63HH9_zGpeieSciWIT138mM8kh6JWZkuFpyXS7zGPHPrL-BHrTix_Z8lARSolrONemsmKg38traOuJO2YhJ2ed2cj5Nmenu-lPcSvD1obHr8ewpykSO9a54WHQoWsGMecilG7wcDNaL8bvxBm0r9x4W0FS9o7m-ubT9dX8y5V9sEDBx95x4N9QC5ptgGnMj1e2G2XjVKukGar6DgPaWaBNPfycvniqGroIB2CkOR2dCTXF64xMqZuuUU7ONrbViwQPXV2cT7w-4XgCnS2bU8PX8T67pL2F9EylvcdN68F5fsAl-nSwoNqgk0vpZ2Q23ICEF-1V2j0vlJBZ_Dt-6_vwaM0D2Ib24QJuWlwYT-FeXuRcXt3Nb-DWmdrH7ldjh2R4GESTbO47Ek71t1Rfpz_7h5in2GXXEMm7-LdRluahL34ATuIINbdZkaI4dmuI5JLF1Y9Eg6VcittZMAmVxh82aOc0xxVkAbchlT6nE1hyzgAa6OUZR-_Pk_oj-6q0i6X3bBwf5UuMxW-DKGDLnathQvrmM93l_Y08RgndG1_0k1BIj244PJGn7LMbhI2edefj-05zvDj_Sft98OP9xFIR5Ou5v_QvqcyV2zLKAXai_4ccz8DdDJ4YU6YkulSyEoV_y_EIOZMWtrBnKoWetVILaWmrPfvKBtUzjNuOGuXss9lnM2Pu8sOAiEFvlk0bqEkWhaNWanSbui_PnIUEatS_YXZjg5FnMIsGQqoWSahZLigQ4k8IQeonf0BszAYnvMLRrXHxQ4OZi4rPiqzis9JiYOT5ORikryeHF_Q059GP43-AQ"><img src="./examples/tiny-house.svg" width="270" alt="Tiny House" /></a><br/>
<b><a href="examples/tiny-house.arch">tiny-house</a></b><br/>
<sub>Barn and bifold doors on a 7.2 x 3 m<br/>shell, now with eaves — <code>roof overhang</code>.</sub>
</td>
</tr>
</table>

**Also in [`examples/`](examples)** — the whole corpus, by what it is there to show:

- **Showpiece** — [`hillside-villa`](examples/hillside-villa.arch) (the whole language on one sheet).
- **Start here** — [`one-room`](examples/one-room.arch) (the smallest plan that draws anything),
  [`studio`](examples/studio.arch) (the lint-clean flagship),
  [`attached`](examples/attached.arch) (nothing positioned by hand).
- **Homes** — [`laneway-house`](examples/laneway-house.arch),
  [`tiny-house`](examples/tiny-house.arch), [`garden-loft`](examples/garden-loft.arch),
  [`two-bed`](examples/two-bed.arch), [`bungalow`](examples/bungalow.arch),
  [`furnished-flat`](examples/furnished-flat.arch) (the furniture flagship),
  [`courtyard-house`](examples/courtyard-house.arch),
  [`townhouse`](examples/townhouse.arch) (three storeys),
  [`terrace-row`](examples/terrace-row.arch) (one component, placed four times),
  [`two-storey`](examples/two-storey.arch), [`accessible`](examples/accessible.arch)
  (`accTitle`/`accDescr`).
- **Public buildings** — [`library`](examples/library.arch),
  [`transit-hall`](examples/transit-hall.arch), [`clinic`](examples/clinic.arch),
  [`museum`](examples/museum.arch) (A1 at 1:200),
  [`hexagon-pavilion`](examples/hexagon-pavilion.arch).
- **Geometry & experiments** — [`gallery-l`](examples/gallery-l.arch) (polygon rooms),
  [`aquarium`](examples/aquarium.arch) (arcs and circles).
- **Scripting & composition** — [`parametric`](examples/parametric.arch) (a `for` loop that
  generates units), [`relational`](examples/relational.arch) (`right-of` / `below`),
  [`imports`](examples/imports.arch), [`museum-wing`](examples/museum-wing.arch) +
  [`museum-wings`](examples/museum-wings.arch) (one wing, imported and placed twice).
- **Style** — [`themed`](examples/themed.arch) (a custom theme + brick hatch),
  [`materials`](examples/materials.arch) (per-element `style` overrides and wall materials).

The [docs gallery](https://archlang.uk/examples) renders all of them **live and
editable** in the browser.

## 🎬 Showcase

The examples above teach the language. The **[Showcase](https://archlang.uk/showcase)** is what
happens when you point it at real buildings and famous fictional ones — the West Wing (whose Oval
Office is a true `arc`, not a faceted polygon), Palladio's Villa La Rotonda (one quarter, `place`d
four times), Bag End, de_dust2, The Skeld, 742 Evergreen Terrace, the Dunder Mifflin annex. Every one
is a few dozen lines of source you can open in the playground and recompile.

They are worth a look for what the compiler *says* about them as much as for the drawings:
`arch lint` reports a real `W_NO_ENTRANCE` on de_dust2 — a quarter century of continuous occupancy,
achieved entirely by spawning — and it reviews a $2,950-a-month railroad apartment in twelve
warnings across nine codes.

<table>
<tr>
<td width="33%" align="center" valign="top">
<img src="https://raw.githubusercontent.com/ChanMeng666/archlang-showcase/main/plans/west-wing/plan.png" width="270" alt="The West Wing, first floor" />
</td>
<td width="33%" align="center" valign="top">
<img src="https://raw.githubusercontent.com/ChanMeng666/archlang-showcase/main/plans/villa-rotonda/plan.png" width="270" alt="Villa La Rotonda, piano nobile" />
</td>
<td width="33%" align="center" valign="top">
<img src="https://raw.githubusercontent.com/ChanMeng666/archlang-showcase/main/plans/dust2/plan.png" width="270" alt="de_dust2 drawn as a building" />
</td>
</tr>
</table>

**[archlang.uk/showcase](https://archlang.uk/showcase)** for the curated set ·
**[ChanMeng666/archlang-showcase](https://github.com/ChanMeng666/archlang-showcase)** for every
plan's source and the story behind it.

## 🏗️ How it works

ArchLang is a compiler pipeline. Source text becomes a backend-neutral **Scene IR**, and every
backend is a pure serializer of that scene — which is why adding a format never touches the language.

```mermaid
flowchart TD
    SRC["<b>.arch</b> source"] --> LEX["<b>lexer</b><br/><i>hand-written → tokens with byte spans</i>"]
    LEX --> PAR["<b>parser</b><br/><i>recursive descent → AST · recovers, never throws</i>"]
    PAR --> IR["<b>resolve()</b><br/><i>expand scripting · grid-snap<br/>relational placement · host openings</i>"]

    IR -->|"render"| SCN["<b>toScene()</b><br/><i>wall union · hatches · page</i>"]
    IR -->|"read back"| DESC["<b>describe() · lint() · validateIntent()</b><br/><i>the SAME resolved plan, as FACTS —<br/>no rendering required</i>"]

    SCN --> SVG["<b>SVG</b><br/><sub>zero-dep</sub>"]
    SCN --> DXF["<b>DXF</b><br/><sub>zero-dep</sub>"]
    SCN --> TXT["<b>TXT</b><br/><sub>zero-dep</sub>"]
    SCN --> PDF["<b>PDF</b><br/><sub>optional</sub>"]
    SCN --> PNG["<b>PNG</b><br/><sub>optional</sub>"]

    DESC --> FACTS(["rooms · areas · adjacency<br/>access graph · intent score"])

    style SRC fill:#ede7f6,stroke:#6b3ae0,color:#1a1a1a
    style IR fill:#eceef2,stroke:#464d59,color:#1a1a1a
    style SCN fill:#eceef2,stroke:#464d59,color:#1a1a1a
    style DESC fill:#e8f5e9,stroke:#2e7d32,color:#1a1a1a
    style FACTS fill:#e8f5e9,stroke:#2e7d32,color:#1a1a1a
    style SVG fill:#fbfbfc,stroke:#464d59,color:#1a1a1a
    style DXF fill:#fbfbfc,stroke:#464d59,color:#1a1a1a
    style TXT fill:#fbfbfc,stroke:#464d59,color:#1a1a1a
    style PDF fill:#fbfbfc,stroke:#8a8f98,color:#1a1a1a
    style PNG fill:#fbfbfc,stroke:#8a8f98,color:#1a1a1a
```

The dotted branch is the point: **`describe`, `lint` and the intent check read the same resolved
plan the renderer does** — so what an agent verifies is exactly what gets drawn, and it costs no
pixels to check.

`compile()` is **pure, synchronous and deterministic** — no I/O, no `Date.now()`, no `Math.random()`.
The only place Node APIs are allowed is the CLI; everything else gets its environment through a
`World` seam. See [AGENTS.md](AGENTS.md) and the [ADRs](docs/adr).

## 📦 Ecosystem

| Package / surface | What it is |
|---|---|
| **[`@chanmeng666/archlang`](https://www.npmjs.com/package/@chanmeng666/archlang)** | The core: compiler, CLI, analysis. Zero runtime deps, isomorphic. |
| **[`@chanmeng666/archlang-mcp`](packages/mcp)** | Optional stdio MCP server (the SDK is quarantined here). |
| **[VS Code extension](https://marketplace.visualstudio.com/items?itemName=ChanMeng.archlang)** | Syntax + live diagnostics, hover, completion, rename. |
| **[Playground](https://playground.archlang.uk)** | Client-side editor: preview, describe, lint, **intent scoring**, apply-fix, embed. |
| **[Docs site](https://archlang.uk)** | Guide, reference, [CLI reference](https://archlang.uk/cli), ADRs, live examples. |
| **[🤗 Dataset](https://huggingface.co/datasets/ChanMeng666/archlang-repair-trajectories)** | Synthetic, self-verifying **repair trajectories** + authoring pairs. CC0. |
| **[GitHub Action](.github/actions/arch-render)** | Render ` ```arch ` fences in any repo's Markdown. |

### Embed a plan anywhere

A **live, editable** plan in any blog, wiki or docs page — one `<iframe>`, no build step, nothing
sent to a server (the source rides in the compressed `#z=` hash, so the page is self-contained):

```html
<iframe src="https://playground.archlang.uk/embed.html#z=…" width="720" height="480"></iframe>
```

The playground's **Embed** button generates the snippet. Optional params: `editable=1` (show a
compact editor that re-renders as you type) and `theme=blueprint|dark|mono|presentation`.

> **Not on GitHub, though.** GitHub's markdown sanitizer strips `<iframe>` — it renders as escaped
> text, the same way `<script>` does — so a README (here or anywhere on github.com) *cannot* host a
> live embed, no matter how it's written. The honest substitutes GitHub does allow are what this
> README uses: a **static SVG the compiler really produced**, linked to a **playground permalink
> that opens the same plan live**. On the [docs site](https://archlang.uk/examples),
> where the sanitizer doesn't apply, every plan *is* live and editable in place.

## 📚 Documentation

- **[📖 Docs site](https://archlang.uk)** — guide, reference, error catalog, ADRs, and a **live, editable** examples gallery. Every ` ```arch ` fence on a docs page is itself an editable plan.
- **[⌨ CLI reference](https://archlang.uk/cli)** — every command, flag and exit code (generated from the manifest, so it can't fall behind).
- **[spec.llm.md](spec.llm.md)** — the **whole language in one page** (~2k tokens) for AI agents; also `arch spec`.
- **[SKILL.md](SKILL.md)** — the agent Skill: the `spec → compile → fix → describe → validate` loop.
- **[Language Reference](docs/language-reference.md)** · **[Error catalog](docs/error-codes.md)** · **[The intent contract](docs/intent.md)** · **[ADRs](docs/adr)**
- **[AGENTS.md](AGENTS.md)** — orientation for AI agents working *in* this repo.

## 🤝 Contributing

Contributions are welcome! Please read the [Contributing Guide](CONTRIBUTING.md) and our
[Code of Conduct](CODE_OF_CONDUCT.md). Use the issue and pull-request templates when you open one.

## ❤️ Support & Sponsor

- Questions? Open a [Discussion](https://github.com/chanmeng666/archlang/discussions) or see [SUPPORT.md](SUPPORT.md).
- Found a security issue? Follow [SECURITY.md](SECURITY.md).
- If this project helps you, consider [sponsoring](https://github.com/sponsors/ChanMeng666) ☕.

## 📄 License

Released under the [MIT](LICENSE) license.

---

<!-- CHAN MENG PERSONAL BRAND -->
<div align="center">
  <a href="https://github.com/ChanMeng666" target="_blank">
    <img src="./.github/brand/chan-meng-logo.svg" alt="Chan Meng" width="160" />
  </a>

  <p><strong>Chan Meng</strong><br/>Need a custom app like this one? I build them — let's talk.</p>

  <a href="mailto:chanmeng.dev@gmail.com"><img src="https://img.shields.io/badge/Email-chanmeng.dev@gmail.com-EA4335?style=flat-square&logo=gmail&logoColor=white" alt="Email Chan Meng"/></a>
  <a href="https://github.com/ChanMeng666"><img src="https://img.shields.io/badge/GitHub-ChanMeng666-181717?style=flat-square&logo=github&logoColor=white" alt="Chan Meng on GitHub"/></a>
</div>
<!-- /CHAN MENG PERSONAL BRAND -->
